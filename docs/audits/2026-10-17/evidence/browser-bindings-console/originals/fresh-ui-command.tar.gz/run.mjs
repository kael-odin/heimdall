import { spawn } from 'node:child_process';
import { openSync, closeSync, writeFileSync, readFileSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID, createHash } from 'node:crypto';
const base = fileURLToPath(new URL('.', import.meta.url));
const directory = join(base, 'attempt-' + randomUUID()); mkdirSync(directory);
const command = 'pnpm acceptance:browser:bindings:ui:smoke';
const source = readFileSync('core/scripts/smoke-acceptance-browser-bindings-console.mjs');
const startedAt = new Date().toISOString(), start = Date.now();
writeFileSync(join(directory, 'command.json'), JSON.stringify({ command, cwd: process.cwd(), startedAt,
  sourceBytes: source.length, sourceSha256: createHash('sha256').update(source).digest('hex') }, null, 2) + '\n', { flag: 'wx' });
writeFileSync(join(directory, 'smoke-source.mjs'), source, { flag: 'wx' });
const stdout = openSync(join(directory, 'stdout.log'), 'wx'), stderr = openSync(join(directory, 'stderr.log'), 'wx');
console.log(JSON.stringify({ event: 'started', command, directory, startedAt }));
const child = spawn(process.env.ComSpec ?? 'cmd.exe', ['/d', '/s', '/c', command],
  { cwd: process.cwd(), windowsHide: true, stdio: ['ignore', stdout, stderr] });
const result = await new Promise(resolve => {
  child.once('error', error => resolve({ exitCode: 1, signal: null, error: String(error) }));
  child.once('exit', (exitCode, signal) => resolve({ exitCode, signal }));
});
closeSync(stdout); closeSync(stderr);
const record = { command, directory, startedAt, finishedAt: new Date().toISOString(), durationMs: Date.now() - start, ...result };
writeFileSync(join(directory, 'exitcode.json'), JSON.stringify(record, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ event: 'completed', ...record }));
console.log(readFileSync(join(directory, 'stdout.log'), 'utf8'));
console.error(readFileSync(join(directory, 'stderr.log'), 'utf8'));
process.exitCode = result.exitCode ?? 1;
