# D2 最小产品闭环设计审查：完整复核并保存 Browser 候选

2026-10-17。只读源码设计审查；未实施、未运行测试、构建、浏览器或迁移，未 stage / commit / push。只新增本 ignored 文件。基于 D1 工作树 `C:\Users\44548\.codex\worktrees\managed-spec-provenance\heimdall`，HEAD `b42826e4956d491b461bbd00af3d18b2ad702ad5` 及当时的 D1 未提交实现。

先读并沿用 `browser-candidate-contract-design-20261017.md` 和 `browser-candidate-contract-design-20261017/README.md`。本补充将原 D 的产品部分细化为 D2，不替代 D1 格式/显式迁移合同，不把本次源码审查算成任何验收结果。

## 1. 交付结果与停止线

用户从已归属的 ax 点击“查看完整候选合同”，能看到完整的组织上下文、来源投影、原计划、全部槽位/规则/所选侧期望与保存截图；明确确认后保存一条 bc。刷新、重启后能找到同一 bc，并按需重新核验来源。来源失效时保留历史事实，展示当前无法完整复核。

这就是最小完整切片。draft 只指浏览器中的临时确认状态，不建 durable draft 表、不加 draft POST、不加审批 token、review session 服务、后台任务或另一套数据库。完整预览、明确写入、历史读取、核验图像和控制台交互属于同一 D2 闭环。

D2 不修改 D1 已冻结的 schema4 形状或摘要公式。候选都返回 `executionReady:false`，不生成批准、选用、dispatch、执行 run 或 BUG 账本；不接通旧 Browser runner。现有 Spec `ab/aa/as` 和 managed-spec 路径保持原合同。

前置条件是 D1 的真实门禁与精确提交完成。普通引擎继续新建 schema3、打开已有3/4，D2 不隐式迁移。schema3 的页面明确提示需要显式维护；不得因进入完整复核页或点击保存而迁移。

## 2. 已存在、可直接复用的部件

| 文件 / 接口 | 当前源码事实 | D2 的最小使用方式 |
|---|---|---|
| `browser-candidate-source.mjs: readBrowserCandidateSource(runId,{root,owner})` | genuine owner、目录 pin、FD/EOF/byte/stat 围栏、两次全引用读取、managed namespace 排除；返回 private `{snapshot,files}` | 所有 D2 来源读取均使用此严格 reader；不走正在开发的 display-only run reader，不把 display capability 转成 candidate/source 权限 |
| `browser-candidate-projection.mjs: verifyBrowserBaselineMaterial(material,{sourceSide})` | 已完整验证两侧所有实际引用、原报告语义与 PNG；返回 `{projection,preview,plan}`，preview 已有未脱敏的 observations/rules | 使用现有资格与语义算法，不另写 Browser verifier、不新增受信 verifier fingerprint |
| 同文件 `projectBrowserBaselineCandidate(...)` | public wrapper 仅返回 projection 和 preview | 保持 public 输出原样；新完整 builder 走 private verifier，不扩大 C DTO |
| `catalog-schema.mjs: browserBindingProjectionOf(ax)` | 能从严格已验证的 ax 重建全部旧来源投影 | fresh projection 与其完整比对，不只比 URL、sourceContentDigest 或所选 PNG |
| `browser-organized-candidate-identity.mjs` 与 `browserCandidateContentOf` | D1 已冻结组织/内容摘要域及七字段内容对象 | 直接复用，不复制第二套 production 哈希算法 |
| `catalog-schema.mjs` v4 | bc 严格字段、每 ax 最多一条、组织/来源/内容摘要、event 顺序与容量已有校验 | 只实现合法实体生产者，不改 schema，不把 bc 写入 `candidates` |
| `catalog.mjs: mutate / commit / revalidateBrowserBinding` | 写队列内 generation+revision CAS；strict schema/容量；previous 发布后 guard，最后 head 原字节复查再发布 | 复用 durable 写协议，新增 Browser candidate 方法；对完整 builder 增一条复用路径即可 |
| `catalog-api.mjs` | token gate 由 engine 保证；body16KiB、no-store/nosniff、固定错误白名单 | 增精确 D2 route 分支，保留旧分支的 segment/query/method 防线 |
| `console/src/acceptance-catalog.js` | 无 POST 重发、版本条件、未知提交结果标记 | 原样复用 transport / version；新响应仍需 candidate-specific 验证 |
| `acceptance-browser-bindings.js` / `AcceptanceBrowserBindings.vue` | 已有 ax 选择、sequence+epoch guard、Abort、Object URL 回收、流式大小/SHA 核对 | 复用模式与可分离的 bytes helper；C 的旧 artifact URL 和 summary validator 不可作为完整合同或新服务端核验 |
| `acceptance-baseline.js` | Spec 的 full preview、201关联验证、未知结果处理、ABA guard | 复用交互约定，不扩大其 `ab/spec/source` 输入或校验为 Browser union |

不必重建基础设施。建议新增两个专用产品文件：`core/src/acceptance/browser-candidate-review.mjs`（纯完整合同 builder / 安全候选视图）和 `console/src/acceptance-browser-candidates.js`（响应/输入/状态验证），加一个小 Vue 面板。可先在同一个纯 review 文件中保留 safe summary helper，避免仅为分层再拆三四个文件；只须保证完整和 safe 路径各有显式函数、互不 spread 对方对象。

### private verifier 的唯一必要增补

当前 verifier 已算出 `slots/rules/oracles/selectedEvidence/verified`，但返回时丢弃了 scope/oracles/selectedEvidence/verified。建议给 private 返回增加 `manifests: {scope, rules, selectedOracles, selectedEvidence, verifiedEvidence}`，都是本次验证已构建数据的 JSON copy；不返回 Buffer。public `projectBrowserBaselineCandidate` 继续 destructure 既有 projection/preview，旧 source golden 与 public response 不变。

完整 builder 使用这些 manifests 重算旧 component digests，并和 projection 相等，再构造完整 review。这样不从 preview 逆向猜测 oracle，也不把 D2 变成一份需要永久同步的摘要算法副本。旧 verifier 的规则排序、旧 sourcePlanDigest 的 JSON.stringify 字节约定、旧 sourceContentDigest 域都不能顺手调整。

## 3. 完整 DTO 与 display DTO 的明确区别

C 的 `browserBindingReadView`、`browserBindingPreviewView` 以及原 UI 不变：`presentation.kind='organization-review'`、`completeSourceProjection:false`，整段 query、步骤值、断言字面量、规则保持隐藏。

新完整复核 DTO 只由专用 D2 route 返回；建议冻结形状如下。字段名在实施时一次确定，后续测试依其精确形状验证，不能只检查 `completeSourceProjection===true`：

```text
{
  viewVersion:1, candidateContractVersion:1, schemaVersion:4,
  generationId, revision,
  candidateContent, contentDigest,
  organizationContext:{project,release,sourceBinding}, organizationContextDigest,
  sourceProjection,
  review:{
    sourcePlan, sourceStatus, sourceGate,
    scope, rules, selectedOracles, observations,
    selectedEvidence, verifiedEvidence,
    environment, verifierFingerprint, urlProof, limitations
  },
  completeness:{organizationContext:true,sourceProjection:true,
                selectedRequirements:true,rawArtifactsEmbedded:false},
  presentation:{kind:'browser-candidate-full-review',completeSourceProjection:true},
  diagnostics:{eligible:true,contentMatches:true,issues:[]},
  executionReady:false
}
```

完整是“规定的来源身份与所选侧合同字段完整”，不是全原报告/全部原始采集详情已嵌入。`rawArtifactsEmbedded:false` 保持诚实；全部实际引用通过的 metadata 仍在 verifiedEvidence 中，raw report / details / PNG Buffer 不自动进入 JSON。

完整 review 必须包含原 normalized plan 的两侧入口、精确有序 query、全部 routes/viewports/points/steps.value/assertion literals/thresholds/masks/timeouts；所选侧标识必须突出。scope/rules 每个槽位与 facet 都在，omissions 为空。selectedOracles 只来自明确选定侧的真实 bytes，不能拿原 report 的 baseline oracle 给 target 冒名。

保留 planned URL 精确、observedFinalUrl 已脱敏的证据区别；不推导 final query/redirect chain/部署冻结。完整 URL、selector、输入值、断言只用文本节点显示，不成为自动 href、日志、AI 输入或自动复制内容。

沿用原 preview 2MiB 上限；完整 envelope 单独12MiB上限，超限固定拒绝，不能裁前 N 条后仍允许保存。source/PNG/depth/nodes/characters 原限制不扩大。这个限额只需新模块常量与降低预算的测试入口，不做通用配额系统。

## 4. 三个摘要层与输入

`sourceProjection` 必须完整等于 `browserBindingProjectionOf(sourceBinding)`；旧 `sourceContentDigest` 不含组织，原义和 golden 完全不动。

```js
organizationContext = { project, release, sourceBinding }; // 三个完整、严格验证实体
organizationContextDigest = hashOrganizedBrowserCandidateValue('organization-context', organizationContext);
candidateContent = {
  candidateContractVersion:1, mode:'browser',
  projectId, releaseId, sourceBindingId,
  sourceContentDigest:sourceProjection.contentDigest, organizationContextDigest,
};
contentDigest = hashOrganizedBrowserCandidateValue('content', candidateContent);
```

project/release/ax 全实体及可选 buildRef 的缺失/存在都会绑定。bc.id、createdAt、actor、generation/revision 不进入 candidateContent，但实体及 event digest 仍覆盖其存储身份。无关 append 可能使 CAS 过期，不能改变内容摘要。

POST 仅接受 `{expectedGenerationId,expectedRevision,sourceBindingId,contentDigest}`。project 来自 route；run/side/release/sourceProjection/plan/rules/actor/time 全由服务器获取。拒绝额外字段、代理、accessor、空摘要和其他 ID 前缀。draft.confirmed 仅供前端控制用户动作，不能冒充服务器证明用户已读完全部合同。

两组独立条件都必须成立：目录 lineage 的 `{generationId,revision}` 和用户已复核完整内容的 `contentDigest`。D2 不照抄维护 CLI 的 headSHA/previousSHA/planDigest 输入；这些是显式迁移合同，不是普通候选写入的新前置基础设施。

## 5. Store 的最小接口与提交顺序

建议在现有 `createAcceptanceCatalogStore` 增三个领域方法与两个小图像 wrapper，collection 则用 `catalog.read()` 加纯 safe helper，无额外来源扫描：

```js
previewBrowserBaselineCandidate(projectId, sourceBindingId)
createBrowserBaselineCandidate(projectId, input)
readBrowserBaselineCandidate(projectId, candidateId)
readBrowserCandidatePreviewEvidence(projectId, sourceBindingId, {file, expectedContentDigest})
readBrowserBaselineCandidateEvidence(projectId, candidateId, {file, expectedContentDigest})
```

最后两个只是受控图像返回路径，返回 `{bytes,sha256}` 或同等 private 结构；不对普通 JSON 暴露。它们共用一次 materialize/review 私有函数，避免 store 对外 union 形状过宽。

共用 private helper `materializeBrowserReview(catalog, projectId, sourceBindingId)`：

1. 校验 schema4、project/ax 存在与严格归属、release 精确一致；不重新接受客户端 side/release。调用严格 Browser source reader，继承 genuine owner/root fence。
2. 运行现有 private verifier，完整 sourceProjection 与 ax 重建值比较；release.targetUrl 必须等于所选入口，含完整有序 query。
3. 从同次 material+verifier manifests 构建完整 review，重算组织/内容摘要与所有旧 component digests。assert owner/root 后返回 private material + complete DTO。

保存路径用现有 mutate：

1. parse/ID/digest 严格检查；进入写队列，对最新 head 的 generation/revision 做 CAS。错误 schema3、跨组织、不存在、每 ax 已有 bc、计数容量满等在 source/PNG 读取前拒绝。
2. 第一次 fresh materialize；比客户端 contentDigest。相同 ax 已有 bc 返回409 `CANDIDATE_ALREADY_EXISTS`，安全附 existingCandidateId；不自动返回201、不复制候选、不追加事件。
3. 仅生成 bc 的 D1 冻结11字段；写入 `catalog.browserCandidates`；返回 `kind:'browser-candidate-created'` 与 `candidate`，使现有 mutate 自动记单 event/revision+1。Spec maps 原样。
4. 容量、serialized JSON、strict v4、previous ancestor 检查后使用现有 commit。
5. `preCommitGuard` 重新执行完整 materialize，fresh sourceProjection + org/content 与待提交候选逐项一致；guard 不采纳新内容、不刷新 CAS、不重试。在同一个严格 catalog clone 重建组织，随后共享 commit 的 head 原 bytes CAS 保证初始组织版本未被替换。
6. 最后 head/previous 原 bytes 检查成功才发布 head。201 可以复用第一次已验证的完整 DTO（内容摘要与最后重核验相同）和服务器 event；不在提交后再跑可失败重读来把已提交误报失败。

早期失败应零 catalog 写。late guard 失败按照当前协议允许 previous 已旋转到旧 head，必须保证 head 未发布、新 bc/event/revision 不存在；不要为 D2 重写整个提交协议，也不要声称所有失败都零字节变更。

`preview...` 没有 durable record，源无效返回409。`read...` 有效时采用 `{...completeDto,candidate}`，来源无效返回200 `{schemaVersion,generationId,revision,candidate,review:null,diagnostics,executionReady:false}`；不得在失效响应里带上次 review 的残留块。历史事实保留。owner/root/catalog不可用继续503，不能落成200“来源变化”。不存在实体404、跨项目409。

## 6. API 与 schema3 行为

沿用首版 D API 路径；在 `catalog-api.mjs` 增精确路由表/分支即可，不新建框架或 catch-all router：

| 方法 / path（均在 `/api/acceptance/projects/:ap` 下） | 返回 |
|---|---|
| GET `/browser-source-bindings/:ax/candidate-preview` | fresh 完整 DTO，无写入 |
| POST `/browser-baseline-candidates` | 严格四字段输入；合法201+bc+event+完整 DTO |
| GET `/browser-baseline-candidates` | 只读 stored bc safe summary；source/PNG reads=0；currentSourceVerified=false |
| GET `/browser-baseline-candidates/:bc` | durable bc + fresh 完整 DTO，或 current source失效时 review:null |
| GET `/browser-source-bindings/:ax/candidate-preview/evidence/:file?expectedContentDigest=...` | 完整复核前的 selected screenshot/repeat |
| GET `/browser-baseline-candidates/:bc/evidence/:file?expectedContentDigest=...` | 已保存候选的相同图像语义 |

新 dedicated D2 endpoints 在 schema3 固定409 `CATALOG_MIGRATION_REQUIRED`（安全 reason=`SCHEMA4_REQUIRED`），不迁移。只需添加一个固定错误白名单项。project detail 可新增 safe `browserCandidates` 与 stored verification；schema3 给空数组及 `browserCandidateSupport:{available:false,requiredSchemaVersion:4}`，schema4 available=true，使UI无需主动失败请求才能提示维护。这些都是 transient DTO，不改变 schema4 存储格式。

`CANDIDATE_ALREADY_EXISTS` 可加一个严格 bc 前缀的 existingCandidateId 安全字段，方便丢响应后对账；不要把整个 error.details 任意透传。沿用 source/BASELINE_CHANGED、STALE_REVISION、owner、capacity 等已有错误。无需为了区分 stale generation 重构原 mutate 对两者统一报 STALE_REVISION 的既有行为，保持固定 currentGenerationId/currentRevision。

只有证据 route 允许 token + 单个 expectedContentDigest；其他旧路由仍只允许 token。重复 query、未知 query、错误 segments/ID、未定义方法均按原400/404/405+Allow规则拒绝；body16KiB、413、token gate、no-store/nosniff继续使用。

### 图像合同与当前 C loader 的边界

先严格 fresh capture+完整 review，与 expectedContentDigest/存储 bc 一致，再确认 file 恰是本 review 所选侧 observation 的 screenshot 或 repeat，返回同次 captured Map 的 Buffer。服务端不在校验后另开 path 读一次。拒绝 details/report/manifest/非所选侧/未引用/遍历/文件名编码变体，错误返回固定 JSON，失败不输出部分 PNG。

可复用 C 前端 fetch 的有界流、metadata.bytes、SHA256、Abort、Object URL 回收逻辑；D2 path builder 只指向上述专用路由。现有 C `browserEvidencePath` 指向通用 run artifact，客户端哈希核对有价值，但不足以承担新的服务器完整候选核验。PNG 12M pixels/64MiB 等预算不改；一次只加载一张，不后台预取全部图。

## 7. 控制台最小改动

新增 `AcceptanceBrowserCandidates.vue`，或在现有 Browser bindings 面板下的独立子区块。父 `AcceptanceCatalog.vue` 继续持 project/version/write 状态；ax行增加“查看完整候选合同”，已有 bc 显示“查看已保存候选”。无需重做整个工作台。

界面顺序：组织和来源身份→精确计划→全部槽位/规则/所选期望→按需截图/重复截图→完整摘要→明确确认→“记录 Browser 候选”。折叠可读，不删字段；不把敏感原值塞到浏览器路由/query、本地持久 storage 或普通项目列表。返回 C 核对页后完整明文清空。

新 helper 导出 `browserCandidateReviewState`、`buildBrowserCandidateInput`、`validateBrowserCandidateWrite`、`createBrowserCandidateReadGuard` 和专用 evidence path helper；依现有代码模式即可。201校验必须包括 bc字段/归属/sourceBindingId/三摘要、event kind/entity/project/revision/time、generation仍同请求且revision恰+1、executionReady=false。C safe DTO、缺任一完整块、omissions非空、计数不齐的响应均不能启用确认。

guard上下文至少含 `{projectId,sourceBindingId,candidateId,generationId,revision,selectionEpoch}` 加单调请求 sequence；打开完整 review、切project、切ax/bc、目录变化、关闭、Abort、卸载都清确认+完整明文+图像。A→B→A 即使ID回到A也拒绝旧响应。

保存收到合法201后马上记录成功事实。后续目录刷新失败显示“写入已确认，列表待刷新”，不能变成可重试 POST；丢失201或响应格式无效视为可能提交，禁用再次保存，先 GET stored collection 按 sourceBindingId+contentDigest 对账。对账有匹配bc就显示已保存；不匹配时刷新目录/完整合同并重新明确确认，不自动重发。

## 8. 必要测试矩阵与现有复用点

不重复为 D1 所有纯schema/迁移用例另建 D2套件。保留它们在完整Core回归中执行；D2新增覆盖真实接口、完整性边界和用户状态的测试。以下是计划，全部未运行。

| 位置 / 复用 | 必须新增的高价值断言 |
|---|---|
| 新 `acceptance-browser-candidate-review.test.mjs`；复用四份 frozen Browser fixtures、D1 independentHash/organizedHash | 4fixtures×2side资格和旧projection一致；raw query/steps/assertion/rules齐全；target oracle只用target；scope/manifests重算与旧digest相同；预算+1拒绝不截断；public projector/C DTO形状不变 |
| 新 `acceptance-browser-candidate-store.test.mjs`；复用 binding fixture/tree/openStore.afterPrevious/reseal | preview零写；合法保存恰1bc+1event+revision1；重启读同身份；schema3/坏输入/错归属/重复ax/满计数在PNG读取前失败；旧generation/revision/content摘要各自拒绝；同CAS并发仅1成功 |
| 同 store test 的中后期 guard | post-previous改plan、details/PNG、managed namespace/缺run；coherent reseal仍eligible但变projection也拒绝；head不变、previous符合旧协议；owner/root503；byte-identical跨捕获重建仍按旧内容边界接受 |
| 同 store test 的持久/错误 | source坏/缺时record保留且review:null；恢复原字节可再次复核；源及旧Spec/dispatch目录bytes不写；所有read不自动修复。不要把owner503吞为source200 |
| 新 `acceptance-browser-candidate-api.test.mjs`；复用现有 Router+真实 engine token harness | 200/201/400/404/405/409/413/503；token先于source读取；精确segments/query；no-store/nosniff；safe list零source读取、无raw值；existingCandidateId白名单；旧Spec请求传bc/browser仍拒绝 |
| 同 API test 的图像 | screenshot/repeat bytes和合同sha一致；wrongdigest/非所选侧/details/未引用/path变体拒绝；捕获内变更拒绝；先校验后只吐同一Map bytes；零live target请求 |
| 新 `console-acceptance-browser-candidates.test.mjs`；复用transport/guard测试习惯 | C DTO不能确认；完整块缺失/计数错拒绝；输入仅四字段；合法201关联；A→B→A/同ID不同lineage/Abort；201后刷新失败保留成功；丢响应先stored对账且POST调用恰一次 |
| 新 fresh UI smoke，现有C+Spec smoke回归 | 实际ax→完整合同→保存bc→刷新/重启→来源失效/恢复；桌面/手机字段可读、文本XSS不执行；两条fresh来源含baseline/target和原比较failed但所选侧健康；普通显示无raw，专用完整页raw齐全；截图endpoint字节独立核对 |

owner/FD/路径/JSON/PNG原始低层边界由既有 reader/projector tests承担；D2只加“调用方不会绕过它”和新增guard/PNG响应关联的必要交叉用例。全部 Spec approve/select/dispatch 和 C 原浏览器smoke按已有门禁跑，不能为了D2把它们输入union改宽或吞409。

## 9. Fresh 验收最短可信路径与证据

新增 `core/scripts/smoke-acceptance-browser-candidates-console.mjs` 和根/core package命令，沿用 C smoke 的受控 fixture/engine/browser/phase instrumentation。每轮新UUID，不拿D1混合历史旧截图替代D2实际保存bc。

1. 新隔离root创建schema4是harness的显式选择；另测schema3新接口409且树不变。真实采集mirror/regression，含有序query、fill值、text/attribute/url literal；建立project/release/ax。
2. 捕获后phase boundary启用target请求/禁止runner/fetch守卫。浏览器已在harness准备阶段启动；引擎重启是明确harness动作，不混入“服务动作无进程启动”的计数。后续复核/写入没有live目标请求。
3. 实际控制台打开full合同，逐关键字段验证raw值与所有槽位；普通C view保持隐藏。selected screenshot/repeat独立SHA核对。执行合法保存、staleCAS/wrongdigest/重复ax、切project/ax与保存后刷新。
4. 重启引擎后stored bc及摘要一致，单条重核验成功；对标记的隔离来源副本做字节破坏，record保留+review失效，恢复后复核可用。保留source/dispatch原件；不去目标站重新capture“修复”旧来源。
5. before/after树表明仅catalog/head-previous发生允许变化；Spec approvals/selections、managed-dispatch、执行run/tasks没有新增。所有`executionReady:false`。

保存完整合同JSON、safeDTO、201及拒绝HTTP、catalog前后bytes、source树SHA/stat、图像响应SHA、UI截图/errors、target-request日志、fresh采集索引与所有失败现场。fixture只用无真实凭据的测试字面量；完整review证据不自动进入AI或控制台日志。发布报告按“源码审查 / 单测 / 真实受控浏览器 / 精确提交CI”分证据级别，不声称外站通用可用。

## 10. 推荐实施顺序

先完成D1及当前display竞态热修复真实门禁；D2不抢先发布。随后按一个产品闭环实施：

1. private verifier返回已算manifests + 纯full builder；旧source/C输出golden不变。
2. catalog领域方法和图像wrapper + 专用精确API + safe list + fresh图像，复用现有提交/owner机制。
3. ax入口、完整review子区块、临时draft和明确保存；先完整DTO验证再启用按钮。
4. 必要targeted、原C/Spec回归、完整Core/build、fresh UI smoke，保留失败及最终对应源SHA。
5. 更新现行指南/导航与本片真实证据，提交D2，等待自身精确SHA CI，才讨论下一片Browser批准/选用。

不需要新的通用review平台、批准账本、异步job、跨进程缓存或source复制仓库。如果D2实施发现raw artifact持久保管/多用户授权/Browser执行oracle需要额外协议，留给对应后续片；不能用这些远期项阻塞本片“完整看清并明确保存”交付。

## 11. 本次只读核对的关键源码指纹

| 文件 | SHA256 |
|---|---|
| catalog-schema.mjs | af6be66714fd68dc56ff315ffff131c5ea45048e0c602843eb0d5358589f654c |
| browser-organized-candidate-identity.mjs | b70e07be5b6775a61cc0a66a2f108d4f6c9d5b60ea8f64ec6d7b022eeb80a6e4 |
| browser-candidate-projection.mjs | db83583bf8d696504285fdac4dcef312e48ce817de248f4213063d62eb3a1e44 |
| browser-candidate-source.mjs | b82f73f3fac835036600ac3b202eceb938adb9a4675aa9a8cf209c5ca32d8d8f |
| catalog.mjs | f14034f3f9ad458101fd4e68d30703c654053bdfeb3ae2d857330b00fdd2d80b |
| catalog-api.mjs | 7118c83172df100d94a4bbd605626984079b651a6bbe0bd6527700dc179d7c20 |
| console/src/acceptance-browser-bindings.js | cccb4c0f4cb15cc4a846d02bfad1174cb9e7ecaa6e4ec8ca2b6c9763358d02b3 |

以上是阅读时的工作树指纹，不是已发布D1/D2承诺。父任务若继续修改共享文件，实施前以最终D1/热修复提交核对接口；本设计不要求重跑本轮既有质量门或占用浏览器。

