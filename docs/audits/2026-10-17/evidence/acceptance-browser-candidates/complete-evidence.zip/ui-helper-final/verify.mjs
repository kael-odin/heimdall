import { spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = process.cwd(), output = dirname(fileURLToPath(import.meta.url));
const files = ['console/src/acceptance-browser-candidates.js', 'console/src/AcceptanceBrowserCandidates.vue',
  'console/src/AcceptanceBrowserBindings.vue', 'console/src/AcceptanceCatalog.vue', 'core/test/acceptance-browser-candidate-ui.test.mjs'];
const sources = files.map(path => ({ path, bytes: readFileSync(join(root, path)).length,
  sha256: createHash('sha256').update(readFileSync(join(root, path))).digest('hex') }));
writeFileSync(join(output, 'source-hashes.json'), JSON.stringify({ at: new Date().toISOString(), sources }, null, 2) + '\n');
const commands = [
  ['helper-syntax', ['--check', 'console/src/acceptance-browser-candidates.js']],
  ['helper-tests', ['--test', 'core/test/acceptance-browser-candidate-ui.test.mjs']],
];
let failed = false;
for (const [name, args] of commands) {
  const start = new Date().toISOString(), result = spawnSync(process.execPath, args, { cwd: root, encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 });
  writeFileSync(join(output, name + '.stdout.log'), result.stdout ?? ''); writeFileSync(join(output, name + '.stderr.log'), result.stderr ?? '');
  writeFileSync(join(output, name + '.command.json'), JSON.stringify({ command: [process.execPath, ...args], cwd: root, start,
    completed: new Date().toISOString(), exitCode: result.status, signal: result.signal, error: result.error?.message ?? null }, null, 2) + '\n');
  console.log(name + ': ' + result.status); if (result.status !== 0) { failed = true; console.log(result.stdout, result.stderr); }
}
try {
  const require = createRequire(join(root, 'console/package.json')), compiler = require('vue/compiler-sfc');
  const diagnostics = [];
  for (const path of files.filter(path => path.endsWith('.vue'))) {
    const source = readFileSync(join(root, path), 'utf8'), { descriptor, errors } = compiler.parse(source, { filename: path });
    if (errors.length) throw Error(path + ': ' + errors.join('\n'));
    const script = compiler.compileScript(descriptor, { id: path });
    const template = compiler.compileTemplate({ source: descriptor.template.content, filename: path, id: path,
      compilerOptions: { bindingMetadata: script.bindings } });
    if (template.errors.length) throw Error(path + ': ' + template.errors.join('\n'));
    diagnostics.push({ path, parsed: true, script: true, template: true });
  }
  writeFileSync(join(output, 'vue-syntax.stdout.log'), JSON.stringify(diagnostics, null, 2) + '\n');
  writeFileSync(join(output, 'vue-syntax.stderr.log'), ''); console.log('vue-syntax: 0');
} catch (error) {
  failed = true; writeFileSync(join(output, 'vue-syntax.stdout.log'), ''); writeFileSync(join(output, 'vue-syntax.stderr.log'), error.stack + '\n');
  console.log('vue-syntax: 1\n' + error.stack);
}
process.exitCode = failed ? 1 : 0;

