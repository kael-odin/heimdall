"""One read-only exact-attempt poll; never runs CI evidence or product code."""
from pathlib import Path
from datetime import datetime, timezone
import json
import math
import subprocess
import sys

base = Path(__file__).resolve().parent
queries = sorted((base / "queries").iterdir())
last = json.loads((queries[-1] / "jobs-command.json").read_bytes())
elapsed = (datetime.now(timezone.utc) - datetime.fromisoformat(last["queriedAt"])).total_seconds()
if elapsed < 60:
    print(json.dumps({"status": "wait-before-next-query", "seconds": math.ceil(60 - elapsed)}))
    raise SystemExit(2)
output = base / "queries" / str(len(queries) + 1).zfill(4)
output.mkdir()


def query(label, endpoint):
    args = ["gh", "api", endpoint]
    started = datetime.now(timezone.utc).isoformat()
    value = subprocess.run(args, capture_output=True)
    (output / (label + ".json")).write_bytes(value.stdout)
    (output / (label + ".stderr.log")).write_bytes(value.stderr)
    (output / (label + "-command.json")).write_text(json.dumps({"args": args, "startedAt": started,
        "queriedAt": datetime.now(timezone.utc).isoformat(), "exitCode": value.returncode}, indent=2) + "\n", encoding="utf-8", newline="\n")
    if value.returncode:
        raise RuntimeError("GitHub query failed; raw response preserved")
    return json.loads(value.stdout)


run = query("run", "repos/kael-odin/heimdall/actions/runs/39015344019/attempts/1")
assert run["id"] == 39015344019 and run["run_attempt"] == 1
assert run["head_sha"] == "0988fc333b3ec6abd857c4a5ccac5a5484906ee1"
jobs = query("jobs", "repos/kael-odin/heimdall/actions/runs/39015344019/attempts/1/jobs?per_page=100")
assert jobs["total_count"] == len(jobs["jobs"])
print(json.dumps({"query": str(output), "status": run["status"], "conclusion": run["conclusion"],
    "jobs": [{"id": j["id"], "name": j["name"], "status": j["status"], "conclusion": j["conclusion"],
        "active": [s["name"] for s in j.get("steps", []) if s["status"] == "in_progress"],
        "failed": [s["name"] for s in j.get("steps", []) if s["conclusion"] in ("failure", "timed_out", "cancelled")],
        "completedSteps": sum(s["status"] == "completed" for s in j.get("steps", [])),
        "totalSteps": len(j.get("steps", []))} for j in jobs["jobs"]]}))
