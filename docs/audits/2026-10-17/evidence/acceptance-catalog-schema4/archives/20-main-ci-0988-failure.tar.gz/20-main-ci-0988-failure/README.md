# Exact main CI archive — 0988fc3

本轮最终结论：**failure**。Linux 原生 display-head rename 专项通过；Acceptance console 的浏览器错误断言失败。后续 skipped 门禁不能算通过。

- Repository: `kael-odin/heimdall`
- Run: `39015344019` / attempt `1`
- Exact head: `0988fc333b3ec6abd857c4a5ccac5a5484906ee1`
- Created: `2026-10-17T07:53:56Z`; completed metadata updated: `2026-10-17T08:11:24Z`
- Authenticated run/job metadata: `queries/0002/run.json` / `queries/0002/jobs.json`

## Verified outcome

`pnpm test`: tests 2302, pass 2298, fail 0, cancelled 0, skipped 4, todo 0; duration 960935.479472 ms.

原生 Linux case `an actual Linux rename while a descriptor is open returns only that descriptor version` 在 Core 日志第 4049–4054 行实际执行，`ok 270`，耗时 4.140219 ms，无 `# SKIP`。

四项跳过用例：

- `ok 7 - real Windows reader holding a non-delete-sharing file handle releases after 180ms and replacement succeeds # SKIP` (Core log line 46)
- `ok 560 - real Windows non-share-delete reader releases and replacement retries successfully # SKIP` (Core log line 5888)
- `ok 1193 - Docker network-none delivery serves SSR, SPA and data-driven SPA bundles without a source workspace # SKIP` (Core log line 10552)
- `ok 1194 - Docker network-none delivery persists adapter writes in a volume after container recreation # SKIP` (Core log line 10558)

## Acceptance console failure

`run-logs/core (lint + test)/12_Acceptance console (real browser, local model stub).txt:12–28` 显示 smoke-acceptance-console.mjs:161 的 `assert.deepEqual(errors, [])` 因一条资源 409 错误失败。

`failure-artifact/acceptance-console/acceptance-failure.json:199–208` 保存：

```text
GET /api/acceptance/runs/ac-42fc98b0-9b17-494d-a2d8-f2a005628047
409 / MANAGED_RUN_INTEGRITY_FAILED
随后相同 GET 返回 200
```

其后 report、POST triage、PNG/JSON evidence 与 report.md 请求均为 200。截图显示移动端已完成的缺陷报告。此轮失败历史仍有效，不以最终页面可用覆盖。

artifact 只含失败 JSON、PNG、engine-error.log；没有 409 完整 body、原因/fence/syscall trace 或运行目录。不能从这些原件断言具体触发 fence。engine-error.log 只有 SQLite experimental warning 和服务启动地址。

## Job and step conclusions

| Job | ID | Conclusion |
|---|---:|---|
| core (e2e smoke, local fixture) | 117346199377 | success |
| console (build) | 117346199528 | success |
| core (lint + test) | 117346199583 | failure |

### core (e2e smoke, local fixture)

| Step | Name | Conclusion |
|---:|---|---|
| 1 | Set up job | success |
| 2 | Run actions/checkout@v7 | success |
| 3 | Run pnpm/action-setup@v6 | success |
| 4 | Run actions/setup-node@v7 | success |
| 5 | Run pnpm install --frozen-lockfile | success |
| 6 | Run pnpm exec playwright install --with-deps chromium | success |
| 7 | Run pnpm smoke | success |
| 8 | Acceptance detection benchmark (known truth fixtures) | success |
| 9 | Spec API benchmark (OpenAPI candidates and known truth) | success |
| 10 | Acceptance comparison benchmark (known retest and false-closure cases) | success |
| 18 | Post Run actions/setup-node@v7 | success |
| 19 | Post Run pnpm/action-setup@v6 | success |
| 20 | Post Run actions/checkout@v7 | success |
| 21 | Complete job | success |

### console (build)

| Step | Name | Conclusion |
|---:|---|---|
| 1 | Set up job | success |
| 2 | Run actions/checkout@v7 | success |
| 3 | Run pnpm/action-setup@v6 | success |
| 4 | Run actions/setup-node@v7 | success |
| 5 | Run pnpm install --frozen-lockfile | success |
| 6 | Run pnpm build | success |
| 10 | Post Run actions/setup-node@v7 | success |
| 11 | Post Run pnpm/action-setup@v6 | success |
| 12 | Post Run actions/checkout@v7 | success |
| 13 | Complete job | success |

### core (lint + test)

| Step | Name | Conclusion |
|---:|---|---|
| 1 | Set up job | success |
| 2 | Run actions/checkout@v7 | success |
| 3 | Run pnpm/action-setup@v6 | success |
| 4 | Run actions/setup-node@v7 | success |
| 5 | Run pnpm install --frozen-lockfile | success |
| 6 | Run pnpm lint | success |
| 7 | Run pnpm check:docs | success |
| 8 | Run pnpm exec playwright install --with-deps chromium | success |
| 9 | Run pnpm --dir ../console install --frozen-lockfile | success |
| 10 | Run pnpm --dir ../console build | success |
| 11 | Run pnpm test | success |
| 12 | Acceptance console (real browser, local model stub) | failure |
| 13 | Spec contract console (real browser, local API fixture) | skipped |
| 14 | Acceptance comparison console (explicit runs, integrity and CLI) | skipped |
| 15 | Acceptance project catalog (versions, explicit bindings and two-engine isolation) | skipped |
| 16 | Acceptance catalog migration (real v1 artifacts and browser continuity) | skipped |
| 17 | Spec baseline review (candidates, approvals, selections and source integrity) | skipped |
| 18 | Managed Spec preparation (immutable contract, replay and zero execution) | skipped |
| 19 | Managed Spec result reading (captured evidence and zero execution) | skipped |
| 20 | Owned acceptance recovery (startup barrier, restart and zero execution) | skipped |
| 21 | Managed Spec execution (fresh admission, real runner, BUG and cancel) | skipped |
| 22 | Managed execution UI (explicit click, durable recovery and stop) | skipped |
| 23 | Browser candidate source (fresh captures and explicit healthy side) | skipped |
| 24 | Browser private source reader (owner fences and unchanged originals) | skipped |
| 25 | Browser source bindings (fresh captures, explicit sides and source revalidation) | skipped |
| 26 | Browser source binding console (native HTTP, source review and verified evidence) | skipped |
| 27 | Preserve acceptance smoke failure diagnostics | success |
| 28 | Docker offline delivery (SSR + SPA + data SPA + adapter) | skipped |
| 54 | Post Run actions/setup-node@v7 | skipped |
| 55 | Post Run pnpm/action-setup@v6 | success |
| 56 | Post Run actions/checkout@v7 | success |
| 57 | Complete job | success |

## Read-only mechanism candidate

精确 head 的 engine-server.mjs:1376–1377 确认 GET 详情进入 readAcceptanceDisplayRun。managed-run-reader.mjs:158–161 尚有可能的 Linux 窄时序：open 取得旧 inode 后、第一次 fstat 前发生 atomic rename，旧 descriptor 的首次元数据已 nlink=0/ctime 改变；before/opened 同 inode导致 publishedHead=false，而 sameFile 因链接数/ctime差异为 false，从而 changed()。现有原生专项在首次正 readSync 之后才 rename，因此通过不能覆盖该时序。

以上为源码确认的候选时序，**尚不是这次 CI 409 的现场因果证明**；本归档任务没有新跑实验，没有修改脚本或产品。

## Evidence and integrity

- `downloads/run-39015344019-attempt-1-logs.zip`: 433680 bytes; SHA256 `a4e70f0d8664b4b40cf6ec99078c53d030c33c735885dde1c2c85a9cdc30d064`; 46 entries; CRC passed.
- `downloads/artifact-12093974658-acceptance-catalog-failure-1.zip`: 77500 bytes; SHA256 `4cb12bed22a76ff8f88087b83cd0653bbe2387394e24156bd3a936936955ac4b`; 3 entries; CRC passed.
- `safe-extraction-manifest.json`: original archives safely extracted after rejecting absolute/traversal/duplicate/link/special entry paths.
- `exact-head-source/`: git-show snapshots at the exact CI head.
- `gates.json`: complete final jobs and steps, with conclusion counts.
- `summary.json`: machine-readable verified conclusions and limitations.
- `focused-evidence.txt`: exact log line excerpts.
- `file-inventory.json` + `completion-receipt.json`: every archive file byte count and SHA chain, excluding the inventory/receipt themselves.

全部工作位于 ignored `_runs`。未执行下载内容；未修改产品/公开文档；未提交/push；未启动 Browser。
