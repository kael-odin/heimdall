import { mkdirSync, writeFileSync, readFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { createHash, randomUUID } from 'node:crypto';
const repo = resolve(import.meta.dirname, '../../../..');
const out = join(import.meta.dirname, 'attempt-' + randomUUID()); mkdirSync(out);
const files = ['core/src/acceptance/catalog-schema.mjs', 'core/src/acceptance/browser-organized-candidate-identity.mjs',
  'core/src/acceptance/browser-candidate-identity.mjs', 'core/test/acceptance-browser-organized-candidate-identity.test.mjs',
  'core/test/acceptance-catalog-schema-v4.test.mjs', 'core/test/fixtures/acceptance-browser-organized-candidate.mjs',
  'core/test/acceptance-catalog-schema.test.mjs'];
const manifest = () => files.map(file => { const bytes = readFileSync(join(repo, file)); return { file, bytes: bytes.length,
  sha256: createHash('sha256').update(bytes).digest('hex') }; });
const save = (file, value) => writeFileSync(join(out, file), typeof value === 'string' || Buffer.isBuffer(value)
  ? value : JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const args = ['--test', '--test-concurrency=1', 'core/test/acceptance-browser-organized-candidate-identity.test.mjs',
  'core/test/acceptance-catalog-schema-v4.test.mjs', 'core/test/acceptance-catalog-schema.test.mjs',
  'core/test/acceptance-catalog-schema-v3.test.mjs'];
save('command.json', { executable: process.execPath, args, cwd: repo, scope: 'pure-schema-and-identity-only', startedAt: new Date().toISOString() });
save('source-before.json', manifest());
const started = Date.now();
const result = spawnSync(process.execPath, args, { cwd: repo, encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 });
save('stdout.log', result.stdout ?? ''); save('stderr.log', result.stderr ?? '');
save('exitcode.json', { exitCode: result.status, signal: result.signal, error: result.error?.message ?? null, elapsedMs: Date.now() - started });
save('source-after.json', manifest());
process.stdout.write(JSON.stringify({ out, exitCode: result.status, stdout: (result.stdout ?? '').slice(-12000), stderr: result.stderr ?? '' }, null, 2) + '\n');
process.exitCode = result.status ?? 1;
