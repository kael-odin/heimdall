# D1 Schema4 显式维护：证据归档清单与独立审计草稿

状态：**暂存于 ignored `_runs`；不是公开审计定稿，不代表最终整仓门禁通过，也不是合入或发布批准。**

审查日期为 2026-10-17。审查工作树是 `C:\Users\44548\.codex\worktrees\managed-spec-provenance\heimdall`，分支 `codex/browser-candidates-schema4`，基准 HEAD 为 `b42826e4956d491b461bbd00af3d18b2ad702ad5`。D1 变更仍在工作树中，没有提交。本轮独立审查仅读取代码、日志和现有截图，重算证据摘要并写入本 ignored 目录；没有启动 Browser、夹具或引擎，没有编辑产品、脚本或公开文档，没有 stage/commit/push。

## 1. 当前可确认的结果与不可扩大的边界

第三轮 fresh Browser Schema4 模式已通过 **19/19**，包装进程 `exit0`、`signal:null`、`sourcesUnchanged:true`。运行时间为 2026-10-17 06:42:42–06:43:33 UTC（香港时间 14:42:42–14:43:33）。本轮独立重算确认：548 个源码条目的 before/after 快照完全相同，且当前条目的 SHA256/bytes 仍匹配该快照；迁移后 runtime 的 71 个文件路径、bytes、SHA256、nlink、mtimeNs、ctimeNs 与保存的 afterTree 完全一致。运行后的 HTTP/UI 树快照也与之完全一致。

该结果证明的是受控本地目标下，真实 Mirror/Regression 引擎 worker 捕获、Browser 来源归属/只读核对，以及混合历史显式 3→4 迁移的本轮合同。两个 Browser 原始比较结果均真实保留 `failed`。它不证明 Browser candidate 写入、批准、选用或执行器已经实现；最终 `browserCandidates` 仍为空，`executionReady:false`，显示 DTO 明确 `presentation.completeSourceProjection:false`。

Spec 草稿、candidate/approval/select/cancel/reselect 以及三条 dispatch/lifecycle 是明确的 harness setup。两条生命周期使用 owner-bound writer，原因分别是 `CANCELLED`、`ENGINE_RESTARTED`；另一条仅 `prepared-only`。它们不是本轮 Spec executor 或 Browser executor 的真实执行结果。Spec `approved:false` 草稿走 blocked/no-request 分支。

## 2. 精确证据入口

下表路径均相对该 D1 工作树。归档清单保持原路径，没有复制、移动、覆盖或删除原始证据。

| 证据组 | 精确入口 | 本次复核结论 |
| --- | --- | --- |
| fresh Browser 第三轮 gate | `core/workspace/_runs/d1-integration-20261017/fresh-browser-v4-opaque-origin-4677dcfd-ffee-4f53-8809-e9fab989aeb2/` | command/stdout/exitcode/summary 相互对应，exit0，源码快照一致 |
| fresh Browser 第三轮 runtime | `core/workspace/_runs/browser-bindings-console-smoke-f944e26d-fbb3-4801-a0e0-04dbd16715b9/` | 19/19、10 张截图、71 文件 byte/stat 树、catalog/来源/派发完整现场 |
| fresh Browser 首次失败 gate | `core/workspace/_runs/d1-integration-20261017/fresh-browser-v4-initial-8ade882c-97d9-4fdd-9b41-d34debee7226/` | exit1，sourcesUnchanged:true，保留 stderr 与快照 |
| fresh Browser 首次失败 runtime | `core/workspace/_runs/browser-bindings-console-smoke-b66606af-cdf4-4bb9-871f-0bc30424801c/` | 保留 failure、截图/DOM、日志与 runtime；失败为树比较遗漏另一份 v3 来源前像 |
| fresh Browser 第二次失败 gate | `core/workspace/_runs/d1-integration-20261017/fresh-browser-v4-two-preimages-88183da7-4319-47c3-ae8d-f3c1b3949e9a/` | exit1，sourcesUnchanged:true，保留 stderr 与快照 |
| fresh Browser 第二次失败 runtime | `core/workspace/_runs/browser-bindings-console-smoke-43a91425-70a1-43a5-b7bc-ce15c2bb3db6/` | 保留 opaque-origin localStorage pageerror 与现场 |
| legacy 迁移首次失败 gate | `core/workspace/_runs/d1-integration-20261017/legacy-migration-smoke-ebbf2c73-ee60-4489-b7f5-972f801b45f2/` | exit1，sourcesUnchanged:true；旧格式尚未引入的表被误要求为空对象 |
| legacy 迁移首次失败输出 | `core/workspace/_runs/acceptance-catalog-migration/2026-10-17T06-16-11.542Z-9e9865f6/` | failure、CLI 确认/拒绝日志、引擎日志仍保留；旧版尚未保存 disposable runtime 副本 |
| legacy 迁移修正 gate | `core/workspace/_runs/d1-integration-20261017/legacy-migration-smoke-fixed-d9d96f77-fe42-4adf-8fd1-6b2a7e1e524f/` | exit0，sourcesUnchanged:true |
| legacy 迁移修正输出 | `core/workspace/_runs/acceptance-catalog-migration/2026-10-17T06-17-14.070Z-a58c6f8f/` | 21/21，零旧目标请求；早于新的 finally 归档补强，不能充当该补强实跑证据 |
| 集成定向测试 | `core/workspace/_runs/d1-integration-20261017/targeted-3e910d79-a639-4729-ad94-2751be85dadb/` | stdout 为 149 tests / 149 pass / 0 fail / 0 skip，exit0 |
| 根条目预算修正测试 | `core/workspace/_runs/d1-integration-20261017/root-capacity-983e6568-aca2-4efd-abe1-24f28206871c/` | stdout 为 90 tests / 90 pass / 0 fail / 0 skip，exit0 |
| 本轮已有语法门禁 | `core/workspace/_runs/d1-integration-20261017/syntax-1e8bfd35-d913-448b-8ded-1f6bb6ff1620/` | 456 file(s) OK，exit0 |
| 维护专项原件 | `core/workspace/_runs/catalog-maintenance-specialist-20261017/attempt-0eb37baa-724e-499e-8dd4-9990669448bd/` | 保留原 81 项专项 command/stdout/exitcode/源码快照；本轮没有重跑 |
| store 独立审查 | `core/workspace/_runs/d1-store-independent-20261017.md` | 原 P2 根条目预算问题、独立失败探针和修复复核均保留 |
| 原根条目失败探针 | `core/workspace/_runs/d1-store-independent-14c75139-1b29-4e00-8800-9885e197aae1/root-entry-capacity.json` | 保留 4095/4096 原失败事实；不以修复后的结果覆盖 |
| 修正后的独立边界探针 | `core/workspace/_runs/d1-store-independent-fixed-1767e73c-7996-476b-a406-cf1026c3884e/independent-fixed-results.json` | 4095/4096 两次 fresh preview 写前拒绝，schema1+4091 条目完整迁移成功 |
| 混合 smoke 原审查记录 | `core/workspace/_runs/d1-mixed-smoke-independent-20261017.md` | 保留两项原证据缺口与 DTO 层级修复历史；本草稿补记其后的真实通过结果 |

## 3. 本轮独立重核的关键数值

- fresh Browser checks 为 19 项，全部严格为 `true`，`status:passed`；gate stdout 指向的 runtime 与上述 UUID 一致。
- 源码快照范围为 `core/src` 184、`core/scripts` 34、`core/test` 291、`console/src` 34、`.github/workflows` 2，以及三个 package 文件，共 548 个条目。本结论仅涵盖列出的文件内容，不把未列入的依赖、构建目录或整个环境冻结等同于源码快照。
- 最终 catalog 为 schema4，含 3 个 project、3 条 Browser binding、1 个 Spec candidate、1 个 Spec approval、3 条 Spec selection；Browser candidate 为 0。
- 三条 dispatch 分别标记 `prepared-only`、`owner-bound-lifecycle-writer-without-runner/CANCELLED`、`owner-bound-lifecycle-writer-without-runner/ENGINE_RESTARTED`。它们随其源文件一并位于 71 文件快照中。
- 迁移计划登记并新增两份不同的 v3 来源前像；本轮逐份重算实际文件 SHA256 与计划 SHA 一致。rolling previous 与 head 的原始字节也由 fixture 断言核对。
- target 日志实有 16 条请求，与 capture 计数完全相同；binding/setup/maintenance/restart/HTTP/UI 读取未增加此受控 target 请求。它不是全进程网络隔离证明。
- 2 组 Browser 来源的 before/after 原始文件摘要一致。3 个创建的 Blob URL 均已撤销。
- 10 张声明的截图均存在。独立查看 schema4 桌面 1440 深色与 390 手机浅色截图，均显示来源核对、失败原比较、查询隐藏与“此次核对不批准、选用或启动运行”的边界；layout JSON 的对应 documentWidth 均未超过 viewport。
- pageErrors 为空。全程保留 1 条故障注入的预期 502 资源错误；不能写成“全程零 HTTP 资源错误”。源码围栏固定 Schema4 阶段起点，要求该阶段无新增预期资源错误。

## 4. 保留的失败及修正点

| 类型 | 原事实 | 修正与证据 |
| --- | --- | --- |
| 产品维护预算 P2 | root 已有 4095/4096 条目时原 preview 误报 eligible，apply 准备文件后才拒绝，并留下使后续 preview 继续受阻的条目 | 预算整链新增前像、缺失 previous、1 个发布临时槽，纳入 planDigest 并稳定重核计数；90 项与独立边界探针关闭；原失败保留 |
| legacy harness 断言 | 较旧 schema 未引入 `browserSourceBindings` 时实际为 undefined，原 verifier 误与 `{}` 比较而失败 | 按 original/candidate 实际拥有字段核对，新增表仅在自己的格式步骤要求空表；修正后 legacy21/21 |
| 混合 harness 前像比较 | v3 头与 previous 都可产生不同前像；原 fixture 只排除头前像，真实树多出合法 previous 前像导致首次失败 | 以 preview 全部 preimage source 清单决定新文件；每份 head/previous 原始字节都核 SHA/内容；第三轮通过 |
| Browser harness token 初始化 | 为停止旧引擎进入 `about:blank` 后，init script 直接访问 opaque-origin localStorage 产生 pageerror，第二轮失败 | 只在 http/https document 设置 token；第三轮 pageErrors 为空 |
| 原静态审查证据缺口 | 迁移后的重启/HTTP/UI 没有完整 byte/stat 树围栏，且全局资源错误豁免可能吞掉新阶段错误 | 重启后及最终 HTTP/UI 后双重完整树比较；固定资源错误起点并要求无新增；第三轮实际完成 |
| 新增 DTO 断言层级 | 曾误写 `read.preview.completeSourceProjection`，实际生产字段位于 presentation 下 | 已修正为 `read.preview.presentation.completeSourceProjection`；第三轮实际通过 |

除根预算 P2 外，上述失败来自验证脚本/夹具适配。不能把它们抹掉，也不能把验证脚本失败表述为已经证明的产品来源损坏。

## 5. legacy smoke 新 finally 全场景归档审查

当前代码为 `core/scripts/smoke-acceptance-catalog-migration.mjs:575-594`，当前 SHA256 `32703d1295c2b5638ee11b6c59b430df01b4dea22578de3d4cd8261e1dc49296`。本轮对该文件执行 `node --check`，exit0；**没有实跑新增归档代码**。

源码确认的顺序为：输出目录必须全新且通过空目录检查后置 `outputReady`；`createDataRoot` 在 mkdtemp 后立即登记到 `tempRoots`，再建立/复制 fixture。因此部分 setup 失败也留下已登记根。主 try 成功或 catch 失败均进入 finally；先关闭 Browser、停止所有 engine 并保存日志，再逐个处理全部已登记根。

每个根先通过 realpath 与 tmpdir 范围/固定前缀检查；随后枚举文件内容摘要，复制到全新 `OUT/runtime-scene-N`（拒绝覆盖现存路径），比较 copied 与 source SHA 树，并再次重读 source 确认未变化，落 `runtime-scene-N-digests.json` 后才删除原 disposable 根。正常完整运行预计产生 N=0 的 B1 主场景、N=1 的缺失来源副本、N=2 的完整原生 V2 Spec 场景；早期失败只归档此前已经建立的根。不存在先 rm 再复制的路径。

这里的保真合同是路径与普通文件内容摘要；`treeDigests` 不比较 nlink、mtime/ctime、inode 或目录属性，不能把复制目录说成保留了所有原文件状态。若 `browser.close`、`stop` 或归档本身异常，顺序 finally 可在处理全部根之前结束；尚未处理的 disposable 根保留在原 tmp 位置，不代表已经写入 OUT。复制、核验或 digest 保存失败发生在该根 rm 之前，因此不能声称失败后仍完成了所有归档，也没有证据支持先删后丢现场。

现有 legacy21/21 对应脚本 SHA 为 `e47496f4f7622914200a34fcd7b3c7157e78cc772eb870db1eab083841d4acac`，早于新 finally 归档补强；其输出不存在 `runtime-scene-*`。旧首次失败和修正成功均只能沿用其当时保存的 JSON/日志/截图/摘要，不能追溯补成完整 runtime 场景。因此归档补强目前证据等级为**源码确认 + 语法检查**，成功与失败场景的归档实跑仍是待办。

## 6. 证据级别

| 级别 | 本草稿采用的内容 | 限制 |
| --- | --- | --- |
| 本地真实流程 | 第三轮真实 Mirror/Regression worker、原生 Browser 归属控件、来源三种证据角色、桌面/手机版、显式 schema4 混合迁移与重启读取 | 受控本地目标；Browser candidate/批准/选用/执行器未实现；Spec 归属/生命周期 setup 明确为 harness |
| 离线复现/专项 | genuine-owner 根条目边界独立探针、维护/CLI/兼容专项149与90、legacy21 | 没有重跑这些旧专项；依据保留的命令/退出码/stdout及已有独立探针，不能代替最终整仓门禁 |
| 源码确认 | 新 legacy finally 归档、维护期间禁止来源读取的同步 FS guard 边界、显示 DTO 无批准权 | guard 只覆盖被替换的同步 string-path API 与 preview/apply 时段，不是任意 async/FD/URL I/O 沙箱 |
| 主流程同步，未在本 D1 审查独立复验 | 主树 display-only 热修复的阶段状态 | 该热修复尚未合入本 D1 工作树；不得将主树阶段结果转写成本 D1 结果 |

## 7. 尚未合入的热修复与最终门禁

主流程同步的状态是：主树 display-only 热修复已冻结 4 文件，29 项专项为 28 pass/1 Linux skip，合并 targeted 为 79 total/77 pass/2 skip，主树 lint450、build 与 fresh 原 smoke（27,627 ms）通过，完整 Core 刚启动；**没有 commit，D1 尚未包含该热修复**。这些是协调状态，独立 D1 审查未读取/复跑主树结果，不能称为最终门禁通过。

D1 此时的基准 HEAD 仍是上述 b42826e，产品与脚本变更未提交。当前 evidence 只覆盖本快照。最终合入前仍需由主流程处理 C display-only 热修复，固定最终源码身份，再执行适合最终变更的 Core/构建/Browser/文档门禁，并核对所发布证据与最终源码一致。新 legacy finally 的成功/失败归档行为也没有真实演练证据。

截至本草稿，**最终整仓门禁未过，尚未合入/提交/推送 D1，不能发布“全部完成”结论。**

## 8. 归档清单文件与摘要

本目录 `evidence-inventory.json` 逐文件记录 11 个证据组，共 **514 文件 / 10,488,282 bytes** 的路径、bytes 和 SHA256；覆盖所有列出的 gate/runtime 目录。根条目探针只把关键 JSON 与独立审查报告纳入索引，其数千空 filler 文件的 disposable 根继续保留原位，没有在本清单逐项穷举。清单本身不搬运原证据，也不替代其完整现场。

`verification.json` 记录本次独立重算的 548 源码匹配、71 文件 byte/stat 匹配、19/19、来源失败结果、两份前像、Blob 生命周期、请求计数及所有 gate 尝试的实际退出结果。公开定稿时应保留本表的失败尝试与证据边界，不能只复制第三轮成功目录。

| 本目录文件 | SHA256 |
| --- | --- |
| `evidence-inventory.json` | `fe415cf6a53244eae0466dbe36767f8d2c934bdd60f7c168c49a64a65ba8809f` |
| `verification.json` | `2ed22106b9b5562063ef92fa53ac919b0cf3f1d2d156b83c5228e973b65de41a` |

当前关键源码 SHA256：

| 文件 | SHA256 |
| --- | --- |
| `core/src/acceptance/catalog.mjs` | `f14034f3f9ad458101fd4e68d30703c654053bdfeb3ae2d857330b00fdd2d80b` |
| `core/src/acceptance/catalog-schema.mjs` | `af6be66714fd68dc56ff315ffff131c5ea45048e0c602843eb0d5358589f654c` |
| `core/src/acceptance/catalog-maintenance-cli.mjs` | `d9f908c2608c12ab650590d67bb956c60ee46e29677b5c34e8cb4aa6f7dfc999` |
| `core/scripts/fixtures/catalog-v4-compatibility.mjs` | `eda8c0aa21cb30bf076be09c705932b80991c617cd31417a94288f0d589e2098` |
| `core/scripts/smoke-acceptance-browser-bindings-console.mjs` | `1241f91147ac3f6180f4a6fe180ecd5b6dd99b4c8bae91ad58998b7e93787d7f` |
| `core/scripts/smoke-acceptance-catalog-migration.mjs` | `32703d1295c2b5638ee11b6c59b430df01b4dea22578de3d4cd8261e1dc49296` |
| `core/src/acceptance/browser-binding-view.mjs` | `c2c71f8f3b7f513e923c7927a5fd030c321473753a8b5d9acad055d5172ddba7` |
