import { spawn } from 'node:child_process';
import { randomUUID, createHash } from 'node:crypto';
import { mkdirSync, writeFileSync, readFileSync, openSync, closeSync } from 'node:fs';
import { resolve, join } from 'node:path';
const repo = resolve(import.meta.dirname, '../../..', '..');
const out = join(import.meta.dirname, 'attempt-' + randomUUID()); mkdirSync(out);
const files = ['core/src/acceptance/catalog.mjs', 'core/src/acceptance/catalog-maintenance-cli.mjs', 'core/src/acceptance/catalog-schema.mjs', 'core/src/acceptance/browser-organized-candidate-identity.mjs',
  'core/test/acceptance-catalog-migration.test.mjs', 'core/test/acceptance-catalog-schema3-migration.test.mjs', 'core/test/acceptance-catalog-maintenance-cli.test.mjs'];
const snapshot = () => files.map(file => { const bytes = readFileSync(join(repo, file)); return { file, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') }; });
const save = (name, value) => writeFileSync(join(out, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
save('source-before.json', snapshot());
const args = ['--test', '--test-concurrency=1', ...files.filter(file => file.includes('/test/'))];
save('command.json', { executable: process.execPath, args, cwd: repo, startedAt: new Date().toISOString() });
const stdout = openSync(join(out, 'stdout.log'), 'wx'), stderr = openSync(join(out, 'stderr.log'), 'wx'), started = Date.now();
const child = spawn(process.execPath, args, { cwd: repo, stdio: ['ignore', stdout, stderr] });
const result = await new Promise(resolve => { child.once('error', error => resolve({ exitCode: null, error: error.message })); child.once('exit', (exitCode, signal) => resolve({ exitCode, signal })); });
closeSync(stdout); closeSync(stderr); save('exitcode.json', { ...result, wallTimeMs: Date.now() - started }); save('source-after.json', snapshot());
console.log(JSON.stringify({ out, ...result, wallTimeMs: Date.now() - started }, null, 2)); process.exitCode = result.exitCode ?? 1;
