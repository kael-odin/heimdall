# Acceptance display head race evidence packer

This ignored workspace is preparation only. The packer never runs Core, Browser, UI, build, lint, Git mutation, or other product commands.

The root agent must append every final gate and runtime directory to `inputs.json`, clear `pendingGroups`, and optionally add public documents with `{"source":"workspace/relative/or/absolute/file.md","destination":"README.md"}`. Destination is one new filename. All earlier failed and abandoned attempts remain separate complete-tree groups.

Read-only inventory (exit 2 means a pending or unavailable input):

```powershell
python core/workspace/_runs/acceptance-display-head-evidence-packer-20261017/pack.py --plan
```

After inputs are frozen, the root agent can create the package explicitly:

```powershell
python core/workspace/_runs/acceptance-display-head-evidence-packer-20261017/pack.py --pack --output docs/audits/2026-10-17/evidence/acceptance-display-head-race
```

The output directory must not exist. All files use exclusive creation. Output and every source directory must be disjoint. On failure, partial output and `FAILED.json` remain for inspection; reruns need a new output path and must not overwrite or delete the previous attempt.

The package creates its own `.gitattributes` containing `* -text -whitespace` before other output. It is included in completion checksums and prevents Git text normalization from changing these exact evidence bytes; the repository's root attributes remain untouched.

`INDEX.json` schema v1 lists every source directory, note, full manifest path, archive path, counts, and archive/manifest SHA256. `manifests/<id>.json` contains `entries[]`: root path `.`, all directories including empty ones, and every file with its relative path, byte length, SHA256, mode, and mtime. `archives/<id>.tar.gz` uses member prefix `<id>/`; no exclusion rules apply. Symlinks, junction/reparse points, and special filesystem objects fail explicitly.

The packer compares each complete source tree before and after packing and again before completion. It reads every tar member back, rejects missing, extra, or duplicate entries, and verifies each decompressed file length, SHA256, and mode. Source manifests index mtimeNs metadata; tar metadata is not claimed to preserve exact nanosecond timestamps or every filesystem directory attribute. It compares all 542 source entries from the full-Core source guard before and after. The final four-stage runner group separately retains its original five-file guard and frozen copies. `controls/pack.py`, `controls/inputs.json`, and `controls/source-guard.json` are exact byte copies, and `17-packer-source` independently preserves the complete preparation tree. Optional published documents are copied exactly and indexed.

`COMPLETED.json` is written last, only after all checks, and contains SHA256 for every prior output file. `source-before.json` and `source-after.json` describe the 542 source-guard entries. A separate verifier should recompute archives and manifests independently instead of trusting success booleans. Native Linux fd-open atomic rename remains an explicitly unexecuted platform case; the archived Windows syscall model does not upgrade that evidence level. The archived `13-docs-links` result is an intermediate gate; root validates final publication links separately.
