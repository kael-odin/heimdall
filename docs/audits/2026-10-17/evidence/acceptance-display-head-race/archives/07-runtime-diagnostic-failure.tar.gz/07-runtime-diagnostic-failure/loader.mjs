import { registerHooks } from 'node:module';
registerHooks({ load(url, context, nextLoad) {
  const result = nextLoad(url, context);
  if (!url.endsWith('/src/acceptance/managed-run-reader.mjs')) return result;
  let source = String(result.source);
  const declaration = `const diagnosticDescriptor = fs.openSync(process.env.HEIMDALL_HEAD_TRACE_OUT + '/head-' + process.pid + '.jsonl', 'wx');
const diagnostic = (event, value = {}) => fs.writeSync(diagnosticDescriptor, JSON.stringify({time:new Date().toISOString(),event,...value}, (_key,item)=>typeof item==='bigint'?String(item):item)+'\\n');`;
  source = source.replace('const headPublications = new WeakSet();', 'const headPublications = new WeakSet();\n' + declaration);
  source = source.replace("const fail = (reason = 'INVALID_INPUT') => { throw", "const fail = (reason = 'INVALID_INPUT') => { diagnostic('fail', {reason, stack:new Error().stack}); throw");
  source = source.replace('catch (cause) { if (cause instanceof ManagedAcceptanceRunError)', "catch (cause) { diagnostic('boundary-error',{code:cause?.code,message:cause?.message,stack:cause?.stack}); if (cause instanceof ManagedAcceptanceRunError)");
  source = source.replace("const error = new ManagedAcceptanceRunError('MANAGED_RUN_INTEGRITY_FAILED');", "const error = new ManagedAcceptanceRunError('MANAGED_RUN_INTEGRITY_FAILED'); diagnostic('changed-file',{runId:run.runId,name,checkingPublication,previous,current,stack:error.stack});");
  source = source.replace('headPublications.add(error);', "diagnostic('retryable-publication',{runId:run.runId,name}); headPublications.add(error);");
  return {...result, source};
} });
