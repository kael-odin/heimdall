# Display head independent review evidence

Result: PASS. All four existing controlled fixture probes must reject with 409 / MANAGED_RUN_INTEGRITY_FAILED.

Git HEAD: b42826e4956d491b461bbd00af3d18b2ad702ad5
Source hashes: source-sha256.json (before and after execution).
Command: command.json; raw output: stdout.txt / stderr.txt; process status: exit.json.

| Probe | Status | Code | Publications | Mutations | Result |
|---|---:|---|---:|---:|---|
| pre-directory | 409 | MANAGED_RUN_INTEGRITY_FAILED | 1 | 1 | PASS |
| pre-inplace | 409 | MANAGED_RUN_INTEGRITY_FAILED | 1 | 1 | PASS |
| delayed-inplace | 409 | MANAGED_RUN_INTEGRITY_FAILED | 1 | 1 | PASS |
| second-publication | 409 | MANAGED_RUN_INTEGRITY_FAILED | 2 | 0 | PASS |

Only temporary fixture directories were mutated; all were cleaned. No product/test source edits, network access, browser runs, Core suite, staging or commits.
All evidence files were created with flag wx in a new ignored directory.
