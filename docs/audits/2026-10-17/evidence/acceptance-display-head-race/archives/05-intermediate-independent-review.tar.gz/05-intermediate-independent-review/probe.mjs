import fs, * as ns from 'node:fs';
import { syncBuiltinESMExports } from 'node:module';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { createAcceptanceRun, listAcceptanceRuns } from '../../../src/acceptance/store.mjs';
import { writeAtomicFileSync } from '../../../src/acceptance/atomic-file.mjs';

// Independent controlled fixtures only. No HTTP, browser, Core suite or source edits.
// Each mutation occurs only after closeSync has closed the matching reader fd.
const input={baselineUrl:'https://baseline.test',targetUrl:'https://target.test'};
const encode=x=>JSON.stringify(x)+'\n', outcomes=[];
for(const mode of ['pre-directory','pre-inplace','delayed-inplace','second-publication']) {
 const root=ns.realpathSync(ns.mkdtempSync(join(tmpdir(),'heimdall-review-v3-')));
 createAcceptanceRun({...input,name:'one'},{root});
 createAcceptanceRun({...input,name:'two'},{root});
 const ids=ns.readdirSync(root).filter(x=>x.startsWith('ac-'));
 const aDir=join(root,ids[0]),aPath=join(aDir,'manifest.json'),bPath=join(root,ids[1],'manifest.json');
 const a=JSON.parse(ns.readFileSync(aPath)),b=JSON.parse(ns.readFileSync(bPath));
 const open=fs.openSync,close=fs.closeSync,handles=new Map();
 let aCloses=0,bCloses=0,busy=false,pubs=0,mutations=0,outcome;
 fs.openSync=(path,...args)=>{const fd=open(path,...args);handles.set(fd,String(path));return fd;};
 fs.closeSync=fd=>{
  close(fd);
  const path=handles.get(fd);handles.delete(fd);
  if(busy)return;
  busy=true;
  try {
   if(path===aPath){
    aCloses++;
    if(mode==='delayed-inplace'&&aCloses===3){
     ns.writeFileSync(aPath,encode({...a,progress:{kind:'late-inplace'}}));mutations++;
    }
   }
   if(path===bPath){
    bCloses++;
    if(bCloses===1){
     if(mode==='pre-directory'){
      ns.renameSync(aDir,join(root,'.parked-a'));
      ns.cpSync(join(root,'.parked-a'),aDir,{recursive:true});mutations++;
     }
     if(mode==='pre-inplace'){
      ns.writeFileSync(aPath,encode({...a,progress:{kind:'early-inplace'}}));mutations++;
     }
     writeAtomicFileSync(bPath,encode({...b,progress:{kind:'publication-1'}}));pubs++;
    }else if(mode==='second-publication'&&bCloses===2){
     writeAtomicFileSync(bPath,encode({...b,progress:{kind:'publication-2'}}));pubs++;
    }
   }
  }finally{busy=false;}
 };
 syncBuiltinESMExports();
 try {
  const rows=listAcceptanceRuns({root});
  outcome={mode,status:200,aCloses,bCloses,pubs,mutations,rows:rows.map(x=>({runId:x.runId,progress:x.progress}))};
 }catch(error){
  outcome={mode,status:error.status,code:error.code,aCloses,bCloses,pubs,mutations};
 }finally{
  fs.openSync=open;fs.closeSync=close;syncBuiltinESMExports();
  ns.rmSync(root,{recursive:true,force:true});
 }
 outcome.pass=outcome.status===409&&outcome.code==='MANAGED_RUN_INTEGRITY_FAILED'
  &&outcome.pubs===(mode==='second-publication'?2:1)
  &&outcome.mutations===(mode==='second-publication'?0:1);
 outcomes.push(outcome);
 console.log(JSON.stringify(outcome));
}
if(outcomes.length!==4||outcomes.some(row=>!row.pass))process.exitCode=1;
