# C: ordinary legacy head publication hotfix

Date: 2026-10-17. Base HEAD: `b42826e4956d491b461bbd00af3d18b2ad702ad5`.

The final implementation is frozen in this directory's `frozen/` tree. No files were staged, committed or pushed by this subtask. Complete Core execution and publishing belong to the parent task.

## Final behavior and boundary

The ordinary acceptance worker publishes progress and completion by replacing `manifest.json` and `report.json` atomically. These are live display heads. Applying a fixed source/evidence byte fence to their public polling requests can return an integrity 409 while the worker is publishing normally.

The final change introduces a separate `createAcceptanceDisplayReadScope()` and `readAcceptanceDisplayRun()` capability. Only the run list and the single-run GET detail route use it. `readAcceptanceRun()` retains its original strict meaning; engine finalization, job projection, triage/artifact preliminary checks, source snapshots, recovery, and evidence captures continue to use strict reads.

A display scope returns the first stable bytes captured for each ordinary legacy head. If the underlying path is subsequently replaced by a regular single-link file with a different filesystem object identity, that replacement is never adopted in the same request. The next request reads its own new version. There is no retry, scope recreation, cache across requests, writer repair, or extended timeout. A display response may therefore lag a concurrent publication by one poll.

The same display scope still verifies all root/run identities and the original managed dispatch context. Managed head changes, same-inode writes, permission changes, hardlinks, disappearance, symlinks and namespace replacement remain errors. Metadata pins also reject an in-place change to a replacement inode after it has first been observed. A display capability is rejected by fixed-scope assertion, arbitrary file capture and managed completed-snapshot capture, so it cannot become an artifact/source permission.

For a replacement while the original file descriptor is open, only the old descriptor's original bytes may be returned. Detached-inode link/ctime metadata changes are allowed only when the path has a different safe ordinary legacy head and the descriptor's identity, mode, size and mtime remain unchanged. The actual opened size is independently bounded before allocation. The strict reader continues to reject this situation.

Changed tracked files:

- `core/src/acceptance/managed-run-reader.mjs`
- `core/src/acceptance/store.mjs`
- `core/src/engine-server.mjs`
- `core/test/acceptance-display-head-race.test.mjs`

The original `core/scripts/smoke-acceptance-console.mjs` was not changed. Its console-error assertion, HTTP behavior, fixture, and timeouts remain in force.

## Final frozen validation

All commands, stdout, stderr, exit codes, source snapshots and before/after SHA256 are in this directory. `summary.json` records `sourceBytesUnchanged: true`.

| Gate | Result | Duration |
|---|---|---:|
| Four reader/consumer/batch/race test files, serial | 79 total, 77 pass, 0 fail, 2 skip | 93,164 ms |
| Core syntax check | exit 0 | 19,147 ms |
| Console production build | exit 0 | 1,021 ms |
| Fresh original acceptance-console smoke | exit 0 | 27,627 ms |

The new race file alone has 29 cases: 28 pass, 0 fail, 1 skip on Windows. Its actual Linux open-descriptor rename case is intentionally skipped on Windows; a separate syscall metadata model verifies the corresponding display/strict branches locally. Native Linux execution remains a CI responsibility. The other skip in the combined gate belongs to the pre-existing targeted suite.

The fresh smoke exercised the real console, child worker, report/evidence retrieval, Markdown download, reload, desktop and mobile. `fresh-smoke/browser-checks.json` has `status: passed`, all 17 smoke checks true, and `pageErrors: []`. The fixture's acceptance result is intentionally `gate: failed` with 39 measured checks and 3 detected bugs; this is the expected behavior, not an acceptance-system failure. AI triage used the existing local model mock. This is controlled local evidence, not external model or production-site acceptance.

Final SHA256 (identical before/after):

| File | SHA256 |
|---|---|
| `core/src/engine-server.mjs` | `a38b5a4a650b7ba693ccbbe8caa4509bf7743c25412d188409b04351ea78b2d1` |
| `core/src/acceptance/managed-run-reader.mjs` | `04916edde625b5b02fba6541833375faace00ed32bb840bad71b25a74a063a47` |
| `core/src/acceptance/store.mjs` | `0d53346020669bb5a12ef0b966e7afb9632cbd1bdd1cd40cac01efffc5c02054` |
| `core/test/acceptance-display-head-race.test.mjs` | `08f09a154fdd0977cf9b248d82bf846fc8e7f5cddd2cdac9ef5090551daa5545` |
| Original smoke | `7f31c24de47518cdf840e47907dabe087637bacba08c4d2b1bdddfe4ce606e9c` |

## Independent final review

Final evidence directory: `core/workspace/_runs/display-original-bytes-independent-final-2026-10-17T06-53-51-327Z-a5790224/`.

The same 12 independent probes passed, exit 0, empty stderr. Its five source hashes match this runner's `source-before.json` exactly before and after execution. The probe SHA256 is `2c70d1c8b7206156bddc359540af428d947d80128c50fbf19be93b86df1bd5e6`.

The probes cover earlier A directory/in-place/late changes combined with B publication, two normal B publications retaining the original response bytes, in-place changes to an observed replacement, completion staying at the captured running version until the next request, strict-reader refusal, display capability isolation, strict source snapshot, managed A plus ordinary B publication, and display/strict detached-inode metadata models. The latter is explicitly a Windows offline syscall model, not a native Linux run. No new reproducible defect was found in that review.

## Preserved failed and superseded attempts

These paths are evidence history, not the final implementation's passing gates. All are under the main repository's ignored `core/workspace/_runs/` directory, except the original CI archive in `docs/audits`.

| Directory | Meaning |
|---|---|
| `acceptance-head-publication-hotfix-5c823b3b-e1b6-4885-8cc4-84286bec90e6` | Initial deterministic race reproduction: 7 cases, 3 pass, 4 fail. |
| `acceptance-head-publication-hotfix-5cf063fd-9574-46b3-b0a7-b2ef9c20bd2f` | First narrow retry implementation: its then-current 7 cases passed; superseded. |
| `acceptance-head-publication-validation-1792216819119` | Early retry implementation's four local gates passed; independent review later found batch adoption concerns, so this is not the final gate. |
| `display-head-independent-review-2026-10-17T06-19-59-486Z-04502ce1` | Intermediate retry batch review, four probes; superseded by final display review. |
| `acceptance-head-publication-final-1792217991701` | Retry-with-fixed-eligibility-tail version: targeted/lint/build passed, but fresh original smoke failed at line 161 with one GET list 409. |
| `display-head-runtime-diagnostic-1792218399330` | Fresh original smoke with an ignored runtime loader for error stacks; reproduced that list 409 without editing tracked source or assertions. `head-796.jsonl` shows another normal atomic manifest replacement during `checkingPublication: true` in the eligibility tail. |
| `display-original-bytes-independent-2026-10-17T06-47-26-939Z-dff5fa85` | First independent display harness; fixture-only URL slash/parking-metadata mistakes were preserved. |
| `display-original-bytes-independent-corrected-2026-10-17T06-49-36-198Z-ad853f60` | Corrected same 12 probes passed; `fixture-correction.json` documents the harness corrections. Store formatting was later restored to its original three lines. |
| `display-original-bytes-independent-final-2026-10-17T06-53-51-327Z-a5790224` | Same 12 probes rerun against the exact final hashes; final independent review. |

The original C CI is run `39005540253`, attempt 1, HEAD `b42826e4956d491b461bbd00af3d18b2ad702ad5`. Its Linux Core gate passed (2273 total / 2269 pass / 4 skip), but its original acceptance-console smoke failed on a transient GET detail 409. Its archived output has no complete 409 body or per-request timestamp, so this work does not claim the exact original CI fence instant is known. The controlled original-race reproduction and the later instrumented local failure establish the mechanism and why repeated fixed-scope retry was insufficient.

The parent's original CI archive is `docs/audits/2026-10-17/evidence/browser-bindings-console-ci-main-b42826e/` (351 files / 7,265,009 bytes; COMPLETED SHA256 `f0045d5f606ea2ed1ca901072956a2e3464689555ee13da0e8678f57faf9fa5b`). Final archival/publishing and complete Core validation remain with the parent.
