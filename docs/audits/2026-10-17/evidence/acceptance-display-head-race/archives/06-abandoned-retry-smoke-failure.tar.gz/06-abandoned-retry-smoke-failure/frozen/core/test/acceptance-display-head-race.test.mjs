import test from 'node:test';
import assert from 'node:assert/strict';
import nativeFs, * as fs from 'node:fs';
import { syncBuiltinESMExports } from 'node:module';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { createAcceptanceRun, updateAcceptanceRun, finishAcceptanceRun, readAcceptanceRun,
  listAcceptanceRuns, readAcceptanceSnapshot } from '../src/acceptance/store.mjs';
import { createAcceptanceReadScope, captureAcceptanceRunHead,
  isAcceptanceHeadPublicationConflict } from '../src/acceptance/managed-run-reader.mjs';
import { writeAtomicFileSync } from '../src/acceptance/atomic-file.mjs';
import { managedExecutionFixture } from '../scripts/fixtures/managed-execution.mjs';
import { createManagedAcceptanceRun, updateManagedAcceptanceProgress } from '../src/acceptance/managed-run-store.mjs';

const integrity = { code: 'MANAGED_RUN_INTEGRITY_FAILED', status: 409 };
const encode = value => JSON.stringify(value, null, 2) + '\n';
function fixture(t) {
  const root = fs.realpathSync(fs.mkdtempSync(join(tmpdir(), 'heimdall-display-head-race-')));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const manifest = createAcceptanceRun({ name: 'display publication race', baselineUrl: 'https://baseline.test',
    targetUrl: 'https://target.test' }, { root });
  return { root, runId: manifest.runId, path: join(root, manifest.runId, 'manifest.json'), manifest };
}
function duringClose(path, publish, read) {
  const open = nativeFs.openSync, close = nativeFs.closeSync, descriptors = new Map();
  let publications = 0, publishing = false;
  nativeFs.openSync = (current, ...args) => {
    const descriptor = open(current, ...args);
    descriptors.set(descriptor, String(current));
    return descriptor;
  };
  nativeFs.closeSync = descriptor => {
    close(descriptor);
    const current = descriptors.get(descriptor); descriptors.delete(descriptor);
    // Publish only after the reader closes its descriptor: Windows correctly
    // denies rename while that handle is open. This models the child writer
    // winning between a stable capture and the next scope fence.
    if (current === path && !publishing) {
      publishing = true;
      try { publications += publish(publications) ? 1 : 0; }
      finally { publishing = false; }
    }
  };
  syncBuiltinESMExports();
  try { return { value: read(), publications }; }
  finally { nativeFs.openSync = open; nativeFs.closeSync = close; syncBuiltinESMExports(); }
}
function listOrder(root) {
  const handle = fs.opendirSync(root), names = []; let entry;
  try { while ((entry = handle.readSync())) if (entry.name.startsWith('ac-')) names.push(entry.name); }
  finally { handle.closeSync(); }
  return names;
}

test('replacement between lstat and the first open is recaptured with the triggering file pinned', t => {
  const f = fixture(t), open = nativeFs.openSync; let publications = 0;
  nativeFs.openSync = (path, ...args) => {
    if (String(path) === f.path && !publications) {
      publications++;
      writeAtomicFileSync(f.path, encode({ ...f.manifest, progress: { kind: 'before-first-open' } }));
    }
    return open(path, ...args);
  };
  syncBuiltinESMExports();
  try {
    const value = readAcceptanceRun(f.runId, { root: f.root });
    assert.equal(publications, 1); assert.deepEqual(value.progress, { kind: 'before-first-open' });
  } finally { nativeFs.openSync = open; syncBuiltinESMExports(); }
});

for (const list of [false, true]) test(`${list ? 'list' : 'detail'} display recaptures an atomic legacy progress publication in a fresh complete scope`, t => {
  const f = fixture(t);
  const { value, publications } = duringClose(f.path, count => {
    if (count) return false;
    updateAcceptanceRun(f.runId, { progress: { kind: 'observing', completed: 1, total: 2 } }, { root: f.root });
    return true;
  }, () => list ? listAcceptanceRuns({ root: f.root }).find(row => row.runId === f.runId)
    : readAcceptanceRun(f.runId, { root: f.root }));
  assert.equal(publications, 1);
  assert.equal(value.status, 'running');
  assert.deepEqual(value.progress, { kind: 'observing', completed: 1, total: 2 });
  assert.deepEqual(JSON.parse(fs.readFileSync(f.path)).progress, value.progress);
  assert.deepEqual(fs.readdirSync(join(f.root, f.runId)), ['manifest.json']);
});

test('display recaptures a legitimate report plus completed manifest publication without mixing heads', t => {
  const f = fixture(t);
  const { value, publications } = duringClose(f.path, count => {
    if (count) return false;
    finishAcceptanceRun(f.runId, { mode: 'mirror', name: f.manifest.name, checks: [],
      endedAt: new Date().toISOString() }, { root: f.root });
    return true;
  }, () => readAcceptanceRun(f.runId, { root: f.root }));
  assert.equal(publications, 1); assert.equal(value.status, 'completed');
  const saved = JSON.parse(fs.readFileSync(f.path));
  assert.deepEqual(value, saved); assert.match(value.reportSha256, /^[a-f0-9]{64}$/);
});

test('a first report publication between the absence capture and fence is recaptured as one complete display batch', t => {
  const f = fixture(t), reportPath = join(f.root, f.runId, 'report.json'); let closes = 0;
  const { value, publications } = duringClose(f.path, () => {
    if (++closes !== 2) return false;
    writeAtomicFileSync(reportPath, encode({ runId: f.runId, status: 'completed', checks: [] })); return true;
  }, () => readAcceptanceRun(f.runId, { root: f.root }));
  assert.equal(publications, 1); assert.equal(value.status, 'running');
  assert.deepEqual(value, f.manifest);
  assert.deepEqual(JSON.parse(fs.readFileSync(reportPath)), { runId: f.runId, status: 'completed', checks: [] });
});

test('publication during the final scope fence also discards earlier captured display heads', t => {
  const f = fixture(t); let closes = 0;
  const { value, publications } = duringClose(f.path, () => {
    if (++closes !== 3) return false;
    updateAcceptanceRun(f.runId, { progress: { kind: 'final-fence-publication' } }, { root: f.root }); return true;
  }, () => readAcceptanceRun(f.runId, { root: f.root }));
  assert.equal(publications, 1); assert.deepEqual(value.progress, { kind: 'final-fence-publication' });
});

test('a second publication during retry eligibility fails shut without adopting the continuously changing writer', t => {
  const f = fixture(t); let publications = 0;
  assert.throws(() => duringClose(f.path, () => {
    publications++;
    writeAtomicFileSync(f.path, encode({ ...f.manifest, progress: { publication: publications } }));
    return true;
  }, () => readAcceptanceRun(f.runId, { root: f.root })), integrity);
  assert.equal(publications, 2);
  assert.deepEqual(JSON.parse(fs.readFileSync(f.path)).progress, { publication: 2 });
});

test('display recapture stops after three complete list batches even when every publication is individually stable', t => {
  const f = fixture(t), opendir = nativeFs.opendirSync; let attempts = 0, publishedAttempt = 0;
  nativeFs.opendirSync = (path, ...args) => {
    if (String(path) === f.root) attempts++;
    return opendir(path, ...args);
  };
  syncBuiltinESMExports();
  try {
    assert.throws(() => duringClose(f.path, () => {
      if (publishedAttempt === attempts) return false;
      publishedAttempt = attempts;
      writeAtomicFileSync(f.path, encode({ ...f.manifest, progress: { publication: attempts } })); return true;
    }, () => listAcceptanceRuns({ root: f.root })), integrity);
  } finally { nativeFs.opendirSync = opendir; syncBuiltinESMExports(); }
  assert.equal(attempts, 3); assert.equal(publishedAttempt, 3);
  assert.deepEqual(JSON.parse(fs.readFileSync(f.path)).progress, { publication: 3 });
});

test('stable malformed heads and managed markers are still rejected after an atomic publication', t => {
  for (const malformed of [true, false]) {
    const f = fixture(t); let bytes;
    assert.throws(() => duringClose(f.path, count => {
      if (count) return false;
      bytes = malformed ? '{malformed' : encode({ ...f.manifest, managed: {} });
      writeAtomicFileSync(f.path, bytes); return true;
    }, () => readAcceptanceRun(f.runId, { root: f.root })), integrity);
    assert.equal(fs.readFileSync(f.path, 'utf8'), bytes);
  }
});

test('in-place mutations do not qualify as an atomic publication retry', t => {
  const f = fixture(t); let publications = 0;
  assert.throws(() => duringClose(f.path, () => {
    publications++; fs.writeFileSync(f.path, encode({ ...f.manifest, progress: { changed: true } })); return true;
  }, () => readAcceptanceRun(f.runId, { root: f.root })), integrity);
  assert.equal(publications, 1);
});

test('in-place permission changes and new hardlinks do not qualify as head publication retries', t => {
  for (const hardlink of [false, true]) {
    const f = fixture(t); let publications = 0;
    try {
      assert.throws(() => duringClose(f.path, () => {
        publications++;
        if (hardlink) fs.linkSync(f.path, join(f.root, f.runId, 'linked-head.json'));
        else fs.chmodSync(f.path, 0o400);
        return true;
      }, () => readAcceptanceRun(f.runId, { root: f.root })), integrity);
      assert.equal(publications, 1);
      assert.deepEqual(JSON.parse(fs.readFileSync(f.path)), f.manifest);
    } finally { fs.chmodSync(f.path, 0o600); }
  }
});

for (const replacement of ['run', 'root', 'dispatch']) test(`${replacement} namespace replacement is never adopted as a head publication`, t => {
  const f = fixture(t); let publications = 0;
  const parked = replacement === 'root' ? f.root + '.original' : join(f.root, '.original-run');
  t.after(() => { if (replacement === 'root') fs.rmSync(parked, { recursive: true, force: true }); });
  assert.throws(() => duringClose(f.path, () => {
    publications++;
    if (replacement === 'dispatch') {
      writeAtomicFileSync(f.path, encode({ ...f.manifest, progress: { changed: true } }));
      fs.mkdirSync(join(f.root, 'managed-spec-dispatches', 'v1'), { recursive: true });
    } else {
      const original = replacement === 'root' ? f.root : join(f.root, f.runId);
      fs.renameSync(original, parked); fs.cpSync(parked, original, { recursive: true });
    }
    return true;
  }, () => readAcceptanceRun(f.runId, { root: f.root })), integrity);
  assert.equal(publications, 1);
});

test('real reserved managed progress keeps its original fixed-scope refusal during publication', async t => {
  const f = await managedExecutionFixture({ paths: ['/healthy'] }); t.after(() => f.cleanup());
  const prepared = await f.prepareOnly(), ref = { operationId: prepared.envelope.operationId, dispatchSha256: prepared.record.sha256 };
  const options = { owner: f.owner, assertActive: () => true };
  createManagedAcceptanceRun(ref, options);
  const path = join(f.root, prepared.envelope.runId, 'manifest.json'); let publications = 0;
  assert.throws(() => duringClose(path, () => {
    publications++;
    updateManagedAcceptanceProgress(ref, { progress: { kind: 'acceptance-check', completed: 1, total: 1 } }, options); return true;
  }, () => readAcceptanceRun(prepared.envelope.runId, { root: f.root })), integrity);
  assert.equal(publications, 1); assert.equal(f.requests.length, 0);
  assert.equal(readAcceptanceRun(prepared.envelope.runId, { root: f.root }).progress.completed, 1);
});

for (const mutation of ['run-directory', 'in-place', 'permissions', 'hardlink']) test(`a later legacy publication cannot hide an earlier ${mutation} change in the display batch`, t => {
  const f = fixture(t);
  createAcceptanceRun({ baselineUrl: 'https://baseline.test', targetUrl: 'https://target.test' }, { root: f.root });
  const ids = listOrder(f.root), firstPath = join(f.root, ids[0], 'manifest.json'), secondPath = join(f.root, ids[1], 'manifest.json');
  const first = JSON.parse(fs.readFileSync(firstPath)), second = JSON.parse(fs.readFileSync(secondPath));
  let publications = 0;
  try {
    assert.throws(() => duringClose(secondPath, () => {
      publications++;
      if (mutation === 'run-directory') {
        const directory = join(f.root, ids[0]), parked = join(f.root, '.earlier-run');
        fs.renameSync(directory, parked); fs.cpSync(parked, directory, { recursive: true });
      } else if (mutation === 'in-place') fs.writeFileSync(firstPath, encode({ ...first, progress: { kind: 'in-place-tamper' } }));
      else if (mutation === 'permissions') fs.chmodSync(firstPath, 0o400);
      else fs.linkSync(firstPath, join(f.root, ids[0], 'linked-head.json'));
      writeAtomicFileSync(secondPath, encode({ ...second, progress: { kind: 'legitimate-publication' } })); return true;
    }, () => listAcceptanceRuns({ root: f.root })), integrity);
    assert.equal(publications, 1);
    assert.deepEqual(JSON.parse(fs.readFileSync(secondPath)).progress, { kind: 'legitimate-publication' });
  } finally { fs.chmodSync(firstPath, 0o600); }
});

test('two ordinary head publications may recapture the complete list without retaining earlier display values', t => {
  const f = fixture(t);
  createAcceptanceRun({ baselineUrl: 'https://baseline.test', targetUrl: 'https://target.test' }, { root: f.root });
  const ids = listOrder(f.root), firstPath = join(f.root, ids[0], 'manifest.json'), secondPath = join(f.root, ids[1], 'manifest.json');
  const first = JSON.parse(fs.readFileSync(firstPath)), second = JSON.parse(fs.readFileSync(secondPath));
  const { value, publications } = duringClose(secondPath, count => {
    if (count) return false;
    writeAtomicFileSync(firstPath, encode({ ...first, progress: { kind: 'first-publication' } }));
    writeAtomicFileSync(secondPath, encode({ ...second, progress: { kind: 'second-publication' } })); return true;
  }, () => listAcceptanceRuns({ root: f.root }));
  assert.equal(publications, 1);
  assert.deepEqual(value.find(row => row.runId === ids[0]).progress, { kind: 'first-publication' });
  assert.deepEqual(value.find(row => row.runId === ids[1]).progress, { kind: 'second-publication' });
});

test('eligibility keeps earlier observed bytes fixed until its final complete-batch fence', t => {
  const f = fixture(t);
  createAcceptanceRun({ baselineUrl: 'https://baseline.test', targetUrl: 'https://target.test' }, { root: f.root });
  const ids = listOrder(f.root), firstPath = join(f.root, ids[0], 'manifest.json'), secondPath = join(f.root, ids[1], 'manifest.json');
  const first = JSON.parse(fs.readFileSync(firstPath)), second = JSON.parse(fs.readFileSync(secondPath)); let closes = 0;
  assert.throws(() => duringClose(secondPath, () => {
    if (++closes === 1) {
      writeAtomicFileSync(secondPath, encode({ ...second, progress: { kind: 'legitimate-publication' } })); return true;
    }
    if (closes === 2) fs.writeFileSync(firstPath, encode({ ...first, progress: { kind: 'late-in-place-change' } }));
    return false;
  }, () => listAcceptanceRuns({ root: f.root })), integrity);
  assert.equal(closes, 2);
  assert.deepEqual(JSON.parse(fs.readFileSync(firstPath)).progress, { kind: 'late-in-place-change' });
});

test('a later legacy publication cannot make an earlier managed progress change eligible for display recapture', async t => {
  const f = await managedExecutionFixture({ paths: ['/healthy'] }); t.after(() => f.cleanup());
  const prepared = await f.prepareOnly(), ref = { operationId: prepared.envelope.operationId, dispatchSha256: prepared.record.sha256 };
  const options = { owner: f.owner, assertActive: () => true };
  createManagedAcceptanceRun(ref, options);
  const legacy = createAcceptanceRun({ baselineUrl: 'https://baseline.test', targetUrl: 'https://target.test' }, { root: f.root });
  const path = join(f.root, legacy.runId, 'manifest.json'), scope = createAcceptanceReadScope({ root: f.root });
  captureAcceptanceRunHead(prepared.envelope.runId, { scope });
  assert.throws(() => duringClose(path, count => {
    if (count) return false;
    updateManagedAcceptanceProgress(ref, { progress: { kind: 'acceptance-check', completed: 1, total: 1 } }, options);
    updateAcceptanceRun(legacy.runId, { progress: { kind: 'legitimate-publication' } }, { root: f.root }); return true;
  }, () => captureAcceptanceRunHead(legacy.runId, { scope })), error => {
    assert.equal(error.code, integrity.code); assert.equal(error.status, integrity.status);
    assert.equal(isAcceptanceHeadPublicationConflict(error), false); return true;
  });
  assert.equal(f.requests.length, 0);
});

test('fixed scopes and source snapshots retain their original fail-closed byte fences', t => {
  const f = fixture(t);
  assert.throws(() => duringClose(f.path, count => {
    if (count) return false;
    writeAtomicFileSync(f.path, encode({ ...f.manifest, progress: { changed: true } })); return true;
  }, () => {
    const scope = createAcceptanceReadScope({ root: f.root });
    const head = captureAcceptanceRunHead(f.runId, { scope }); scope.assertCurrent(); return head;
  }), integrity);
  finishAcceptanceRun(f.runId, { mode: 'mirror', status: 'completed', baselineUrl: f.manifest.baselineUrl,
    targetUrl: f.manifest.targetUrl, checks: [] }, { root: f.root });
  assert.equal(readAcceptanceSnapshot(f.runId, { root: f.root }).integrity.valid, true);
  const result = duringClose(f.path, count => {
    if (count) return false;
    writeAtomicFileSync(f.path, encode({ ...JSON.parse(fs.readFileSync(f.path)), triageAvailable: true })); return true;
  }, () => readAcceptanceSnapshot(f.runId, { root: f.root }));
  assert.equal(result.publications, 1); assert.equal(result.value.integrity.valid, false);
});
