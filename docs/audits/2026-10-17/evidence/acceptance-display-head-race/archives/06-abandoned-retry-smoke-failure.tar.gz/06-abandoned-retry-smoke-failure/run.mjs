import * as fs from 'node:fs';
import { spawn, spawnSync } from 'node:child_process';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
const OUT = dirname(fileURLToPath(import.meta.url)), ROOT = process.cwd(), startedAt = new Date().toISOString();
const put = (name, value) => fs.writeFileSync(join(OUT, name), typeof value === 'string' ? value : JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const sources = ['core/src/acceptance/managed-run-reader.mjs', 'core/src/acceptance/store.mjs',
  'core/test/acceptance-display-head-race.test.mjs', 'core/scripts/smoke-acceptance-console.mjs'];
const facts = () => sources.map(path => { const bytes = fs.readFileSync(resolve(ROOT, path));
  return { path, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') }; });
const before = facts(); put('source-before.json', before);
for (const path of sources) {
  const destination = join(OUT, 'frozen', path); fs.mkdirSync(dirname(destination), { recursive: true });
  fs.writeFileSync(destination, fs.readFileSync(resolve(ROOT, path)), { flag: 'wx' });
}
put('git-head.txt', spawnSync('git', ['rev-parse', 'HEAD'], { cwd: ROOT, encoding: 'utf8', windowsHide: true }).stdout);
put('git-status.txt', spawnSync('git', ['status', '--short', '--branch'], { cwd: ROOT, encoding: 'utf8', windowsHide: true }).stdout);
put('tracked.patch', spawnSync('git', ['diff', '--', ...sources], { cwd: ROOT, encoding: 'utf8', windowsHide: true }).stdout);
put('browser-environment.json', { classification: 'Absent', reason: 'Browser plugin not available',
  path: 'Existing regular Playwright repository acceptance:smoke', viewports: ['1440x1000', '390x844'],
  browserSlot: 'Parent confirmed idle before final runner started' });
const definitions = [
  { name: '01-targeted-tests', cwd: ROOT, args: ['--test', '--test-reporter=tap', '--test-concurrency=1',
    'core/test/acceptance-display-head-race.test.mjs', 'core/test/acceptance-managed-run-reader.test.mjs',
    'core/test/acceptance-managed-consumers.test.mjs', 'core/test/acceptance-managed-batch-edges.test.mjs'] },
  { name: '02-lint', cwd: join(ROOT, 'core'), args: ['scripts/check-syntax.mjs'] },
  { name: '03-console-build', cwd: join(ROOT, 'console'), args: ['node_modules/vite/bin/vite.js', 'build'] },
  { name: '04-fresh-acceptance-console-smoke', cwd: ROOT, args: ['core/scripts/smoke-acceptance-console.mjs', join(OUT, 'fresh-smoke')] }
], stages = [];
async function run(def) {
  const stageStartedAt = new Date().toISOString(), started = Date.now();
  console.log(JSON.stringify({ event: 'stage-start', name: def.name, startedAt: stageStartedAt }));
  put(def.name + '.command.json', { cwd: def.cwd, command: process.execPath, args: def.args, startedAt: stageStartedAt });
  const out = fs.openSync(join(OUT, def.name + '.stdout.log'), 'wx'), err = fs.openSync(join(OUT, def.name + '.stderr.log'), 'wx');
  const result = await new Promise(resolveResult => {
    const child = spawn(process.execPath, def.args, { cwd: def.cwd, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    child.stdout.on('data', bytes => fs.writeSync(out, bytes)); child.stderr.on('data', bytes => fs.writeSync(err, bytes));
    let spawnError;
    child.on('error', error => { spawnError = String(error.message); });
    child.on('close', (exitCode, signal) => resolveResult({ exitCode, signal, ...(spawnError ? { spawnError } : {}),
      elapsedMs: Date.now() - started, finishedAt: new Date().toISOString() }));
  });
  fs.closeSync(out); fs.closeSync(err); put(def.name + '.exitcode.json', result); stages.push({ name: def.name, ...result });
  console.log(JSON.stringify({ event: 'stage-finished', name: def.name, ...result }));
  if (result.exitCode !== 0) throw Error(def.name + ' failed');
}
let failed;
try { for (const def of definitions) await run(def); }
catch (error) { failed = error.message; process.exitCode = 1; }
finally {
  const after = facts(); put('source-after.json', after);
  put('summary.json', { startedAt, stages, sourceBytesUnchanged: JSON.stringify(before) === JSON.stringify(after),
    ...(failed ? { failed } : {}), evidenceLevel: 'local controlled fixture, real console / browser workers / local model mock only',
    finishedAt: new Date().toISOString() });
  console.log(JSON.stringify({ out: OUT, stages: stages.length, failed: failed ?? null }));
}
