# Independent display original-bytes review

FAIL

Evidence: local controlled fixtures, no browser or Core suite. The managed fixture binds a loopback listener but makes zero target/model requests. Linux unlinked fd cases are explicitly offline syscall models, not native Linux execution.

Source hashes: source-sha256.json. Command: command.json. Output: stdout.jsonl/stderr.txt. Exit: exit.json.

| Case | Result |
|---|---|
| pre-directory | PASS |
| pre-inplace | PASS |
| late-inplace | PASS |
| two-publications | PASS |
| replacement-inplace | PASS |
| display-detail-retains-original-completion-bytes | PASS |
| strict-reader-keeps-fixed-scope | PASS |
| display-capability-isolation | PASS |
| source-snapshot-does-not-use-display-tolerance | FAIL |
| display-linux-unlinked-fd-syscall-model | FAIL |
| strict-linux-unlinked-fd-syscall-model | FAIL |
| managed-head-not-masked-by-legacy-publication | PASS |

All files created with wx in this new ignored directory. No source/test/stage/commit edits.
