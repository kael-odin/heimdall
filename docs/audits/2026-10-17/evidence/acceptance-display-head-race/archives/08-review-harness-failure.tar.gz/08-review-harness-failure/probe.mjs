import assert from 'node:assert/strict';
import fs,* as ns from 'node:fs';
import { syncBuiltinESMExports } from 'node:module';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { createAcceptanceRun,updateAcceptanceRun,finishAcceptanceRun,readAcceptanceRun,
 readAcceptanceDisplayRun,listAcceptanceRuns,readAcceptanceSnapshot } from '../../../src/acceptance/store.mjs';
import { createAcceptanceReadScope,createAcceptanceDisplayReadScope,assertAcceptanceReadScope,
 captureAcceptanceRunHead,captureAcceptanceRunFile,captureManagedCompletedRun } from '../../../src/acceptance/managed-run-reader.mjs';
import { writeAtomicFileSync } from '../../../src/acceptance/atomic-file.mjs';
import { managedExecutionFixture } from '../../../scripts/fixtures/managed-execution.mjs';
import { createManagedAcceptanceRun,updateManagedAcceptanceProgress } from '../../../src/acceptance/managed-run-store.mjs';
const encode=x=>JSON.stringify(x)+'\n',input={baselineUrl:'https://baseline.test',targetUrl:'https://target.test'},integrity={status:409,code:'MANAGED_RUN_INTEGRITY_FAILED'},outcomes=[];
function fixture(two=false){
 const root=ns.realpathSync(ns.mkdtempSync(join(tmpdir(),'heimdall-display-original-review-')));
 createAcceptanceRun({...input,name:'one'},{root});if(two)createAcceptanceRun({...input,name:'two'},{root});
 const handle=ns.opendirSync(root),ids=[];let entry;
 try{while((entry=handle.readSync()))if(entry.name.startsWith('ac-'))ids.push(entry.name);}finally{handle.closeSync();}
 return {root,ids,path:id=>join(root,id,'manifest.json'),cleanup:()=>ns.rmSync(root,{recursive:true,force:true})};
}
function hooks(options,read){
 const io={open:fs.openSync,close:fs.closeSync,lstat:fs.lstatSync,fstat:fs.fstatSync},fds=new Map(),counts=new Map();let busy=false;
 const invoke=(fn,arg)=>{if(!fn||busy)return undefined;busy=true;try{return fn(arg,io);}finally{busy=false;}};
 fs.openSync=(path,...args)=>{const alternative=invoke(options.open,{path:String(path),args});const fd=alternative??io.open(path,...args);fds.set(fd,String(path));return fd;};
 fs.closeSync=fd=>{io.close(fd);const path=fds.get(fd);fds.delete(fd);counts.delete(fd);invoke(options.close,{fd,path});};
 fs.lstatSync=(path,...args)=>{const stat=io.lstat(path,...args);return invoke(options.lstat,{path:String(path),stat})??stat;};
 fs.fstatSync=(fd,...args)=>{const stat=io.fstat(fd,...args),count=(counts.get(fd)??0)+1;counts.set(fd,count);return invoke(options.fstat,{fd,path:fds.get(fd),count,stat})??stat;};
 syncBuiltinESMExports();
 try{return read();}finally{fs.openSync=io.open;fs.closeSync=io.close;fs.lstatSync=io.lstat;fs.fstatSync=io.fstat;syncBuiltinESMExports();}
}
function check(name,fn){try{const detail=fn();outcomes.push({name,pass:true,...detail});}catch(error){outcomes.push({name,pass:false,error:{name:error.name,message:error.message,code:error.code,stack:error.stack}});}console.log(JSON.stringify(outcomes.at(-1)));}
for(const mode of ['pre-directory','pre-inplace','late-inplace'])check(mode,()=>{
 const f=fixture(true),aPath=f.path(f.ids[0]),bPath=f.path(f.ids[1]),a=JSON.parse(ns.readFileSync(aPath)),b=JSON.parse(ns.readFileSync(bPath));let aCloses=0,pubs=0,mutations=0;
 try{
  assert.throws(()=>hooks({close:({path})=>{
   if(path===aPath&&++aCloses===3&&mode==='late-inplace'){ns.writeFileSync(aPath,encode({...a,progress:{kind:'late-inplace'}}));mutations++;}
   if(path!==bPath||pubs)return;
   if(mode==='pre-directory'){const aDir=join(f.root,f.ids[0]),parked=join(f.root,'.parked-a');ns.renameSync(aDir,parked);ns.cpSync(parked,aDir,{recursive:true});mutations++;}
   if(mode==='pre-inplace'){ns.writeFileSync(aPath,encode({...a,progress:{kind:'early-inplace'}}));mutations++;}
   writeAtomicFileSync(bPath,encode({...b,progress:{kind:'publication'}}));pubs++;
  }},()=>listAcceptanceRuns({root:f.root})),integrity);
  assert.equal(pubs,1);assert.equal(mutations,1);return {status:409,pubs,mutations,aCloses};
 }finally{f.cleanup();}
});
for(const mode of ['two-publications','replacement-inplace'])check(mode,()=>{
 const f=fixture(true),bPath=f.path(f.ids[1]),b=JSON.parse(ns.readFileSync(bPath));let pubs=0,observed=false,mutations=0;
 try{
  const read=()=>hooks({close:({path})=>{if(path===bPath&&!pubs){writeAtomicFileSync(bPath,encode({...b,progress:{kind:'publication-1'}}));pubs++;}},
   lstat:({path})=>{if(path!==bPath||pubs!==1||observed)return;observed=true;if(mode==='two-publications'){writeAtomicFileSync(bPath,encode({...b,progress:{kind:'publication-2'}}));pubs++;}else{ns.writeFileSync(bPath,encode({...b,progress:{kind:'inplace-after-observation'}}));mutations++;}}
  },()=>listAcceptanceRuns({root:f.root}));
  if(mode==='replacement-inplace'){assert.throws(read,integrity);assert.equal(mutations,1);return {status:409,pubs,mutations};}
  const rows=read();assert.equal(pubs,2);assert.equal(rows.find(x=>x.runId===f.ids[1]).progress,null);
  assert.equal(JSON.parse(ns.readFileSync(bPath)).progress.kind,'publication-2');return {status:200,pubs,returnedProgress:rows.find(x=>x.runId===f.ids[1]).progress,currentProgress:JSON.parse(ns.readFileSync(bPath)).progress};
 }finally{f.cleanup();}
});
check('display-detail-retains-original-completion-bytes',()=>{
 const f=fixture(),id=f.ids[0],path=f.path(id),original=JSON.parse(ns.readFileSync(path));let pubs=0;
 try{const value=hooks({close:({path:current})=>{if(current===path&&!pubs){pubs++;finishAcceptanceRun(id,{mode:'mirror',checks:[],endedAt:new Date().toISOString()},{root:f.root});}}},()=>readAcceptanceDisplayRun(id,{root:f.root}));
  assert.deepEqual(value,original);assert.equal(readAcceptanceDisplayRun(id,{root:f.root}).status,'completed');return {status:200,pubs,returnedStatus:value.status,nextRequestStatus:'completed'};
 }finally{f.cleanup();}
});
check('strict-reader-keeps-fixed-scope',()=>{
 const f=fixture(),id=f.ids[0],path=f.path(id),original=JSON.parse(ns.readFileSync(path));let pubs=0;
 try{assert.throws(()=>hooks({close:({path:current})=>{if(current===path&&!pubs){pubs++;writeAtomicFileSync(path,encode({...original,progress:{kind:'publication'}}));}}},()=>readAcceptanceRun(id,{root:f.root})),integrity);return {status:409,pubs};}finally{f.cleanup();}
});
check('display-capability-isolation',()=>{
 const f=fixture(),id=f.ids[0];try{const scope=createAcceptanceDisplayReadScope({root:f.root});captureAcceptanceRunHead(id,{scope});assert.equal(scope.assertCurrent(),true);
  const calls=[()=>assertAcceptanceReadScope(scope,f.root),()=>captureAcceptanceRunFile(id,'manifest.json',{scope}),()=>captureAcceptanceRunFile(id,'evidence.json',{scope}),()=>captureManagedCompletedRun(id,{scope})];
  for(const call of calls)assert.throws(call,{code:'INVALID_INPUT'});return {rejectedCapabilities:calls.length};
 }finally{f.cleanup();}
});
check('source-snapshot-does-not-use-display-tolerance',()=>{
 const f=fixture(),id=f.ids[0],path=f.path(id);try{finishAcceptanceRun(id,{mode:'mirror',status:'completed',...input,checks:[]},{root:f.root});assert.equal(readAcceptanceSnapshot(id,{root:f.root}).integrity.valid,true);let pubs=0;
  const value=hooks({close:({path:current})=>{if(current===path&&!pubs){pubs++;writeAtomicFileSync(path,encode({...JSON.parse(ns.readFileSync(path)),triageAvailable:true}));}}},()=>readAcceptanceSnapshot(id,{root:f.root}));
  assert.equal(value.integrity.valid,false);return {valid:value.integrity.valid,pubs,errors:value.integrity.errors.map(x=>x.code)};
 }finally{f.cleanup();}
});
for(const strict of [false,true])check((strict?'strict':'display')+'-linux-unlinked-fd-syscall-model',()=>{
 const f=fixture(),id=f.ids[0],path=f.path(id),original=JSON.parse(ns.readFileSync(path)),parked=join(f.root,id,'.pinned-old-manifest');let swapped=false,modeled=false;
 try{const read=()=>hooks({open:({path:current,args},io)=>{if(current!==path||swapped)return;swapped=true;ns.renameSync(path,parked);writeAtomicFileSync(path,encode({...original,progress:{kind:'new-path-version'}}));return io.open(parked,...args);},
   fstat:({path:current,count,stat})=>{if(current!==path||count!==2||modeled)return;modeled=true;const finished=Object.create(Object.getPrototypeOf(stat));Object.assign(finished,stat,{nlink:0n,ctimeNs:stat.ctimeNs+1n});return finished;}
  },()=>strict?readAcceptanceRun(id,{root:f.root}):readAcceptanceDisplayRun(id,{root:f.root}));
  if(strict)assert.throws(read,integrity);else assert.deepEqual(read(),original);
  assert.equal(modeled,true);return {status:strict?409:200,modeled,returnedVersion:strict?null:'original',evidenceLevel:'offline syscall model on Windows; not a native Linux run'};
 }finally{f.cleanup();}
});
let managed;
try{
 managed=await managedExecutionFixture({paths:['/healthy']});
 const prepared=await managed.prepareOnly(),ref={operationId:prepared.envelope.operationId,dispatchSha256:prepared.record.sha256},options={owner:managed.owner,assertActive:()=>true};
 createManagedAcceptanceRun(ref,options);
 const legacy=createAcceptanceRun(input,{root:managed.root}),path=join(managed.root,legacy.runId,'manifest.json');
 check('managed-head-not-masked-by-legacy-publication',()=>{
  const scope=createAcceptanceDisplayReadScope({root:managed.root});captureAcceptanceRunHead(prepared.envelope.runId,{scope});let pubs=0;
  assert.throws(()=>hooks({close:({path:current})=>{if(current!==path||pubs)return;pubs++;updateManagedAcceptanceProgress(ref,{progress:{kind:'acceptance-check',completed:1,total:1}},options);updateAcceptanceRun(legacy.runId,{progress:{kind:'legacy-publication'}},{root:managed.root});}},()=>{captureAcceptanceRunHead(legacy.runId,{scope});scope.assertCurrent();}),integrity);
  assert.equal(managed.requests.length,0);assert.equal(managed.modelRequests.length,0);return {status:409,pubs,targetRequests:managed.requests.length,modelRequests:managed.modelRequests.length};
 });
}catch(error){outcomes.push({name:'managed-fixture-setup',pass:false,error:{message:error.message,stack:error.stack}});console.log(JSON.stringify(outcomes.at(-1)));}
finally{if(managed)await managed.cleanup();}
console.log(JSON.stringify({summary:true,total:outcomes.length,passed:outcomes.filter(x=>x.pass).length,failed:outcomes.filter(x=>!x.pass).length}));
if(outcomes.some(x=>!x.pass))process.exitCode=1;
