import assert from 'node:assert/strict';
import { createHash, randomUUID } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
const here = dirname(fileURLToPath(import.meta.url)), root = resolve(here, '../../../..'), out = join(here, 'run-' + randomUUID());
mkdirSync(out); const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const owned = ['console/src/AcceptanceDefectTickets.vue', 'console/src/acceptance-defect-tickets.js', 'console/src/AcceptanceCatalog.vue',
  'core/test/console-acceptance-defect-tickets-state.test.mjs'];
const verifiers = ['browser-operation-schema.mjs', 'browser-operation-store.mjs', 'browser-fixed-contract.mjs', 'browser-fixed-runner.mjs',
  'runner.mjs', 'identity.mjs', 'report.mjs', '../verify/compare.mjs'].map(file => resolve(root, 'core/src/acceptance', file));
const metadata = files => files.map(file => { const bytes = readFileSync(file); return { file, bytes: bytes.length, sha256: sha(bytes) }; });
const before = metadata(verifiers), ownedBefore = metadata(owned.map(file => join(root, file)));
for (const row of ownedBefore) writeFileSync(join(out, row.file.split(/[\\/]/).at(-1) + '.executed-original'), readFileSync(row.file), { flag: 'wx' });
writeFileSync(join(out, 'run-checks.mjs.executed-original'), readFileSync(fileURLToPath(import.meta.url)), { flag: 'wx' });
const args = ['--test', '--test-reporter=tap', '--test-concurrency=1', 'core/test/console-acceptance-defect-tickets-state.test.mjs'];
const startedAt = new Date().toISOString();
const state = spawnSync(process.execPath, args, { cwd: root, windowsHide: true, encoding: null, timeout: 90000, maxBuffer: 8 * 1024 * 1024 });
writeFileSync(join(out, 'state-stdout.log'), state.stdout ?? Buffer.alloc(0)); writeFileSync(join(out, 'state-stderr.log'), state.stderr ?? Buffer.alloc(0));
const buildArgs = [join(root, 'console/node_modules/vite/bin/vite.js'), 'build'];
const build = spawnSync(process.execPath, buildArgs, { cwd: join(root, 'console'), windowsHide: true, encoding: null, timeout: 120000, maxBuffer: 8 * 1024 * 1024 });
writeFileSync(join(out, 'build-stdout.log'), build.stdout ?? Buffer.alloc(0)); writeFileSync(join(out, 'build-stderr.log'), build.stderr ?? Buffer.alloc(0));
const after = metadata(verifiers), ownedAfter = metadata(owned.map(file => join(root, file))); assert.deepEqual(before, after); assert.deepEqual(ownedBefore, ownedAfter);
const result = { startedAt, endedAt: new Date().toISOString(), executable: process.execPath, outputDirectory: out,
  state: { args, cwd: root, exitCode: state.status, signal: state.signal, error: state.error?.code ?? null,
    counts: Object.fromEntries(['tests', 'pass', 'fail', 'cancelled', 'skipped', 'todo'].map(key => [key, Number((String(state.stdout).match(new RegExp(`# ${key} (\\d+)`)) ?? [null, -1])[1])])) },
  build: { args: buildArgs, cwd: join(root, 'console'), exitCode: build.status, signal: build.signal, error: build.error?.code ?? null },
  ownedBefore, ownedAfter, verifierBefore: before, verifierAfter: after, eightVerifierBytesUnchanged: true, ownedBytesUnchanged: true,
  evidenceLevel: 'actual-vue-ref-watchers-and-production-build-no-browser-engine-or-network' };
writeFileSync(join(out, 'summary.json'), JSON.stringify(result, null, 2) + '\n'); console.log(JSON.stringify({ state: result.state, build: result.build, outputDirectory: out }));
if (state.status !== 0 || build.status !== 0 || result.state.counts.skipped !== 0) process.exitCode = 1;
