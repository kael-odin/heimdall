# 人工缺陷单

范围：固定关联检查。

> 菜单还原的两个固定检查

编号：dt\-da61dec1\-8820\-439a\-b229\-92a22313ff27
严重度：high
人工处理状态：closed
当前核验状态：verified\_passed
关联检查数量：2
导出时间：2026\-10\-17T18:50:40\.935Z

## 问题说明

> Compare dashboard\[query omitted\] and //example\.test/path

## 复现说明

> 打开固定页面并展开菜单，核对布局与行为。

## 固定来源

操作：bo\-2197a5fe\-1e83\-408c\-94a6\-ebd0f6067807
报告 SHA256：ea60fcf5a8bbd0d3eb9ccd32cd4dc308b066f879bf0100a0973dcc9dcdff3ef9
登记 SHA256：1f973b3d8c65707c63a219da09fbb851c359d2ecab34f88a6fd10567721f3126
成员集合 SHA256：51bd79fe6747a1cada1c08922c814bbc4d01b98ac1ff76bc5117c6c931eb1a19

## 关联检查与证据

- 检查：route\-1\-1\-desktop\-point\-1\-menu；路由：/；BUG：bug\-c8e2712abaa7fae5e597f85b00046cac4b6b6b1d9a3a857035a59ff495750518
  - baselineDetails：source\-route\-1\-1\-desktop\-point\-1\-baseline\.json；2019 bytes；SHA256 42b8582d1a5e2749ae5777f4d7baaa348c9224a9e06f61f8b6f81b7a71cfbffc
  - baselineRepeat：source\-route\-1\-1\-desktop\-point\-1\-baseline\-repeat\.png；20801 bytes；SHA256 fad70f008284c23961c1f598183376a691918a323818a7351c4d6876f5bb8fe0
  - baselineScreenshot：source\-route\-1\-1\-desktop\-point\-1\-baseline\.png；20801 bytes；SHA256 fad70f008284c23961c1f598183376a691918a323818a7351c4d6876f5bb8fe0
  - targetDetails：route\-1\-1\-desktop\-point\-1\-target\.json；1976 bytes；SHA256 83de50f4fb0636456bc880eb7fa15c643bdb4b721f089d8655e73ab98fde9dfb
  - targetRepeat：route\-1\-1\-desktop\-point\-1\-target\-repeat\.png；19446 bytes；SHA256 1225aed12b39a898e611acfdbfeaec641f39d32f6257aef2c70e1b3d3e045885
  - targetScreenshot：route\-1\-1\-desktop\-point\-1\-target\.png；19446 bytes；SHA256 1225aed12b39a898e611acfdbfeaec641f39d32f6257aef2c70e1b3d3e045885
- 检查：route\-1\-1\-desktop\-visual；路由：/；BUG：bug\-3dfacf755504062390a4ab62b7fb54d90a47b63f296a080f93a3d36708241263
  - baselineDetails：source\-route\-1\-1\-desktop\-baseline\.json；1499 bytes；SHA256 fc7c62109e4fa39193c54e68a6ca42178f495c4139ef22c5301a166b1e3c5942
  - baselineRepeat：source\-route\-1\-1\-desktop\-baseline\-repeat\.png；18603 bytes；SHA256 202d38f7589893b5087810ec44d54397af3d1dd83e82b7a9146a262672ee49d1
  - baselineScreenshot：source\-route\-1\-1\-desktop\-baseline\.png；18603 bytes；SHA256 202d38f7589893b5087810ec44d54397af3d1dd83e82b7a9146a262672ee49d1
  - diff：route\-1\-1\-desktop\-diff\.png；18902 bytes；SHA256 fcfb328862c42286b58454bd70838b284574f859872e2a0e61244ac4117fa8e3
  - targetDetails：route\-1\-1\-desktop\-target\.json；1451 bytes；SHA256 4a859b13ab14c82109d482070e26c9b5aac41589f11f5baf4645f3462ed979a2
  - targetRepeat：route\-1\-1\-desktop\-target\-repeat\.png；18689 bytes；SHA256 66bf1a1be26da389544bda3856aa681eb947d889eb2099e52aaeb54412f4c832
  - targetScreenshot：route\-1\-1\-desktop\-target\.png；18689 bytes；SHA256 66bf1a1be26da389544bda3856aa681eb947d889eb2099e52aaeb54412f4c832

## 当前逐项核验

- route\-1\-1\-desktop\-point\-1\-menu：verified\_passed（REGISTERED\_RELIABLE\_PASS）
- route\-1\-1\-desktop\-visual：verified\_passed（REGISTERED\_RELIABLE\_PASS）

## 人工处理历史

- revision 0 · create · 2026\-10\-17T18:42:35\.413Z · da\-801bba28\-1d85\-40e0\-bd97\-501bfd9cf3b3 · SHA256 c79e80405e47d238970762831b149d9f8f204a457a39ee7222901a1657912274
- revision 1 · close · 2026\-10\-17T18:44:31\.947Z · da\-8e5173c4\-2a75\-405e\-90f1\-9555643ce779 · SHA256 eb3102e74947dd6ffcaf114659fc6b53a3fb4e8a56e14779b4350c2c1709985b

> 两项固定检查均已在当前登记中通过。

- revision 2 · close · 2026\-10\-17T18:49:17\.296Z · da\-b0374ceb\-4b5b\-4cc2\-ae09\-a3a9446e46e0 · SHA256 25f6ee701a5841a34a164eb670bac9528e13a16897ea91115eb76d8aacd05215

> 两项固定检查均已在当前登记中通过。


## 范围限制

- 仅覆盖此人工缺陷单固定关联的检查；不代表整个页面、项目或业务流程已修复。
- 人工处理状态与当前核验状态分开；历史关闭不代替当前证据核验。
- 导出省略 URL 查询参数及已识别的敏感字段，不包含原始报告、截图、网络记录或 AI 原文。
- 无法保证识别任意人工输入的秘密；共享前仍应检查人工文字。
