import assert from 'node:assert/strict';
import { createHash, randomUUID } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
const here = dirname(fileURLToPath(import.meta.url)), root = resolve(here, '../../../..');
const out = join(here, 'run-' + randomUUID()); mkdirSync(out);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const own = ['core/src/acceptance/defect-ticket-store.mjs', 'core/test/acceptance-defect-ticket-store.test.mjs',
  'core/src/acceptance/defect-ticket-schema.mjs', 'core/src/acceptance/defect-ticket-model.mjs'];
const verifier = ['browser-operation-schema.mjs', 'browser-operation-store.mjs', 'browser-fixed-contract.mjs', 'browser-fixed-runner.mjs',
  'runner.mjs', 'identity.mjs', 'report.mjs', '../verify/compare.mjs'].map(file => resolve(root, 'core/src/acceptance', file));
const metadata = files => files.map(file => { const bytes = readFileSync(file); return { file, bytes: bytes.length, sha256: sha(bytes) }; });
const before = metadata(verifier), owned = metadata(own.map(file => join(root, file)));
for (const row of owned) writeFileSync(join(out, row.file.split(/[\\/]/).at(-1) + '.executed-original'), readFileSync(row.file), { flag: 'wx' });
writeFileSync(join(out, 'run-tests.mjs.executed-original'), readFileSync(fileURLToPath(import.meta.url)), { flag: 'wx' });
const args = ['--test', '--test-concurrency=1', own[1]], startedAt = new Date().toISOString();
const result = spawnSync(process.execPath, args, { cwd: root, windowsHide: true, encoding: null,
  timeout: 180000, maxBuffer: 8 * 1024 * 1024, env: { ...process.env, D5_STORE_EVIDENCE_ROOT: join(out, 'fixtures') } });
writeFileSync(join(out, 'stdout.log'), result.stdout ?? Buffer.alloc(0), { flag: 'wx' });
writeFileSync(join(out, 'stderr.log'), result.stderr ?? Buffer.alloc(0), { flag: 'wx' });
const after = metadata(verifier); assert.deepEqual(after, before);
writeFileSync(join(out, 'summary.json'), JSON.stringify({ startedAt, endedAt: new Date().toISOString(), executable: process.execPath,
  args, cwd: root, exitCode: result.status, signal: result.signal, error: result.error?.code ?? null,
  ownedSources: owned, verifierBefore: before, verifierAfter: after, eightVerifierBytesUnchanged: true,
  evidenceLevel: 'offline-owner-bound-manual-defect-ticket-store-no-browser-or-network', outputDirectory: out }, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ exitCode: result.status, outputDirectory: out }));
if (result.status !== 0) process.exitCode = 1;
