import { createHash, randomUUID } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { resolve, dirname, join, basename } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
const here = dirname(fileURLToPath(import.meta.url)), root = resolve(here, '../../../..');
const out = join(here, 'run-' + randomUUID()); mkdirSync(out);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const sources = ['console/src/acceptance-defect-tickets.js', 'core/test/console-acceptance-defect-tickets.test.mjs',
  'core/src/acceptance/defect-ticket-schema.mjs', 'core/src/acceptance/defect-ticket-model.mjs', 'core/src/acceptance/defect-ticket-report.mjs'];
const verifier = ['browser-operation-schema.mjs', 'browser-operation-store.mjs', 'browser-fixed-contract.mjs', 'browser-fixed-runner.mjs',
  'runner.mjs', 'identity.mjs', 'report.mjs', '../verify/compare.mjs'].map(file => resolve(root, 'core/src/acceptance', file));
const metadata = files => files.map(file => { const bytes = readFileSync(file); return { file, bytes: bytes.length, sha256: sha(bytes) }; });
const before = metadata(verifier), originals = metadata(sources.map(file => join(root, file)));
for (const row of originals) writeFileSync(join(out, basename(row.file) + '.executed-original'), readFileSync(row.file), { flag: 'wx' });
writeFileSync(join(out, 'run-tests.executed-original'), readFileSync(fileURLToPath(import.meta.url)), { flag: 'wx' });
const args = ['--test', '--test-reporter=tap', '--test-concurrency=1', 'core/test/console-acceptance-defect-tickets.test.mjs'];
const startedAt = new Date().toISOString(), result = spawnSync(process.execPath, args,
  { cwd: root, windowsHide: true, encoding: null, timeout: 45000, maxBuffer: 8 * 1024 * 1024, env: { ...process.env } });
writeFileSync(join(out, 'stdout.log'), result.stdout ?? Buffer.alloc(0), { flag: 'wx' });
writeFileSync(join(out, 'stderr.log'), result.stderr ?? Buffer.alloc(0), { flag: 'wx' });
const after = metadata(verifier), afterSources = metadata(sources.map(file => join(root, file)));
const stdout = (result.stdout ?? Buffer.alloc(0)).toString('utf8');
const counts = Object.fromEntries(['tests', 'pass', 'fail', 'cancelled', 'skipped', 'todo'].map(key => [key,
  Number(new RegExp(`^# ${key} (\\d+)\\s*$`, 'm').exec(stdout)?.[1] ?? -1)]));
const summary = { startedAt, endedAt: new Date().toISOString(), executable: process.execPath, args, cwd: root,
  exitCode: result.status, signal: result.signal, error: result.error?.code ?? null, counts,
  sourcesBefore: originals, sourcesAfter: afterSources, executedSourcesUnchanged: JSON.stringify(originals) === JSON.stringify(afterSources),
  verifierBefore: before, verifierAfter: after, eightVerifierBytesUnchanged: JSON.stringify(before) === JSON.stringify(after),
  evidenceLevel: 'pure-core-model-dto-and-simulated-fetch-storage-web-locks-no-browser-service-engine-or-network', outputDirectory: out };
writeFileSync(join(out, 'summary.json'), JSON.stringify(summary, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ exitCode: result.status, counts, outputDirectory: out, executedSourcesUnchanged: summary.executedSourcesUnchanged,
  eightVerifierBytesUnchanged: summary.eightVerifierBytesUnchanged }));
if (result.status !== 0 || !summary.executedSourcesUnchanged || !summary.eightVerifierBytesUnchanged) process.exitCode = 1;
