"""Capture only D5 API and real-engine HTTP tests with their source bytes."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess

repo = Path.cwd().resolve()
capture_root = Path(__file__).resolve().parent
stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
out = capture_root / ("run-" + stamp)
out.mkdir(exist_ok=False)
sha = lambda data: hashlib.sha256(data).hexdigest()
encode = lambda value: (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
pending = [repo / file for file in ["core/src/engine-server.mjs", "core/test/acceptance-defect-ticket-api.test.mjs",
    "core/test/acceptance-defect-ticket-engine.test.mjs"]]
pending += [path for path in (repo / "core/test/fixtures/acceptance-browser-source").rglob("*") if path.is_file()]
pending += [repo / file for file in ["package.json", "package-lock.json", "core/package.json", "core/package-lock.json"] if (repo / file).is_file()]
sources = {}
while pending:
    path = pending.pop().resolve()
    path.relative_to(repo)
    if path in sources:
        continue
    data = path.read_bytes()
    sources[path] = {"path": path.relative_to(repo).as_posix(), "bytes": len(data), "sha256": sha(data)}
    target = out / "source" / path.relative_to(repo)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.open("xb").write(data)
    if path.suffix == ".mjs":
        for specifier in re.findall(r'''(?:from\s*|import\s*|import\s*\(\s*)['"](\.[^'"]+)['"]''', data.decode("utf-8")):
            pending.append(path.parent / specifier)
command = ["node", "--test", "--test-reporter=tap", "test/acceptance-defect-ticket-api.test.mjs", "test/acceptance-defect-ticket-engine.test.mjs"]
node_version = subprocess.check_output(["node", "--version"]).decode().strip()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
env = dict(os.environ)
env["HEIMDALL_D5_ENGINE_TEST_EVIDENCE_DIR"] = str(out / "engine-http")
timed_out = False
try:
    with (out / "stdout.log").open("xb") as stdout_file, (out / "stderr.log").open("xb") as stderr_file:
        process = subprocess.Popen(command, cwd=repo / "core", stdout=stdout_file, stderr=stderr_file, env=env)
        try:
            code = process.wait(timeout=1800)
        except subprocess.TimeoutExpired:
            process.terminate()
            process.wait()
            code, timed_out = None, True
    stdout, stderr = (out / "stdout.log").read_bytes(), (out / "stderr.log").read_bytes()
except subprocess.TimeoutExpired as error:
    stdout, stderr, code, timed_out = error.stdout or b"", error.stderr or b"", None, True
changed = [item["path"] for path, item in sources.items() if path.read_bytes() != (out / "source" / path.relative_to(repo)).read_bytes()]
text = stdout.decode("utf-8", errors="replace")
stats = {key: int(value) for key, value in re.findall(r"^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)$", text, re.M)}
summary = {"command": command, "cwd": str(repo / "core"), "nodeVersion": node_version, "startedAt": started,
    "endedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(), "exitCode": code, "timedOut": timed_out,
    "sourceStable": not changed, "changedSource": changed, "sourceCount": len(sources), "sources": list(sources.values()),
    "stdoutBytes": len(stdout), "stdoutSha256": sha(stdout), "stderrBytes": len(stderr), "stderrSha256": sha(stderr), "stats": stats,
    "passed": code == 0 and not timed_out and not changed and stats.get("tests", 0) > 0 and stats.get("pass") == stats.get("tests")
        and all(stats.get(key) == 0 for key in ("fail", "cancelled", "skipped", "todo")),
    "captureScriptSha256": sha(Path(__file__).read_bytes())}
(out / "summary.json").open("xb").write(encode(summary))
print(json.dumps({"directory": str(out), **{key: summary[key] for key in ["exitCode", "timedOut", "sourceStable", "changedSource", "sourceCount", "stats", "passed"]}}, ensure_ascii=False))
if not summary["passed"]:
    print(text[-24000:])
    print(stderr.decode("utf-8", errors="replace")[-5000:])
raise SystemExit(0 if summary["passed"] else 1)
