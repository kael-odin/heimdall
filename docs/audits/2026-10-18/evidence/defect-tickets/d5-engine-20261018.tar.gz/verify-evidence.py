"""Independent byte and HTTP-fact audit; does not launch any tests or browser."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

repo = Path.cwd().resolve()
run = Path(sys.argv[1]).resolve()
summary = json.loads((run / "summary.json").read_bytes())
sha = lambda data: hashlib.sha256(data).hexdigest()
encode = lambda value: (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
checks, cases, timings, drift = [], [], [], []
for source in summary["sources"]:
    frozen = (run / "source" / source["path"]).read_bytes()
    checks.append({"kind": "frozen-source", "path": source["path"],
        "ok": len(frozen) == source["bytes"] and sha(frozen) == source["sha256"]})
    if (repo / source["path"]).read_bytes() != frozen:
        drift.append(source["path"])
for file in ["stdout", "stderr"]:
    data = (run / (file + ".log")).read_bytes()
    checks.append({"kind": "output", "path": file + ".log",
        "ok": len(data) == summary[file + "Bytes"] and sha(data) == summary[file + "Sha256"]})
verifiers = ["core/src/acceptance/" + file for file in ["browser-operation-schema.mjs", "browser-operation-store.mjs",
    "browser-fixed-contract.mjs", "browser-fixed-runner.mjs", "runner.mjs", "identity.mjs", "report.mjs"]] + ["core/src/verify/compare.mjs"]
for file in verifiers:
    frozen = run / "source" / file
    head = subprocess.check_output(["git", "show", "HEAD:" + file], cwd=repo)
    checks.append({"kind": "unchanged-existing-verifier", "path": file,
        "ok": frozen.is_file() and frozen.read_bytes() == head and (repo / file).read_bytes() == head})
for case in sorted((run / "engine-http").iterdir()):
    if not case.is_dir():
        continue
    snapshots = json.loads((case / "source-snapshots.json").read_bytes())
    targets = json.loads((case / "target-requests.json").read_bytes())
    calls = json.loads((case / "http.json").read_bytes())
    baseline = snapshots["before-engine"]
    stable = all(value == baseline for value in snapshots.values())
    completed = [call for call in calls if "status" in call]
    failed_business_transport = [call for call in calls if "transportFailure" in call and call["path"] != "/api/status"]
    acceptance = [call for call in completed if call["path"].startswith("/api/acceptance/")]
    no_store = all(call["headers"].get("cache-control") == "no-store" and call["headers"].get("x-content-type-options") == "nosniff"
        for call in acceptance)
    jobs = [call["payload"] for call in completed if call["path"] == "/api/jobs"]
    status = [call["payload"] for call in completed if call["path"] == "/api/status"]
    no_execution = bool(jobs) and all(value["jobs"] == [] and value["history"] == [] for value in jobs)
    no_execution = no_execution and bool(status) and all(value["acceptance"] is None for value in status)
    cases.append({"case": case.name, "completedHttp": len(completed), "startupConnectionAttempts": len(calls) - len(completed),
        "sourceFiles": len(baseline["browser"]) + 1, "snapshotLabels": list(snapshots), "sourcesUnchanged": stable,
        "targetRequests": len(targets), "noJobsOrAcceptanceRuntime": no_execution, "headersValid": no_store,
        "businessTransportFailures": failed_business_transport,
        "ok": stable and targets == [] and no_execution and no_store and not failed_business_transport})
    for call in acceptance:
        timings.append({"case": case.name, **{key: call[key] for key in ["method", "path", "status", "elapsedMs"]}})
checks.extend({"kind": "http-case", "path": case["case"], "ok": case["ok"]} for case in cases)
stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
out = run.parent / ("verification-" + stamp)
out.mkdir(exist_ok=False)
inventory = [{"path": file.relative_to(run).as_posix(), "bytes": file.stat().st_size, "sha256": sha(file.read_bytes())}
    for file in sorted(run.rglob("*")) if file.is_file()]
result = {"run": str(run), "verifiedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "passed": summary["passed"] and all(check["ok"] for check in checks), "testStats": summary["stats"],
    "checks": checks, "cases": cases, "currentSourceDrift": drift, "currentSourceMatches": not drift,
    "longestRequests": sorted(timings, key=lambda item: item["elapsedMs"], reverse=True)[:15],
    "evidenceFileCount": len(inventory), "inventory": inventory, "scriptSha256": sha(Path(__file__).read_bytes())}
(out / "summary.json").open("xb").write(encode(result))
print(json.dumps({"directory": str(out), **{key: result[key] for key in ["passed", "testStats", "cases", "currentSourceDrift", "evidenceFileCount"]}}, ensure_ascii=False))
raise SystemExit(0 if result["passed"] else 1)
