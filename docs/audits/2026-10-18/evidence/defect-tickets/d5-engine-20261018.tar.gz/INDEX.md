# D5 人工缺陷单 API 与真实引擎 HTTP 专项证据

最终运行：`run-20261017T183258.330241Z`。本地时间 2026-10-18 02:32:58 至 02:37:08（UTC+08:00），Node v25.2.1。

结果：**19/19 pass，0 fail / cancelled / skipped / todo，exitCode=0，timedOut=false**。其中 API 15 项、真实独立引擎 HTTP 4 项；TAP 总耗时 248380.7647ms。运行前保存的 178 份源码、fixture 和 package 文件在运行后全部保持原字节。

## 证据入口

- `run-20261017T183258.330241Z/summary.json`：精确命令、开始/结束时间、178 份原件的 SHA256、输出摘要与 TAP 统计。
- 同目录 `stdout.log` / `stderr.log`：完整原始输出，采集期间持续落盘。
- 同目录 `source/`：测试、engine 的静态/字面动态导入、完整 captured source fixture、package/lock 原字节。
- 同目录 `engine-http/`：四个隔离现场，均含 `http.json`、`source-snapshots.json`、`target-requests.json`、引擎输出及完整 `data/`。
- `verification-20261017T183929.209634Z/summary.json`：不启动测试或 Browser 的独立核验。178 份冻结原件、2 份输出、8 个既有 verifier 与 HEAD 的逐字节一致性、4 个 HTTP 场景全部通过；677 份证据文件的完整清单。

## 真实 HTTP 场景

| 场景 | 完成 HTTP 请求 | 关键断言 |
| --- | ---: | --- |
| read-only | 31 | 每条读取路由的缺失/错误鉴权均 401；header/query token 可用；sources 与 action 字面路由正确；缺席 action 一直 unresolved；只读访问不创建 ticket namespace。 |
| ticket-lifecycle | 25 | 固定两项成员的建单、原 action 核对、同 action 重放、不同输入 409、预览、显式关闭、关闭重放、MD/JSON 下载、foreign 404、重启后原事件 SHA 与成员集合保持一致。 |
| recovery-blocked | 14 | 原缺陷单/来源/action/导出可读取，所有缺陷单 POST 在既有恢复门禁前拒绝；旧事件、Browser、Catalog 和损坏 legacy 原件保持一致。 |
| owner-lost | 13 | 替换测试 owner 文件后，来源/action/详情/预览/下载/写入全部 503；无鉴权仍 401；原现场不被修复。 |

每个场景都保留完整 captured matrix：两项已登记完成操作，每项 **28 个 checks、52 份 evidence 文件**。没有缩减已捕获的检查范围。逐场景比对 113 份 Catalog/Browser 原件的 SHA256、字节数、mtimeNs、ctimeNs，全部一致。目标哨兵请求为 0，jobs/history 为空，acceptance runtime 为 null。全部 acceptance 响应的 no-store/nosniff 合同通过。

引擎监听前的健康轮询连接失败单独保留在 `http.json`，属于启动探测；83 个完成 HTTP 请求中没有业务传输失败。每个请求均保存精确 method、path、body、状态、响应 headers、payload/bytes SHA256、elapsedMs。

完整校验在本机的最慢完成请求：关闭 10602ms、建单 10191ms、导出 7995ms、详情 7954ms；sources 6968ms。新 HTTP 测试预算为 30s，未修改既有测试 timeout、过滤或断言。

## API 边界

15 项 API 测试覆盖：字面路由优先与严格 ID/query/method、32KiB 原始 UTF-8 字节上限与跨 chunk 中文、fatal UTF-8/JSON/MIME、完整 schema、固定下载文件名与 MIME、错误 own descriptor 边界、固定错误码与显式 outcomeUnknown、原 POST 的确定/未知结果、真实客户端断开后只读取原 action。

API 层的断线测试使用注入服务制造响应前断开，证明路由/传输没有自动重发。真实 service/store 持久化和 engine 重启保持原 action 的证据分别来自后端专项与本轮真实 engine lifecycle；本包不把注入服务测试写成 Browser 或断电耐久性证据。

## 接线范围与复现

生产 engine 仅新增两个 imports、一个 owner-bound service 实例和一个 router 调用。新 router 处于原鉴权、owner、恢复门禁之后，Catalog router 之前。没有增加 Browser 执行、登记或恢复入口；八个既有 verifier 与 HEAD 完全相同。

在工作树根目录运行：

```powershell
python core/workspace/_runs/d5-engine-20261018/capture-tests.py
```

其唯一测试命令（cwd=`core`）：

```text
node --test --test-reporter=tap test/acceptance-defect-ticket-api.test.mjs test/acceptance-defect-ticket-engine.test.mjs
```

只读核验指定运行：

```powershell
python core/workspace/_runs/d5-engine-20261018/verify-evidence.py core/workspace/_runs/d5-engine-20261018/run-20261017T183258.330241Z
```

## 保留的失败轮次

- `run-20261017T181630.063396Z`：API 新版 15 项通过；新增 engine fixture 向 exact-fields 编译入口传入额外字段，4 项在准备阶段被既有门禁拒绝。只修新增测试为明确四字段调用，未动 verifier。
- `run-20261017T181830.304615Z`：完整 matrix 的 sources/create 超过新增测试自定 5s HTTP 预算；100s 新采集总预算到达，原输出/现场保留。随后按真实耗时将新增 HTTP 预算设为 30s、采集预算设为 1800s，保留完整 scope，并等待其它重型后端测试结束后串行得到本轮 19/19。没有将失败轮次写成通过。

本包验证离线捕获事实、真实引擎进程与真实 HTTP；未运行 Browser 或全 Core。D5 真实 Browser 闭环由 root 后续统一验收。
