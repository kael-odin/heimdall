import { spawn } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync, readdirSync } from 'node:fs';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash, randomUUID } from 'node:crypto';
const here = dirname(fileURLToPath(import.meta.url)), root = resolve(here, '../../../..');
const out = join(here, 'run-' + randomUUID()); mkdirSync(out);
const walk = directory => readdirSync(join(root,directory),{withFileTypes:true}).flatMap(entry => entry.isDirectory()
  ? walk(directory+'/'+entry.name) : entry.isFile() ? [directory+'/'+entry.name] : []);
const files = [...walk('core/src/acceptance'), ...walk('core/test/fixtures'),
  ...walk('core/test').filter(file => /acceptance-defect-ticket.*\.test\.mjs$/.test(file)),
  'core/src/verify/compare.mjs'].sort();
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const snapshot = () => files.map(file => {const bytes=readFileSync(join(root,file));return {file,bytes:bytes.length,sha256:hash(bytes)};});
const before = snapshot();
for (const row of before) {const target=join(out,'source',row.file);mkdirSync(dirname(target),{recursive:true});writeFileSync(target,readFileSync(join(root,row.file)),{flag:'wx'});}
writeFileSync(join(out,'runner.mjs'),readFileSync(fileURLToPath(import.meta.url)),{flag:'wx'});
const args = process.argv.slice(2);
if (!args.length) throw new Error('explicit node arguments required');
const startedAt=new Date().toISOString(),stdout=[],stderr=[];
const child=spawn(process.execPath,args,{cwd:root,windowsHide:true});
child.stdout.on('data',bytes=>stdout.push(Buffer.from(bytes)));child.stderr.on('data',bytes=>stderr.push(Buffer.from(bytes)));
const result=await new Promise(resolve=>{child.once('error',error=>resolve({exitCode:null,signal:null,error:String(error)}));child.once('close',(exitCode,signal)=>resolve({exitCode,signal,error:null}));});
const a=Buffer.concat(stdout),b=Buffer.concat(stderr),after=snapshot();
writeFileSync(join(out,'stdout.log'),a,{flag:'wx'});writeFileSync(join(out,'stderr.log'),b,{flag:'wx'});
const tap=a.toString('utf8'),totals=Object.fromEntries(['tests','pass','fail','cancelled','skipped','todo'].map(key=>[key,Number(new RegExp('^# '+key+' (\\d+)$','m').exec(tap)?.[1]??NaN)]));
const summary={startedAt,endedAt:new Date().toISOString(),executable:process.execPath,args,cwd:root,...result,totals,before,after,
  unchanged:JSON.stringify(before)===JSON.stringify(after),output:{stdout:{bytes:a.length,sha256:hash(a)},stderr:{bytes:b.length,sha256:hash(b)}},
  evidenceLevel:'offline-real-owner-browser-ledger-ticket-store-service-no-browser-or-network',outputDirectory:out};
writeFileSync(join(out,'summary.json'),JSON.stringify(summary,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({startedAt:summary.startedAt,endedAt:summary.endedAt,...result,totals,unchanged:summary.unchanged,outputDirectory:out}));
process.exitCode=result.exitCode||(summary.unchanged?0:1);
