import { spawn } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash, randomUUID } from 'node:crypto';
const here = dirname(fileURLToPath(import.meta.url)), root = resolve(here, '../../../..');
const out = join(here, 'run-' + randomUUID()); mkdirSync(out);
const files = ['core/src/acceptance/defect-ticket-source.mjs', 'core/test/acceptance-defect-ticket-source.test.mjs',
  'core/src/acceptance/defect-ticket-schema.mjs', 'core/src/acceptance/defect-ticket-model.mjs',
  ...['browser-operation-schema.mjs', 'browser-operation-store.mjs', 'browser-fixed-contract.mjs',
    'browser-fixed-runner.mjs', 'runner.mjs', 'identity.mjs', 'report.mjs'].map(file => 'core/src/acceptance/' + file), 'core/src/verify/compare.mjs'];
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const snapshot = () => files.map(file => { const bytes = readFileSync(join(root, file)); return { file, bytes: bytes.length, sha256: hash(bytes) }; });
const before = snapshot();
for (const item of before) { const target = join(out, 'source', item.file); mkdirSync(dirname(target), { recursive: true }); writeFileSync(target, readFileSync(join(root, item.file)), { flag: 'wx' }); }
const args = ['--test', '--test-reporter=tap', '--test-concurrency=1', 'core/test/acceptance-defect-ticket-source.test.mjs'];
const start = new Date().toISOString(), stdout = [], stderr = [];
const child = spawn(process.execPath, args, { cwd: root, windowsHide: true });
child.stdout.on('data', bytes => stdout.push(Buffer.from(bytes))); child.stderr.on('data', bytes => stderr.push(Buffer.from(bytes)));
const result = await new Promise(resolve => { child.once('error', error => resolve({ error: String(error), exitCode: null, signal: null }));
  child.once('close', (exitCode, signal) => resolve({ exitCode, signal, error: null })); });
const a = Buffer.concat(stdout), b = Buffer.concat(stderr), after = snapshot();
writeFileSync(join(out, 'stdout.log'), a, { flag: 'wx' }); writeFileSync(join(out, 'stderr.log'), b, { flag: 'wx' });
const text = a.toString('utf8'), totals = Object.fromEntries(['tests','pass','fail','cancelled','skipped','todo'].map(key => [key, Number(new RegExp('^# '+key+' (\\d+)$','m').exec(text)?.[1] ?? NaN)]));
const summary = { startedAt: start, endedAt: new Date().toISOString(), executable: process.execPath, args, cwd: root,
  ...result, totals, before, after, unchanged: JSON.stringify(before) === JSON.stringify(after),
  output: { stdout: { bytes: a.length, sha256: hash(a) }, stderr: { bytes: b.length, sha256: hash(b) } },
  evidenceLevel: 'offline-real-owner-browser-store-ledger-no-browser-or-network', outputDirectory: out };
writeFileSync(join(out, 'summary.json'), JSON.stringify(summary,null,2)+'\n', { flag: 'wx' });
console.log(JSON.stringify(summary)); process.exitCode = result.exitCode || (summary.unchanged ? 0 : 1);
