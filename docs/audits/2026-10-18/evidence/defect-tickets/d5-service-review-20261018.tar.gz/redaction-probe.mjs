import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { redactDefectTicketExportText } from '../../../src/acceptance/defect-ticket-report.mjs';
const cases = ['Visit dashboard?session=RELATIVE_SECRET', 'Visit //user:pass@example.test/app?token=NETWORK_SECRET'];
const output = cases.map(input => ({ input, output: redactDefectTicketExportText(input) }));
writeFileSync(join(dirname(fileURLToPath(import.meta.url)), 'redaction-probe-output.json'), JSON.stringify(output, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(output));
