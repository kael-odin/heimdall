# Schema4 draft source · 项目验收报告

任务：ac-3fcd03e8-7aa2-4c47-bba9-929bba2f0d49
模式：spec；时间：2026-10-17T13:48:36.881Z → 2026-10-17T13:48:36.883Z
需求来源：SCHEMA4-COMPATIBILITY；版本：1
清单批准：未批准候选
来源指纹：f3484aa7d143e06d90d53796545e8baa4b99be0b27f074ec8daf974bec10d908
契约指纹：5431e1a0b146353a0b278bd8805c0cfeedf97c4ca5facf1bf8a6623525d6df43
目标：http://127.0.0.1:51712/baseline?declared=spec

计划指纹：7b0002323db208355454c399e5ad87dbd7abf800e43e9afc7b9d74a365f5622b
验证器指纹：2e59d9d52a22a146e32c0cf3db32c4644c8e977d40ef927d365d4def4644b337

**门禁：阻断：存在未测/环境失败**

声明检查 1，已形成结果 1，完成可靠判定 0。
通过 0；失败 0；阻塞 1；待复核 0；目标缺陷 0；基线失败 0；缺测 0。

仅验收明确批准的 GET/HEAD 及声明的 HTTP、MIME、JSON 字段/响应 schema；不使用会话、不跟随重定向。候选、未覆盖契约、超时、超响应/验证预算均不能通过；无视觉、数据库、写操作、认证或任意业务状态机保证。来源指纹用于追溯，不代表系统已经证明原需求正确。

## 维度

| 维度 | 检查 | 通过 | 失败 | 阻塞 | 待复核 | 已测视觉分 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| visual | 0 | 0 | 0 | 0 | 0 | 未测 |
| structure | 0 | 0 | 0 | 0 | 0 | 未测 |
| behavior | 1 | 0 | 0 | 1 | 0 | 未测 |
| health | 0 | 0 | 0 | 0 | 0 | 未测 |

## 检查明细

| ID | 路由 | 视口 | 状态 | 归因 | 严重程度 |
| --- | --- | --- | --- | --- | --- |
| spec-1-STATUS | / | api | blocked | needs_review | high |

## 问题与证据

### spec-1-STATUS · 显式状态合同

结论：needs_review；证据等级：http-reproduced；参照：{"kind":"draft-spec","source":"SCHEMA4-COMPATIBILITY","revision":"1","sourceFingerprint":"f3484aa7d143e06d90d53796545e8baa4b99be0b27f074ec8daf974bec10d908","documentSha256":null,"contractFingerprint":"5431e1a0b146353a0b278bd8805c0cfeedf97c4ca5facf1bf8a6623525d6df43"}
预期：{"status":200}
实际：{"requested":false,"reason":"Requirement candidate has not been explicitly approved."}

复现步骤：

1. Use requirement SCHEMA4-COMPATIBILITY at revision 1.
2. GET http://127.0.0.1:51712/baseline?declared=%5Bredacted%5D without cookies or credentials; redirects are not followed.
3. Compare HTTP status, declared MIME and explicit JSON assertions/schema.

证据文件：

- contract：spec-1-STATUS-contract.json

## 边界

仅执行用户批准清单的 GET/HEAD，不跟随重定向、不携带会话或凭据。明确断言与支持的响应 schema 是本次真值；来源指纹用于追溯，不证明需求本身正确。未覆盖操作、未批准候选、网络/执行/响应/验证预算受阻不能通过。响应 JSON 保存在本地鉴权证据中；没有视觉、认证、数据库、写操作或完整业务状态机验收保证。
