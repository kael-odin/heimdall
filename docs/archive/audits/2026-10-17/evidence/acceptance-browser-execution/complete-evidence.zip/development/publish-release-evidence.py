import datetime, hashlib, json, pathlib, re, zipfile

repo = pathlib.Path.cwd()
runs = pathlib.Path('core/workspace/_runs')
public = pathlib.Path('docs/audits/2026-10-17/evidence/acceptance-browser-execution')
assert not public.exists(), 'Publication is immutable; choose a new directory.'
final = runs/'d3-final-publish-20261017'
regressions = runs/'d3-regression-publish-20261017'
ui = runs/'browser-execution-console-smoke-d3-publish-20261017'
groups = [('final-gates',final), ('regressions',regressions), ('ui-final',ui),
 ('second-final-gates',runs/'d3-final-release-20261017'),
 ('second-regressions',runs/'d3-regression-release-20261017'),
 ('second-ui-final',runs/'browser-execution-console-smoke-d3-release-20261017'),
 ('candidate-harness',runs/'d3-candidate-harness-20261017'),
 ('first-final-gates',runs/'d3-final-20261017'),
 ('first-regressions',runs/'d3-regression-originals-065e9a79-1880-49d8-a8d4-db174fa0e0c6'),
 ('first-ui-final',runs/'browser-execution-console-smoke-d3-final-20261017'),
 ('spec-verifier',runs/'d3-spec-verifier-20261017'),
 ('ui-first',runs/'browser-execution-console-smoke-d3-first-20261017'),
 ('development',runs/'d3-single-operation-20261017'), ('fixed-development',runs/'d3-fixed-runner-20261017'),
 ('fixed-fixtures',runs/'d3-fixed-runner-tests'), ('plan',runs/'d3-plan-20261017')]
read = lambda file: json.loads(file.read_bytes())
sha = lambda data: hashlib.sha256(data).hexdigest()
labels = ['console-build-final','syntax-final','browser-execution-ui-final','core-full','original-console',
 'owned-recovery','managed-execution-ui','browser-candidates','browser-bindings-v4','forge','console-cdp']
def gate(label):
 matches=list(final.glob(label+'-*'))
 assert len(matches)==1,(label,matches)
 return matches[0]
core = gate('core-full')
guard = read(core/'source-before.json')
assert len(guard)==578
def current_sources():
 for row in guard:
  data=(repo/row['path']).read_bytes()
  assert len(data)==row['bytes'] and sha(data)==row['sha256'],row['path']
current_sources()
gates=[]
for label in labels:
 folder=gate(label); result=read(folder/'summary.json')
 assert result['code']==0 and result['signal'] is None and result['sourcesUnchanged'] is True and result['sourceFileCount']==len(guard),(label,result)
 assert read(folder/'source-before.json')==guard and read(folder/'source-after.json')==guard,label
 gates.append(dict(label=label,**{key:'final-gates/'+folder.name+'/'+name for key,name in
  [('summary','summary.json'),('stdout','stdout.log'),('before','source-before.json'),('after','source-after.json')]}))
assert read(regressions/'results.json')['complete'] is True
assert read(ui/'summary.json')['status']=='passed' and read(ui/'summary.json')['checks']==16
assert len(read(ui/'checks.json'))==16 and all(read(ui/'checks.json').values())
assert read(ui/'browser-errors.json')['pageErrors']==[]
assert len(read(ui/'summary.json')['captures'])==7
stats={key:value for key,value in re.findall(r'(?m)^ℹ (tests|pass|fail|skipped|cancelled|todo|duration_ms) (.+)$',(core/'stdout.log').read_text(encoding='utf-8'))}
assert int(stats['tests'])==int(stats['pass'])+int(stats['skipped']) and int(stats['fail'])==0 and int(stats['cancelled'])==0 and int(stats['todo'])==0,stats
public.mkdir(parents=True)
(public/'.gitattributes').write_text('* -text\n',encoding='utf-8')
rows=[]; group_rows=[]; excluded=[]; scanned=0
patterns={
 'openai-secret':re.compile(rb'\bsk-[A-Za-z0-9_-]{24,}'),
 'github-token':re.compile(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{35,})'),
 'private-key':re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
 'aws-key':re.compile(rb'\bAKIA[A-Z0-9]{16}\b')}
with zipfile.ZipFile(public/'complete-evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for key,source in groups:
  assert source.is_dir(),source
  count=0; size=0
  for file in sorted(source.rglob('*')):
   assert not file.is_symlink(),file
   if file.is_dir(): continue
   assert file.is_file(),file
   relative=file.relative_to(source)
   if 'chromium-profile' in relative.parts:
    excluded.append(dict(group=key,sourcePath=file.as_posix(),reason='Chromium profile cache; local original retained')); continue
   name=key+'/'+relative.as_posix(); data=file.read_bytes()
   for rule,pattern in patterns.items(): assert not pattern.search(data),(rule,str(file))
   scanned+=len(data); count+=1; size+=len(data)
   rows.append(dict(group=key,path=name,sourcePath=file.as_posix(),bytes=len(data),sha256=sha(data)))
   archive.writestr(name,data)
  group_rows.append(dict(key=key,source=source.as_posix(),fileCount=count,bytes=size))
with zipfile.ZipFile(public/'complete-evidence.zip') as archive:
 assert archive.testzip() is None
 assert sorted(archive.namelist())==sorted(row['path'] for row in rows)
 for row in rows:
  data=archive.read(row['path']); assert len(data)==row['bytes'] and sha(data)==row['sha256']
copies=[]
def readable(name,original):
 row=next(row for row in rows if row['path']==original); data=pathlib.Path(row['sourcePath']).read_bytes()
 (public/name).write_bytes(data); copies.append(dict(file=name,originalPath=original,bytes=len(data),sha256=sha(data)))
for name in ['summary.json','checks.json','browser-errors.json','source-file-digests.json','layouts.json',
 'broken-complete-report.json','repaired-complete-report.json','ledger-initial.json','ledger-verified-passed.json','ledger-reopened.json',
 *read(ui/'summary.json')['captures']]: readable(name,'ui-final/'+name)
readable('final-sources.json','final-gates/'+core.name+'/source-before.json')
for entry in gates: readable('gate-'+entry['label']+'.json',entry['summary'])
readable('core-full.stdout.txt','final-gates/'+core.name+'/stdout.log')
for name in ['summary.json','remaining-summary.json','independent-source-review.json']:
 readable('spec-verifier-'+name,'spec-verifier/'+name)
readable('frontend-finish-review.md','development/frontend-finish-review.md')
readable('frontend-release-review.md','development/development/frontend-release-review.md')
readable('frontend-final-review.md','development/frontend-publish-review.md')
readable('spec-verifier-compatibility-review.md','development/spec-verifier-compatibility-review.md')
readable('lineage-reproduction.json','development/lineage/before-fix-reproduction.json')
archive=(public/'complete-evidence.zip').read_bytes()
index=dict(schemaVersion=1,createdAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),baselineHead='007760ed80019b4a5369ab284ea7ba734f18d0d2',
 groups=group_rows,originalRoots=[source.as_posix() for _,source in groups],originals=rows,excluded=excluded,archive=dict(file='complete-evidence.zip',bytes=len(archive),sha256=sha(archive),entries=len(rows),inflatedBytes=sum(row['bytes'] for row in rows)),
 readableCopies=copies,sourceGuard=dict(file='final-sources.json',sourceFileCount=len(guard)),finalGates=gates,
 anchors=dict(core={key:float(value) if key=='duration_ms' else int(value) for key,value in stats.items()},ui=dict(checks=16,screenshots=7),
 failures=['second-final-gates/browser-candidates-0b4a7f61-ba65-4eda-ab3a-c70303c02727/stderr.log','first-final-gates/core-full-fb0649d6-eeb0-4d08-bc9a-132918b2e58e/stdout.log','development/console-build-first/stderr.log','fixed-development/console-first.stdout.log','development/lineage/before-fix-reproduction.json']),
 publisherChecks=dict(zipCRC=True,allOriginalBytesMatched=True,allFinalSourcesMatched=True,highConfidenceCredentialBytesScanned=scanned,highConfidenceCredentialFindings=0),
 boundary='Controlled local fixtures. Browser single-operation execution and check issues only. Local success does not substitute the exact commit Linux CI. Profile caches excluded from archive and retained locally.')
for failure in index['anchors']['failures']: assert failure in [row['path'] for row in rows],failure
(public/'INDEX.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
current_sources()
print(json.dumps(dict(public=public.as_posix(),archive=index['archive'],groups=len(groups),readableCopies=len(copies),finalGates=len(gates),sourceFileCount=len(guard),core=index['anchors']['core'],excludedFiles=len(excluded)),ensure_ascii=False))
