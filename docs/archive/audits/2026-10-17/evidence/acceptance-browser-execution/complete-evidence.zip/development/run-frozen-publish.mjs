import fs from 'node:fs';
import path from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { spawn } from 'node:child_process';
const [label, command, ...args] = process.argv.slice(2);
if (!/^[a-z0-9-]+$/.test(label ?? '') || !command) throw Error('label and command required');
const root = process.cwd(), out = path.join(root, 'core/workspace/_runs/d3-final-publish-20261017', label + '-' + randomUUID());
fs.mkdirSync(out, { recursive: true });
const write = (name, value) => fs.writeFileSync(path.join(out, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
function sources() {
  const records = [];
  const add = key => { const bytes = fs.readFileSync(key); records.push({ path: key, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') }); };
  const visit = dir => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
      const key = dir + '/' + entry.name;
      if (entry.isDirectory()) visit(key); else if (entry.isFile()) add(key); else throw Error('Unexpected source entry: ' + key);
    }
  };
  for (const dir of ['core/src', 'core/scripts', 'core/test', 'console/src', '.github/workflows']) visit(dir);
  for (const key of ['package.json', 'core/package.json', 'console/package.json']) add(key);
  return records;
}
const before = sources(); write('source-before.json', before);
const startedAt = new Date().toISOString(), started = Date.now();
write('command.json', { cwd: root, command, args, startedAt, outputDirectory: out });
console.log(JSON.stringify({ event: 'started', label, out }));
const stdout = fs.openSync(path.join(out, 'stdout.log'), 'wx'), stderr = fs.openSync(path.join(out, 'stderr.log'), 'wx');
const child = spawn(command === 'node' ? process.execPath : command, args, { cwd: root, windowsHide: true, stdio: ['ignore', stdout, stderr] });
const result = await new Promise(resolve => {
  let error;
  child.once('error', cause => { error = cause.message; });
  child.once('close', (code, signal) => resolve({ code, signal, ...(error ? { error } : {}) }));
});
fs.closeSync(stdout); fs.closeSync(stderr);
const after = sources(); write('source-after.json', after);
const summary = { ...result, startedAt, finishedAt: new Date().toISOString(), wallTimeMs: Date.now() - started,
  sourcesUnchanged: JSON.stringify(before) === JSON.stringify(after), sourceFileCount: before.length };
write('summary.json', summary); console.log(JSON.stringify({ out, ...summary }));
console.log(fs.readFileSync(path.join(out, 'stdout.log'), 'utf8').slice(-3500));
console.error(fs.readFileSync(path.join(out, 'stderr.log'), 'utf8').slice(-2000));
process.exitCode = result.code === 0 && summary.sourcesUnchanged ? 0 : 1;
