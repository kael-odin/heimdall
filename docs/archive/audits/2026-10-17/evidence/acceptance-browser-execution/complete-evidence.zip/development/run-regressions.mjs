import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { spawn } from 'node:child_process';
const root = process.cwd(), out = path.join(root, 'core/workspace/_runs/d3-regression-originals-' + randomUUID());
fs.mkdirSync(out);
const jobs = [
  ['core-full', 'core/scripts/test-core.mjs'],
  ['original-console', 'core/scripts/smoke-acceptance-console.mjs'],
  ['owned-recovery', 'core/scripts/smoke-acceptance-owned-recovery.mjs'],
  ['managed-execution-ui', 'core/scripts/smoke-acceptance-execution-ui.mjs'],
  ['browser-candidates', 'core/scripts/smoke-acceptance-browser-candidates-console.mjs'],
  ['browser-bindings-v4', 'core/scripts/smoke-acceptance-browser-bindings-console.mjs'],
  ['forge', 'core/scripts/smoke-forge.mjs'],
  ['console-cdp', 'core/scripts/smoke-console-cdp.mjs'],
];
console.log(JSON.stringify({ event: 'regressions-started', out }));
const results = [];
for (const [label, script] of jobs) {
  const target = path.join(out, label);
  const args = ['core/workspace/_runs/d3-single-operation-20261017/run-frozen.mjs', label, 'node', script,
    ...(label === 'browser-bindings-v4' ? ['--migrate-catalog'] : []),
    ...(['forge', 'core-full'].includes(label) ? [] : [target])];
  console.log(JSON.stringify({ event: 'started', label }));
  const stdout = fs.openSync(path.join(out, label + '-wrapper-stdout.log'), 'wx');
  const stderr = fs.openSync(path.join(out, label + '-wrapper-stderr.log'), 'wx');
  const child = spawn(process.execPath, args, { cwd: root, windowsHide: true,
    env: { ...process.env, ...(label === 'console-cdp' ? { HEIMDALL_E2E_CDP_SELF: '1' } : {}) }, stdio: ['ignore', stdout, stderr] });
  const code = await new Promise((resolve, reject) => { child.once('error', reject); child.once('close', resolve); });
  fs.closeSync(stdout); fs.closeSync(stderr); results.push({ label, code });
  console.log(JSON.stringify({ event: 'finished', label, code }));
  if (code !== 0) { process.exitCode = 1; break; }
}
fs.writeFileSync(path.join(out, 'results.json'), JSON.stringify({ jobs: results, expected: jobs.length, complete: results.length === jobs.length && results.every(v => v.code === 0) }, null, 2) + '\n', { flag: 'wx' });
