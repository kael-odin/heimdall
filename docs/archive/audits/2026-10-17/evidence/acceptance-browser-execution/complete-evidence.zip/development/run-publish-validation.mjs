import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
const root = process.cwd();
const out = path.join(root, 'core/workspace/_runs/d3-regression-publish-20261017');
fs.mkdirSync(out);
const ui = path.join(root, 'core/workspace/_runs/browser-execution-console-smoke-d3-publish-20261017');
const jobs = [
  ['console-build-final', ['console/node_modules/vite/bin/vite.js', 'build', 'console', '--config', 'console/vite.config.js']],
  ['syntax-final', ['core/scripts/check-syntax.mjs']],
  ['browser-execution-ui-final', ['core/scripts/smoke-acceptance-browser-execution-console.mjs', ui]],
  ['core-full', ['core/scripts/test-core.mjs']],
  ['original-console', ['core/scripts/smoke-acceptance-console.mjs', path.join(out, 'original-console')]],
  ['owned-recovery', ['core/scripts/smoke-acceptance-owned-recovery.mjs', path.join(out, 'owned-recovery')]],
  ['managed-execution-ui', ['core/scripts/smoke-acceptance-execution-ui.mjs', path.join(out, 'managed-execution-ui')]],
  ['browser-candidates', ['core/scripts/smoke-acceptance-browser-candidates-console.mjs', path.join(out, 'browser-candidates')]],
  ['browser-bindings-v4', ['core/scripts/smoke-acceptance-browser-bindings-console.mjs', '--migrate-catalog', path.join(out, 'browser-bindings-v4')]],
  ['forge', ['core/scripts/smoke-forge.mjs']],
  ['console-cdp', ['core/scripts/smoke-console-cdp.mjs', path.join(out, 'console-cdp')]],
];
console.log(JSON.stringify({ event: 'release-validation-started', out, ui }));
const results = [];
for (const [label, scriptArgs] of jobs) {
  const args = ['core/workspace/_runs/d3-single-operation-20261017/run-frozen-publish.mjs', label, 'node', ...scriptArgs];
  console.log(JSON.stringify({ event: 'started', label }));
  const stdout = fs.openSync(path.join(out, label + '-wrapper-stdout.log'), 'wx');
  const stderr = fs.openSync(path.join(out, label + '-wrapper-stderr.log'), 'wx');
  const child = spawn(process.execPath, args, { cwd: root, windowsHide: true,
    env: { ...process.env, ...(label === 'console-cdp' ? { HEIMDALL_E2E_CDP_SELF: '1' } : {}) },
    stdio: ['ignore', stdout, stderr] });
  const code = await new Promise((resolve, reject) => { child.once('error', reject); child.once('close', resolve); });
  fs.closeSync(stdout); fs.closeSync(stderr); results.push({ label, code });
  console.log(JSON.stringify({ event: 'finished', label, code }));
  if (code !== 0) { process.exitCode = 1; break; }
}
fs.writeFileSync(path.join(out, 'results.json'), JSON.stringify({ jobs: results, expected: jobs.length,
  complete: results.length === jobs.length && results.every(value => value.code === 0) }, null, 2) + '\n', { flag: 'wx' });
