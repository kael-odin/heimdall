"""Read-only D3 publication checks. Only the separate --output directory is written."""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import time
import uuid
import zipfile

PUBLIC = "docs/audits/2026-10-17/evidence/acceptance-browser-execution"
INDEX = PUBLIC + "/INDEX.json"
HASH = re.compile(r"^[0-9a-f]{64}$")
SOURCE_DIRS = ("core/src", "core/scripts", "core/test", "console/src", ".github/workflows")
SOURCE_FILES = ("package.json", "core/package.json", "console/package.json")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def rel(value):
    require(isinstance(value, str) and value and "\\" not in value and ":" not in value,
            "Unsafe or missing relative path: " + repr(value))
    path = PurePosixPath(value)
    require(not path.is_absolute() and all(p not in ("", ".", "..") for p in value.split("/")),
            "Unsafe relative path: " + value)
    return value


def integer(value):
    return isinstance(value, int) and not isinstance(value, bool) and value >= 0


def digest(value):
    return hashlib.sha256(value).hexdigest()


def loaded(value, label):
    try:
        return json.loads(value.decode("utf-8-sig"))
    except (ValueError, UnicodeError) as exc:
        raise ValueError("Invalid JSON: " + label) from exc


class Publication:
    def __init__(self, root, staged):
        self.root, self.staged = root, staged
        self.checks = []
        self.index_state = self.git("ls-files", "--stage", "-z") if staged else None

    def git(self, *args):
        result = subprocess.run(["git", *args], cwd=self.root, capture_output=True, check=False)
        require(result.returncode == 0, "git read failed: " + " ".join(args) + ": " + result.stderr.decode("utf-8", "replace")[:1000])
        return result.stdout

    def local(self, name):
        name = rel(name)
        path = self.root / Path(name)
        require(path.resolve().is_relative_to(self.root), "Local path escapes checkout: " + name)
        before = path.stat(follow_symlinks=False)
        require(stat.S_ISREG(before.st_mode) and not path.is_symlink(), "Not an ordinary local file: " + name)
        value = path.read_bytes()
        after = path.stat(follow_symlinks=False)
        require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
                == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
                "Local file changed while reading: " + name)
        return value

    def read(self, name):
        name = rel(name)
        return self.git("show", ":" + name) if self.staged else self.local(name)

    def match(self, value, record, label):
        require(integer(record.get("bytes")) and isinstance(record.get("sha256"), str) and HASH.fullmatch(record["sha256"]),
                "Invalid byte/hash metadata: " + label)
        require(len(value) == record["bytes"] and digest(value) == record["sha256"], "Byte/hash mismatch: " + label)

    def checked(self, label, **details):
        self.checks.append({"label": label, **details})

    def source_names(self):
        if self.staged:
            entries = self.git("ls-files", "--stage", "-z", "--", *SOURCE_DIRS, *SOURCE_FILES).split(b"\0")
            result = []
            for entry in filter(None, entries):
                header, raw_name = entry.split(b"\t", 1)
                mode, _oid, stage = header.split(b" ")
                require(stage == b"0" and mode in (b"100644", b"100755"), "Unmerged or non-regular staged source")
                result.append(rel(raw_name.decode("utf-8")))
            return set(result)
        names = set(SOURCE_FILES)
        for source_dir in SOURCE_DIRS:
            for current, directories, files in os.walk(self.root / source_dir, followlinks=False):
                for directory in directories:
                    require(not (Path(current) / directory).is_symlink(), "Symlink in source inventory")
                for file in files:
                    target = Path(current) / file
                    require(not target.is_symlink() and target.is_file(), "Non-regular source entry")
                    names.add(target.relative_to(self.root).as_posix())
        return names

    def snapshot(self, raw, label, count):
        records = loaded(raw, label)
        require(isinstance(records, list) and len(records) == count, "Wrong source snapshot count: " + label)
        result = {}
        for record in records:
            require(isinstance(record, dict), "Invalid source snapshot item: " + label)
            name = rel(record.get("path"))
            require(name not in result and integer(record.get("bytes")) and HASH.fullmatch(record.get("sha256", "")),
                    "Invalid or repeated source snapshot entry: " + label)
            result[name] = (record["bytes"], record["sha256"])
        return result

    def verify(self, index_bytes):
        index = loaded(index_bytes, INDEX)
        require(isinstance(index, dict), "INDEX must be an object")
        archive = index["archive"]
        archive_name = rel(archive["file"])
        archive_bytes = self.read(PUBLIC + "/" + archive_name)
        self.match(archive_bytes, archive, "archive")
        require(isinstance(index.get("originals"), list) and isinstance(index.get("readableCopies"), list), "Missing publication manifests")
        with zipfile.ZipFile(io.BytesIO(archive_bytes)) as package:
            infos = package.infolist()
            names = [info.filename for info in infos]
            require(len(names) == len(set(names)), "Repeated ZIP member")
            for info in infos:
                rel(info.filename.rstrip("/"))
                require(not stat.S_ISLNK(info.external_attr >> 16), "ZIP contains a symlink")
            require(package.testzip() is None, "ZIP CRC check failed")
            entry_spec = archive["entries"]
            require((integer(entry_spec) and len(infos) == entry_spec)
                    or (isinstance(entry_spec, list) and sorted(names) == sorted(entry_spec)), "Wrong ZIP entry set/count")
            members = {info.filename for info in infos if not info.is_dir()}
            manifest = {}
            source_paths = {}
            for original in index["originals"]:
                name, source = rel(original["path"]), rel(original["sourcePath"])
                require(name not in manifest and source not in source_paths, "Repeated original path/source")
                require(name in members, "Original missing from ZIP: " + name)
                require("chromium-profile" not in PurePosixPath(source).parts, "Chrome profile included as an original")
                value = package.read(name)
                self.match(value, original, name)
                require(value == self.local(source), "Archived original differs from the current local original: " + source)
                manifest[name], source_paths[source] = original, name
            require(members == set(manifest), "ZIP contains unindexed originals or manifest omissions")
            self.checked("archive CRC, member set, all original byte/hash and local equality", entries=len(members), bytes=len(archive_bytes))

            excluded = index.get("excluded")
            require(isinstance(excluded, list), "Missing excluded manifest")
            excluded_roots = set()
            for item in excluded:
                value = item if isinstance(item, str) else item.get("sourcePath", item.get("path"))
                value = rel(value)
                parts = PurePosixPath(value).parts
                require("chromium-profile" in parts, "Exclusion is not a Chrome profile: " + value)
                excluded_roots.add("/".join(parts[:parts.index("chromium-profile") + 1]))
            roots = index.get("originalRoots")
            require(isinstance(roots, list) and roots and len(roots) == len(set(roots)), "Missing or repeated originalRoots")
            local_files, found_excluded = set(), set()
            for root in roots:
                root = rel(root)
                directory = self.root / root
                require(directory.is_dir() and not directory.is_symlink(), "Invalid original root: " + root)
                for current, directories, files in os.walk(directory, followlinks=False):
                    if "chromium-profile" in directories:
                        found_excluded.add((Path(current) / "chromium-profile").relative_to(self.root).as_posix())
                        directories.remove("chromium-profile")
                    for child in directories:
                        require(not (Path(current) / child).is_symlink(), "Symlink in original root")
                    for file in files:
                        target = Path(current) / file
                        require(target.is_file() and not target.is_symlink(), "Non-regular original file")
                        local_files.add(target.relative_to(self.root).as_posix())
            require(local_files == set(source_paths), "Local original roots contain omitted or unexpected files")
            require(found_excluded == excluded_roots, "Excluded Chrome profile roots do not match local originals")
            self.checked("complete local original roots with Chrome profile exclusions", roots=len(roots), files=len(local_files), excludedRoots=len(found_excluded))

            groups = index.get("groups")
            if groups is not None:
                require(isinstance(groups, list) and len(groups) == len(roots), "Wrong group inventory")
                seen = set()
                for group in groups:
                    source = rel(group["source"])
                    require(source in roots and source not in seen and isinstance(group.get("key"), str), "Invalid group mapping")
                    seen.add(source)
                    selected = [original for original in manifest.values() if original["sourcePath"].startswith(source + "/")]
                    require(group.get("fileCount") == len(selected) and group.get("bytes") == sum(v["bytes"] for v in selected), "Group totals disagree: " + source)
                self.checked("all source group counts and byte totals", groups=len(groups))

            copies = {}
            for copy in index["readableCopies"]:
                file, original = rel(copy["file"]), rel(copy["originalPath"])
                require(file not in copies and original in members, "Invalid or repeated readable copy")
                value = self.read(PUBLIC + "/" + file)
                self.match(value, copy, file)
                require(value == package.read(original), "Readable copy differs from ZIP original: " + file)
                copies[file] = copy
            self.checked("all public readable copies", copies=len(copies))

            guard = index["sourceGuard"]
            count = guard["sourceFileCount"]
            require(count == 578 and integer(count), "Final source guard must cover 578 files")
            guard_name = rel(guard["file"])
            require(guard_name in copies, "Source guard must be an indexed readable copy")
            guard_snapshot = self.snapshot(self.read(PUBLIC + "/" + guard_name), guard_name, count)
            require(self.source_names() == set(guard_snapshot), "Current source inventory differs from 578-file guard")
            for name, (length, sha256) in guard_snapshot.items():
                value = self.read(name)
                require(len(value) == length and digest(value) == sha256, "Current source differs from final guard: " + name)
            self.checked("578 current source files and exact inventory", sourceFileCount=count, mode="staged git show" if self.staged else "working tree")

            gates = index["finalGates"]
            require(isinstance(gates, list) and gates, "Missing final gates")
            labels = set()
            for gate in gates:
                label = gate["label"]
                require(isinstance(label, str) and label not in labels, "Invalid or repeated final gate")
                labels.add(label)
                paths = [rel(gate[key]) for key in ("summary", "stdout", "before", "after")]
                require(all(name in members for name in paths), "Final gate path is outside archive originals: " + label)
                summary = loaded(package.read(paths[0]), paths[0])
                require(isinstance(summary, dict) and summary.get("code") == 0 and not isinstance(summary.get("code"), bool)
                        and summary.get("sourcesUnchanged") is True and summary.get("sourceFileCount") == count,
                        "Final gate did not pass with unchanged sources: " + label)
                before, after = (self.snapshot(package.read(name), name, count) for name in paths[2:])
                require(before == after == guard_snapshot, "Final gate source snapshots differ: " + label)
                self.checked("final gate passed with exact frozen source snapshots", gate=label, sourceFileCount=count)
            if self.staged:
                require(self.git("ls-files", "--stage", "-z") == self.index_state, "Git index changed during staged verification")
            self.checked("publication verification complete", finalGates=len(gates), mode="staged" if self.staged else "working")
        return {"originalFiles": len(manifest), "readableCopies": len(copies), "sourceFileCount": count,
                "finalGates": len(gates), "archiveSha256": digest(archive_bytes), "indexSha256": digest(index_bytes)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[4])
    parser.add_argument("--staged", action="store_true", help="Read every public object and guarded source using git show :path")
    parser.add_argument("--output", type=Path, help="Separate output directory; defaults to an isolated ignored run")
    parser.add_argument("--wait-seconds", type=float, default=0)
    args = parser.parse_args()
    root = args.root.resolve()
    output = (args.output or root / "core/workspace/_runs" / ("d3-publication-verification-" + str(uuid.uuid4()))).resolve()
    require(not output.is_relative_to(root / PUBLIC), "Verification output must be separate from the publication")
    output.mkdir(parents=True, exist_ok=False)
    started = time.time()
    result = {"mode": "staged" if args.staged else "working", "index": INDEX, "readOnlyPublication": True, "checks": []}
    code = 1
    verifier = None
    try:
        deadline = started + max(0, args.wait_seconds)
        while True:
            try:
                verifier = Publication(root, args.staged)
                index_bytes = verifier.read(INDEX)
                break
            except (ValueError, FileNotFoundError):
                if time.time() >= deadline:
                    raise
                time.sleep(min(2, max(.01, deadline - time.time())))
        result.update(verifier.verify(index_bytes))
        code = 0
    except Exception as exc:
        result["error"] = type(exc).__name__ + ": " + str(exc)
    finally:
        if verifier:
            result["checks"] = verifier.checks
        result.update({"passed": code == 0, "exitCode": code, "wallTimeSeconds": round(time.time() - started, 3)})
        (output / "verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps({"output": str(output), **result}, ensure_ascii=False, indent=2))
    return code


if __name__ == "__main__":
    sys.exit(main())
