# 第三轮 managed UI 严格控制台失败的只读复核

审查日期：2026-10-17。本记录只读取已存在的 smoke 原件、wrapper 结果及脚本源码；没有修改源码、断言、错误过滤、超时或既有原件，没有运行测试或启动 Browser。本记录是独立新增文件，不替代失败原件，也不将此门禁改记为通过。

原件根为 `core/workspace/_runs/d3-regression-publish-20261017/managed-execution-ui/`；封包映射为 `pre-normalization-regressions/managed-execution-ui/`。wrapper 原件根为 `core/workspace/_runs/d3-final-publish-20261017/managed-execution-ui-b3c1f4a3-9817-4a51-bb83-bda976a5da31/`，封包映射为 `pre-normalization-final-gates/managed-execution-ui-b3c1f4a3-9817-4a51-bb83-bda976a5da31/`。

## 实际结果

wrapper `summary.json` 记录运行时段为 **2026-10-17 13:18:16.678–13:19:52.906 UTC**，即香港时间 **21:18:16.678–21:19:52.906**；exit code **1**，signal 为 null，578 项源码前后字节一致。此为第三轮归一化前结果，不能代替 LF 归一化后的最终验证。

`failure.json` 保存了 **16 个业务检查，全部为 true**，以及以下八个已完成场景：

- `native-completed-bug`
- `lost-response-reload-only-gets`
- `html502-reload-only-gets`
- `native-stop-interrupted`
- `late-operation-lookup-aba`
- `prepared-query-only`
- `unknown-404-stays-unresolved`
- `stale-cas-explicit-rejection`

`core/scripts/smoke-acceptance-execution-ui.mjs` 的最终顺序为：执行真实启动场景、执行不启动场景、核对所有来源原件与模型请求，最后在第 553 行执行 `assert.deepEqual(pageErrors, [])`。本次堆栈和 wrapper `stderr.log` 均指向该最后断言，实际数组只有一项：

```text
Failed to load resource: net::ERR_NO_BUFFER_SPACE
```

因此可确认业务检查已完成，但完整 smoke 仍因严格错误断言失败。脚本变量 `pageErrors` 同时汇集 `pageerror` 事件与未列入预期过滤的 console error / warning；不能仅凭变量名将这条资源错误称为页面 JavaScript 异常。

## 来源、请求与最后界面

`fixture-0-source-before.json` 与 `fixture-0-source-after.json` 相等，`fixture-1` 对应两文件也相等；每组各含五个来源文件。两组 `model-requests.json` 都是空数组。

`fixture-0-target-requests.json` 记录八次 GET：三对 `/target/healthy`、`/target/bug` 共六次完成，`/ordinary-hold` 与取消场景的最后一次 `/target/healthy` 均已关闭且未完成，符合被中断场景。`fixture-1-target-requests.json` 为空数组，支持 prepared、未知操作查询与旧 CAS 拒绝未启动目标的业务检查。

`failure-dom.txt` 与最后场景的 `execution-stale-cas-requires-new-review-desktop-dom.txt` 原字节 SHA 相同；`failure.png` 与 `execution-stale-cas-requires-new-review-desktop.png` 原字节 SHA 也相同。DOM 显示 `STALE_REVISION`，明确说明请求未被接纳、需要重新核对目录、合同与目标。没有发现该最终界面与已通过旧 CAS 检查矛盾的事实。本复核只比较截图文件字节及 DOM，没有重新目视打开 PNG。

## 不能从原件确证的部分

原脚本的 console handler 只保存 `message.text()`；没有记录 `message.location()`、时间戳或 `requestfailed` 对应关系。`failure.json` 的 354 条 `browserRequests` 只保留 method / path 和 POST body，不含响应状态、网络失败或事件时间。因此不能把这一错误绑定到某个具体请求，也不能证明它首次发生于最后的 stale CAS 场景。最后断言使用的是整个 smoke 期间累计数组。

请求记录中存在 `/api/acceptance/runs`、`/api/acceptance/execution`、项目 `browser-executions` 等轮询；这只能证明它们被请求过，不是某条轮询发生错误的证据。

`chromium.log` 记录了扩展注册路径提示和 `DEPRECATED_ENDPOINT`，没有 `ERR_NO_BUFFER_SPACE`、对应请求 URL 或可用于关联该资源错误的时间。不能将这些 Chromium 后台日志视为此错误的原因。

本轮证据支持“严格 console 断言捕获一次资源错误，16 项业务检查均已通过，完整门禁失败”。其具体请求、首次发生阶段及是否为操作系统资源耗尽仍未确证。后续隔离复验与最终完整门禁应使用新目录保留独立原件，不能通过放宽断言、过滤或超时将本次失败改写为通过。
