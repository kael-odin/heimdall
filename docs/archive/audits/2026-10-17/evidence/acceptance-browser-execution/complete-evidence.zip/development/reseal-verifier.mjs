import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const sha = value => createHash('sha256').update(value).digest('hex');
const names = ['schema.mjs', 'urls.mjs', 'runner.mjs', 'report.mjs', 'spec-schema.mjs',
  'spec-runner.mjs', 'response-schema.mjs', 'openapi.mjs', 'identity.mjs', '../verify/compare.mjs'];
const texts = names.map(name => readFileSync('core/src/acceptance/' + name, 'utf8').replaceAll('\r\n', '\n'));
const fingerprint = values => sha(values.slice(0, -1).join('\n') + values.at(-1));
const lfFingerprint = fingerprint(texts), crlfFingerprint = fingerprint(texts.map(v => v.replaceAll('\n', '\r\n')));
const path = 'core/test/fixtures/browser-verifier-reviewed-d3.json';
const manifest = JSON.parse(readFileSync(path, 'utf8'));
assert.equal(manifest.lfFingerprint, '91474a7b1b010b331cf7566fcb3fd15a163e841bd75ab9089c60602dc66bb3b4');
assert.equal(manifest.crlfFingerprint, '1a6b863fa8e89d4053cd95581121c170b5543e3c2b4d09bc249d1b59180649a5');
for (const file of ['core/src/acceptance/browser-candidate-projection.mjs', 'core/test/acceptance-browser-candidate-projection.test.mjs']) {
  let source = readFileSync(file, 'utf8');
  for (const [before, after] of [[manifest.lfFingerprint, lfFingerprint], [manifest.crlfFingerprint, crlfFingerprint]]) {
    assert.equal(source.split(before).length, 2); source = source.replace(before, after);
  }
  writeFileSync(file, source);
}
manifest.lfFingerprint = lfFingerprint; manifest.crlfFingerprint = crlfFingerprint;
manifest.files = names.map((name, i) => ({ name, lfSha256: sha(texts[i]), crlfSha256: sha(texts[i].replaceAll('\n', '\r\n')) }));
writeFileSync(path, JSON.stringify(manifest, null, 2) + '\n');
console.log(JSON.stringify(manifest, null, 2));
