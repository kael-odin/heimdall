import hashlib
import json
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parents[4]
output = Path(__file__).resolve().parent
pattern = '|'.join([
    'candidate approval and selection writes each have exactly one double-CAS winner',
    'late source corruption after rolling backup and before head publication rejects candidate/approval/selection',
    'owner loss after rolling backup rejects each baseline write without publishing an event',
    'legacy Spec API can bind, create/read a candidate, approve, select and cancel alongside Browser history',
])
args = ['node', '--test', '--test-concurrency=1', '--test-name-pattern=' + pattern,
        'core/test/acceptance-baseline-catalog.test.mjs', 'core/test/acceptance-baseline-integrity.test.mjs',
        'core/test/acceptance-browser-binding-api.test.mjs']
inventory = json.loads((output / 'source-after.json').read_bytes())

def snapshot():
    return [dict(path=row['path'], bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
            for row in inventory for data in [(root / row['path']).read_bytes()]]

def write(name, value):
    with (output / name).open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')

before = snapshot()
write('remaining-source-before.json', before)
write('remaining-command.json', dict(cwd=str(root), command=args))
started = time.time()
with (output / 'remaining-stdout.log').open('xb') as stdout, (output / 'remaining-stderr.log').open('xb') as stderr:
    completed = subprocess.run(args, cwd=root, stdout=stdout, stderr=stderr, check=False)
after = snapshot()
write('remaining-source-after.json', after)
result = dict(code=completed.returncode, sourcesUnchanged=before == after == inventory,
              sourceFileCount=len(before), wallTimeSeconds=round(time.time() - started, 3))
write('remaining-summary.json', result)
print(json.dumps(result))
print((output / 'remaining-stdout.log').read_text(encoding='utf-8')[-5000:])
print((output / 'remaining-stderr.log').read_text(encoding='utf-8')[-2000:])
raise SystemExit(0 if completed.returncode == 0 and result['sourcesUnchanged'] else 1)
