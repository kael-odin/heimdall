import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const root = process.cwd(), output = path.dirname(fileURLToPath(import.meta.url));
const write = (name, value) => fs.writeFileSync(path.join(output, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
function sources() {
  const rows = [];
  const add = key => { const data = fs.readFileSync(key); rows.push({ path: key, bytes: data.length, sha256: createHash('sha256').update(data).digest('hex') }); };
  const visit = directory => {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
      const key = directory + '/' + entry.name;
      if (entry.isDirectory()) visit(key); else if (entry.isFile()) add(key); else throw Error('Unexpected source entry: ' + key);
    }
  };
  for (const directory of ['core/src', 'core/scripts', 'core/test', 'console/src', '.github/workflows']) visit(directory);
  for (const key of ['package.json', 'core/package.json', 'console/package.json']) add(key);
  return rows;
}
const args = ['--test', '--test-concurrency=1', 'core/test/acceptance-candidate-projection.test.mjs', 'core/test/acceptance-managed-spec-plan.test.mjs'];
const before = sources(); write('source-before.json', before);
write('command.json', { cwd: root, command: process.execPath, args });
const stdout = fs.openSync(path.join(output, 'stdout.log'), 'wx'), stderr = fs.openSync(path.join(output, 'stderr.log'), 'wx');
const started = Date.now(), startedAt = new Date().toISOString();
const child = spawn(process.execPath, args, { cwd: root, windowsHide: true, stdio: ['ignore', stdout, stderr] });
const result = await new Promise(resolve => child.once('close', (code, signal) => resolve({ code, signal })));
fs.closeSync(stdout); fs.closeSync(stderr);
const after = sources(); write('source-after.json', after);
const summary = { ...result, startedAt, finishedAt: new Date().toISOString(), wallTimeMs: Date.now() - started,
  sourcesUnchanged: JSON.stringify(before) === JSON.stringify(after), sourceFileCount: before.length };
write('summary.json', summary); console.log(JSON.stringify(summary));
console.log(fs.readFileSync(path.join(output, 'stdout.log'), 'utf8').slice(-4000));
console.error(fs.readFileSync(path.join(output, 'stderr.log'), 'utf8').slice(-2000));
process.exitCode = result.code === 0 && summary.sourcesUnchanged ? 0 : 1;
