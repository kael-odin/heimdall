"""Independent, read-only comparison of the frozen Spec verifier inputs."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

root = Path(__file__).resolve().parents[4]
output = Path(__file__).resolve().parent
names = ['schema.mjs', 'urls.mjs', 'runner.mjs', 'report.mjs', 'spec-schema.mjs',
         'spec-runner.mjs', 'response-schema.mjs', 'openapi.mjs', 'identity.mjs', '../verify/compare.mjs']
sha = lambda value: hashlib.sha256(value).hexdigest()
normalize = lambda value: value.replace(b'\r\n', b'\n')
paths = [(Path('core/src/acceptance') / name).as_posix() for name in names]
paths = [str(Path(path)).replace('\\', '/') for path in paths]
paths[-1] = 'core/src/verify/compare.mjs'
current = [(root / path).read_bytes() for path in paths]
old = [subprocess.run(['git', 'show', 'HEAD:' + path], cwd=root, check=True, capture_output=True).stdout for path in paths]
changed = [name for name, before, after in zip(names, old, current) if normalize(before) != normalize(after)]
assert changed == ['runner.mjs'], changed

def delegation(value):
    value = normalize(value).decode('utf-8')
    found = re.search(r'export async function runAcceptance\(plan, \{ runId = randomUUID\(\), outputDir, onEvent \} = \{\}\) \{\n'
                      r'  if \(plan\?\.mode === \'spec\'\) \{\n'
                      r'    const \{ runSpecAcceptance \} = await import\(\'\./spec-runner\.mjs\'\);\n'
                      r'    return runSpecAcceptance\(plan, \{ runId, outputDir, onEvent \}\);\n  \}', value)
    assert found, 'Exact early Spec delegation was not found'
    return found.group()

assert delegation(old[2]) == delegation(current[2])
fingerprint = lambda values: sha(b'\n'.join(values[:-1]) + values[-1])
lf = list(map(normalize, current))
crlf = [value.replace(b'\n', b'\r\n') for value in lf]
manifest = json.loads((root / 'core/test/fixtures/browser-verifier-reviewed-d3.json').read_bytes())
assert fingerprint(lf) == manifest['lfFingerprint'] == '2e59d9d52a22a146e32c0cf3db32c4644c8e977d40ef927d365d4def4644b337'
assert fingerprint(crlf) == manifest['crlfFingerprint'] == '270251e1ca417383ee019a456d1a103ec461c57a9a8c661fdc9ff562cac515f2'
assert manifest['files'] == [dict(name=name, lfSha256=sha(a), crlfSha256=sha(b)) for name, a, b in zip(names, lf, crlf)]
rows = [dict(path=path, currentBytes=len(after), currentSha256=sha(after),
             headLfSha256=sha(normalize(before)), currentLfSha256=sha(normalize(after)),
             normalizedUnchanged=normalize(before) == normalize(after)) for path, before, after in zip(paths, old, current)]
result = dict(passed=True, evidenceLevel='independent-source-byte-comparison',
              browserLaunched=False, networkRequests=0, changedVerifierInputs=changed,
              unchangedInputs=9, exactEarlySpecDelegationUnchanged=True,
              manifest='core/test/fixtures/browser-verifier-reviewed-d3.json',
              lfFingerprint=fingerprint(lf), crlfFingerprint=fingerprint(crlf),
              actualFingerprint=fingerprint(current), files=rows)
(output / 'independent-source-review.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
