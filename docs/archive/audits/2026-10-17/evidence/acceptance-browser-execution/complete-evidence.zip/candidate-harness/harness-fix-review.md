# Browser candidates harness 停机顺序修复记录

日期：2026-10-17（Asia/Hong_Kong）。只修订 `core/scripts/smoke-acceptance-browser-candidates-console.mjs` 的两处测试页面生命周期：主动停止引擎前，先等待同一 page 导航至 `about:blank` 的 load。没有修改产品实现、业务断言、超时、错误收集或允许错误规则。

## 原失败与根因

原失败完整保留于 `../d3-regression-release-20261017/browser-candidates/`，没有覆盖或改写为通过。其 `failure.json` 显示 12 项业务检查已完成，最终严格 console 断言拒绝一条 `ERR_CONNECTION_REFUSED`；`browser-errors.json` 的 pageErrors 为 0，HTTP 错误只有原先注入的 POST 502。

失效 GET 为旧首引擎 `http://127.0.0.1:60530/api/acceptance/runs`；受控 POST 502 属于迁移后引擎端口 54134。脚本第 159 行在维护提示/schema3/无写入断言完成后直接停止首引擎，旧控制台页面仍运行。`AcceptanceWorkbench.vue` 的 `loadRuns()` 会在 finally 中以 2000ms 继续轮询，停机及离线 CLI 迁移窗口使旧页面请求命中已关闭端口，错误留在跨导航累积的 consoleMessages 中，最终被第 247 行正确拒绝。

第 238 行持久化重启同样采用了先停引擎、后新 origin 导航的顺序，存在相同生命周期竞态，故同步修正。这里没有把断言失败解释成产品通过，而是纠正 harness 主动制造的无关停机请求后重新完整运行该专项。

## 最小变更及语义边界

第 159、238 行的 `stop(engine)` 前各插入一次：

```js
await page.goto('about:blank', { waitUntil: 'load' });
```

等待导航完成发生于引擎仍存活时；旧 document 的定时器及请求生命周期先结束，再停引擎、运行 CLI 或重启。复用同一 page/context，保留上下文配置、init scripts 和既有浏览器级事件收集，随后仍经 `openConsole()` 导航至新引擎读取真实数据。没有清空错误数组或移除监听器。

- 离线迁移仍先在真实 UI 断言 schema3 维护提示、head 未变、零候选 POST，再等待旧引擎退出，执行真实 CLI preview/apply，普通重启后验证 schema4。
- 重启前仍关闭复核并断言所有 Blob 释放，再取 head 原字节；重启后仍读取同一候选、比较 head 原字节，检查无额外写入。原场景本来就通过新 origin 整页导航重建页面，本次没有取消同文档重连检查，因为该场景原先没有声明该检查。
- 两个位置均无未完成的写操作；此前设置的延迟响应在第二处之前已经 release 并 dispose。故本次未新增 API 排空等待、固定延时或网络错误豁免。若后续复跑出现新的在途请求失败，应按原件继续定位，不能扩大允许错误集合。
- 第 246–248 行的 pageErrors、HTTP 错误精确匹配、仅指定 POST 502 的 console 规则及最多 1 条 console 的断言全部原样保留；15 秒默认页面/等待超时未变。

子代理另行完成独立只读源码复核，认为两处顺序修改保留旧场景语义且无需额外 drain；其结论是源码审查，不替代下列真实运行。

## 专项真实回归

命令（cwd 为仓库 core）：

```powershell
node scripts/smoke-acceptance-browser-candidates-console.mjs workspace/_runs/d3-candidate-harness-20261017
```

仓库原生 Playwright CDP harness 实际运行，进程退出码 0。`browser-checks.json`：passed，13/13，包含此前未到达的 `onlyExactInjectedPOST502IsAllowed: true`。起止为 2026-10-17 12:57:33.251–12:58:19.310 UTC，即香港时间 20:57:33.251–20:58:19.310。

| 原件指标 | 修复后结果 |
| --- | --- |
| pageErrors | 0 |
| consoleMessages | 1，仅指定丢 201 回复的受控 POST 502 |
| httpErrors | 1，仅同一受控 POST 502 |
| ERR_CONNECTION_REFUSED | 0 |
| browserCandidatePostCount | 2 |
| captureTargetRequests | 16 |
| candidateAndReadTargetRequests | 0 |
| explicitOfflineCLIUpgradeThenOrdinaryRestart | true |
| restartReadsSameDurableCandidateWithoutWrites | true |
| noExtraTargetRequestsOrExecutionAndAllSourceBytesUnchanged | true |
| executionReady | false |

CLI preview/apply 的命令、stdout/stderr 保留在本目录 `maintenance-*` 原件中；迁移仍为 schema3→4，apply 退出码由原 harness 严格检查。完整候选复核、显式确认、保存、丢回复只读对账、坏源恢复、图片字节校验、项目 ABA、Blob 释放、隐私和持久重启检查均由这次原始 13 项结果覆盖。

`node --check` 与该脚本 `git diff --check` 均通过。源码 diff 只有上述两行导航插入。修复后脚本 SHA-256：`baf1eb5935faa955b89ccf948c9c519ddf0d0dbf72803ae372c0c128ee6bacab`。

这是该专项的一次新鲜真实回归，不替代最终 11 组发布门禁。主代理应在采纳两行 harness 修改后重新冻结源码并完整运行门禁；原先失败及其他 release 证据继续保留。
