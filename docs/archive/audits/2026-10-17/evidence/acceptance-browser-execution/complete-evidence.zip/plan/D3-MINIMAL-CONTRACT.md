# D3 可实施最小合同：单次批准、固定来源执行与持久失败检查

2026-10-17。最新结论，优先于同目录 PLAN.md 的“长期批准/选用”初案。

根任务已确认 D2 推送 main：`007760ed80019b4a5369ab284ea7ba734f18d0d2`；自身 CI `39026482495` 正在运行，尚不能称远端通过。本任务仅只读分析并写 ignored 规划文件，没有实施、浏览器运行、提交或推送。

## 1. 产品决定

**D3 每次由用户明确“批准此候选用于本次目标验收”，授权仅绑定此 operation。** 不建立全局当前 Browser 基线，不新增长期 approval/selection store，不升 Schema5，不复用 Spec aa/as，不修改 D2 保存候选的 `executionReady:false`。

这能安全删除一整层生命周期与迁移工程。执行 operation 的不可变 dispatch 本来就需要持久保存，它兼任本次批准事实。每次重新复核确认是清楚的产品行为；以后确需长期选用时，再将“当前已选基线”作为生成下一次确认的便利入口。

最小演示：读取已有 bc 全合同 → 明确 target release → 勾选本次批准并启动 → source HTTP 已关闭仍只请求 target → 真实差异与行为 BUG → 明确登记失败检查 → 刷新/重启同 ID → 修复目标后新 operation 与明确 before/after 复验 → 持久记录可靠通过。

## 2. 接纳 API 和固定 dispatch

```text
GET  /api/acceptance/browser-execution
POST /api/acceptance/projects/:ap/browser-executions
GET  /api/acceptance/projects/:ap/browser-executions/:operationId
POST /api/jobs/:taskId/cancel                     # 原取消入口
```

POST 严格六字段，不接 URL、plan、expected、approved、阈值、mask、证据或run/task：

```js
{ operationId, expectedGenerationId, expectedRevision,
  candidateId /* bc */, contentDigest, targetReleaseId /* ar */ }
```

令牌鉴权后的专用 POST 就是调用方明确的一次批准请求；前端checkbox是防误操作确认，不再多存一个可被当权限的 approved:true。

dispatch新严格版本使用独立Browser discriminator/namespace，包含：

```js
{
  schemaVersion: 1,
  operationId, dispatchId, runId, taskId, acceptedAt,
  request, requestFingerprint,
  catalog: { generationId, revision, headSha256 },
  project, candidate, sourceBinding, sourceRelease, targetRelease,
  approval: {
    scope: 'single-operation', candidateId, contentDigest,
    targetReleaseId, approvedAt, actor
  },
  contract, contractFingerprint,
  executor: 'engine-owner-browser-v1'
}
```

这里 candidate/binding/release 是现有严格实体的实际快照，不是客户端DTO。contract只含执行所需的完整scope、规则、所选oracles、选侧证据索引、来源/组织摘要、环境、固定target；不为了纯防御重复保存整份12MiB review和另一个同义manifest。预检完整字节上限，拒绝静默截断。

目录队列内：同键完整确认先查询 → 新操作占共享槽 → 检查当前 catalog CAS、项目、bc/ar归属及来源完整性 → 编译合同 → 发布前完整重核验同一组织/来源，核对head原字节及原admission → 发布固定dispatch → 仅当次fresh调用栈把私有material handoff给worker。

相同operation永远返回原run/task，差确认409；busy时仍可查询旧操作。同键重试、查询、重启、旧prepared都不能启动。请求响应丢失后只用原receipt GET对账。Spec原服务与生命周期不变，Browser共用同一runtime槽。

## 3. 最小 target-only runner 接口

```js
prepareManagedBrowserContract(material, {
  project, sourceRelease, sourceBinding, candidate, targetRelease
})
// -> { contract, sourceFiles }

runManagedBrowserAcceptance(contract, {
  runId, outputDir, sourceFiles, onEvent, signal, assertActive
})
// -> raw completed report（仍由strict writer验证并发布最终manifest）
```

material是 `readBrowserCandidateSource` 同次返回，编译必须调用完整 `verifyBrowserBaselineMaterial` / organized review核对bc，不能从display reader或不完整DTO编译。sourceFiles是最终核验捕获的私有selected Map，不能在HTTP/JSON暴露或从旧record取得“fresh许可”。

第一条目标请求之前，将source所选侧的原PNG/repeat/details复制为本run baseline evidence，核对同一contract索引的size/SHA/角色/槽位。独立runFile命名映射避免原选侧为target时文件重名；details保持原bytes，其内部原引用由固定映射解释，不重序列化、不跟随源路径、无hardlink。

runner只observe target。source entryUrl只作来源文字，不navigate、不fetch；不把截图包成伪网页执行。保持六基础facets和全部declared points：

- navigation/console/network/overflow取已资格核验的健康source事实。
- structure比固定title/headings/controls。
- visual比固定PNG与目标first screenshot；目标first/repeat重核稳定性，源资格保留原实证。
- behavior在target重放原声明steps，核验完整assertions；不从target学expected。

read-only GET/HEAD/OPTIONS、WS阻断、隔离context、mask/full-page/stability/时限规则与现有语义一致。source/target环境不相容先blocked，不能把跨平台/浏览器升级渲染差异算代码BUG。active/signal须覆盖浏览器操作、截图/文件与事件等待，停止关闭context/browser。

source复制失败或发布前源被篡改：零目标请求。fresh dispatch后已捕获的bytes不会被原source后续改动替换；完成report从本run副本核验读取。后续新operation仍fresh核验原source，原件损坏则拒绝。v1不承诺永久归档原采集root，无需额外oracle archive store。

## 4. 与旧 store/reader 的最小接线

原 `runAcceptance` 不适合直接调用：`runner.mjs:282` 的pair会重访baseline；且缺少managed同步active控制。新增target-only入口，原smoke断言/timeout/过滤保持。

原 managed Spec schema/raw/evidence validator 均为Spec专用，不能仅放宽mode或把normalizeSpecPlan改成通用。物理I/O/owner/lease/取消/恢复提交点可复用；Browser具备自己的严格合同与证据校验分支。

建议新Browser报告公共mode使用 `regression`，强制 `managed` provenance和fixed-baseline discriminator；原sourceMode单独保存。新oracle identity=`approved-captured-browser-side` +固定来源/PNG/规则，而非runtime oracle。这样既有comparer可复用，其旧live-baseline报告因oracleKey不同不能被误认为同源修复。不必为新mode改旧normalizer或legacy renderer fingerprint；固定基线新formatter可独立。

**必须先接统一reserved registry**：现有 `managed-access.mjs:8` 只盘点managed-spec dispatch。Browser reserved run/operation/task也要被legacy mutation、finish、path artifact、candidate、triage、source reader与recovery识别；删除manifest/report的managed标记后仍不能降级。新Browser namespace的损坏不能被当无记录。同ID跨namespace冲突必须拒绝。这是最不能省的共享接线。

recovery继续prepared不执行、running只中断、completed不重写；Browser完成读取/download与Spec采用严格typed branch。completed+failed是发现BUG并完成，task done，不能伪装成执行失败。

## 5. BUG账本：先做不可变 occurrence，避免再造工作流

最小落盘 `bug-ledger/v1/<projectId>/<runId>.json`，一次明确登记一个strict completed Browser run。以runId排他发布为提交点，不改原report，不创建可变issues head或“closed”权限。

```js
{
  schemaVersion: 1, kind: 'browser-check-observation',
  projectId, runId, reportSha256, dispatchSha256,
  candidateId, contentDigest, targetReleaseId, recordedAt,
  beforeRunId: null /* 或用户明确选定且核验的此前run */,
  requestFingerprint,
  observations: [{
    bugId, bugKey, checkId,
    identity: { caseKey, contextKey, ruleKey, oracleKey,
      environmentKey, verifierFingerprint },
    status, verdict, relation,
    beforeCheckId: null, evidenceReferences
  }]
}
```

`bugKey = hash(version,projectId,candidateContentDigest,caseKey,contextKey,ruleKey,oracleKey)`；bugId可由该hash确定，不另存随机身份表。run、URL、显示ID或版本label不进key。明确标注granularity=check，非代码根因数。

只failed+bug创建问题事实。之后显式before/after从同scope严格snapshots调用现有comparer：verified_passed写可靠通过观察，still_failed续同ID，后续可靠失败可写再次失败；blocked/needs_review/缺项/环境或规则变化只是未验证/不可比，不能关闭。首次observed_passed不伪造修复数。

POST最小 `{runId,reportSha256,beforeRunId}`，project在路由；服务从strict snapshot/dispatch推导其余字段。同run+同requestFingerprint重复返回原记录，改digest/before冲突；未知响应GET原run对账。入账前核验当前原件，预算整批检查，无半写/无裁剪。以临时文件+fsync+排他发布、owner/fd/fence实现，复用现有物理原语。

UI以明确的一对run展示“本次复验状态”；bug详情按stable bugId聚合已存observations。**第一版不从时间排序推断全局当前部署状态**，分支复验均保留before→after事实，列表若显示最新必须标“最近登记观测”，不能假装全局selected基线或最终关单状态。若必须需要唯一当前state，则再引入一个ledger CAS head；此项不是检测闭环的前置。

报告完成与ledger登记分开提交。ledger失败显示“报告已完成，问题未登记/待核对”，不改gate、task或重跑target。原actual/输入/PNG留在鉴权runartifact，ledger只保存引用与安全显示摘要。

## 6. 最小真实验收

1. fresh真实采集健康source+有稳定视觉和行为BUG的target，D2保存bc；nativeUI完整复核，明确目标与单次批准执行。
2. source HTTP关闭并计数。执行source请求增量0，target>0；完成结果显示真实视觉/结构/行为差异与原gate；原证据和新source副本SHA对应。
3. native UI明确登记，刷新/引擎重启同bugId/operation/run，零自动target请求。
4. 修复target，以同bc重新批准一个新operation。显式选择before/after并登记，得同bugId verified_passed；另一独立BUG仍保留failed gate。
5. 再次故障同ID；删point、少跑视口、变判据、环境变化、source或证据同长度篡改均不计修复。取消与旧prepared重启不启动；一次受控已接纳202丢响应仅GET对账，实际只执行一次。
6. shared busy覆盖Legacy/Spec/Browser；完整read/download、recovery、legacy降级反例；全文/checkbox/Blob在切项目、target、bc、lineage、readyfalse、关闭、Abort、卸载时清理，ABA不能串上下文。

完成以上native闭环与必要Core/Console/原回归后才宣称D3交付。当前D2自身CI结论前不push新提交；D3以后必须核对自身精确HEAD LinuxCI，不沿用父提交通过。

## 7. 可立即委派

1. Browser contract/target-only runner：pure编译与fixed evidence映射；完整checks，active取消。
2. Browser dispatch/managed store/reader/recovery：六字段single-operation确认、typed namespace/registry、fresh执行链、严格完成与download。
3. occurrence ledger+comparison API：纯stablekey/reducer、strictsnapshot入账、排他幂等发布、明确pair。
4. UI：D2候选面板单次批准+明确目标执行、receipt只读恢复、report→登记→pair复验与bug历史。真实浏览器门禁在主任务统一串行。

不用先实现Schema5、ba/bs、长期当前基线、另一个lifecycle store、永久source archive、AI根因合并、人工closed流程或外部工单连接器。这里省掉的是产品尚未要求的持久工作流，保留了source固定、执行授权、证据、原件隔离和可靠复验所必需的合同。
