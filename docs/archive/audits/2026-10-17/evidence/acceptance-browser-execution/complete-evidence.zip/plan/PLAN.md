# D3 建议：一条可演示的 Browser 固定基线验收与持久问题闭环

> 后续根任务讨论已选择更短的“单次操作批准并执行”，不先建立长期全局selection。本文件保留早期完整选项推导；**可实施主合同以同目录 `D3-MINIMAL-CONTRACT.md` 为准**，其中不需要Schema5或Browser lifecycle sidecar。

日期：2026-10-17。性质：基于当前 D2 工作树的独立只读规划；没有运行浏览器，没有实施本方案，没有修改生产源码、正式文档或冻结证据。

基准：`c170f503964601b7d125c2f902760c1235cc2e39` 上尚未提交的 D2 修改。D2 自身提交尚未发布、自身远端 CI 尚无结果；本方案没有把 D2 本机门禁当远端成功。

## 1. 推荐交付边界

下一项交付应直接做到：**已有 bc 完整复核 → 明确批准 → 独立选用 → 选择目标版本 → 只访问目标的固定来源验收 → 查看视觉/结构/行为结果 → 明确登记本次问题与复验 → 重启后保留同一问题身份 → 修复后复验显示可靠通过 → 再次失败显示重新出现。**

不建议再发一片“只有批准/选用、仍 executionReady:false”的产品交付。它是实现步骤，却不会使评委看到新的自动验收价值。D3 可在内部按并行模块开发，但应以整个垂直闭环作为一次发布验收点。

最小账本采用**失败检查级**记录，明确显示粒度。一个 CSS 错误可以导致视觉、结构、溢出多个检查失败；不得把它们包装为多个已证实的代码根因。第一版状态用“待修复 / 已可靠复验通过 / 再次失败”，不实现人员分配、评论、外部工单同步、部署状态推断或人工最终关单。

问题登记采用显式按钮“登记本次问题与复验”：检测和报告自动完成，账本写入是单独的、幂等的组织动作。这样既完成持久 BUG 追踪，也避免让报告终态与账本两处发布伪装成跨文件事务。后续需要自动登记时，可对相同入账服务加可靠投影队列，不重写判定内核。

## 2. 当前源码已提供什么，缺什么

| 实时源码依据 | 已有能力与直接含义 |
| --- | --- |
| `core/src/acceptance/browser-candidate-projection.mjs:414`、`:488`、`:517`、`:524`、`:560` | 完整重建旧 Browser 检查、选侧资格、scope/rules/selectedOracles/selectedEvidence，且读取全部实际引用原件；可作为新合同唯一来源。所选侧已要求健康、完整、稳定、无写请求、操作断言全部通过。原比较另一侧可以失败。 |
| `core/src/acceptance/browser-candidate-review.mjs:89`、`:117` | 已把完整来源合同与 project/release/ax 组织上下文绑定到 bc.contentDigest，不应重新定义 D1/D2 摘要。 |
| `core/src/acceptance/catalog.mjs:676`、`:717` | materializeBrowserReview 返回 review 与同次 material；已有写队列、双 CAS、提交前完整来源复核。 |
| `core/src/acceptance/catalog-schema.mjs:18`、`:66`、`:234`、`:242` | Schema4 只有 Browser candidate，批准/选用实体和 currentSelections 仍严格为 Spec。不能往现有 aa/as 偷塞 Browser。 |
| `core/src/acceptance/runner.mjs:282` | legacy pair 每次分别 observe baseline URL 与 target URL。把 bc 填进去仍会重访可变参考站，不能称“固定来源执行”。 |
| `core/src/acceptance/execution-service.mjs:65`、`execution-runtime.mjs:56` | 已有新确认接纳、同键查询、共享槽、取消与不确定发布阻断；应复用这些合同。 |
| `core/src/acceptance/managed-dispatch-schema.mjs:143`、`managed-run-schema.mjs:159`、`managed-snapshot-schema.mjs:15` | 当前派发/运行/证据严格绑定 Spec 结构；不能只把 mode 枚举放宽就获得 Browser executor。 |
| `core/src/acceptance/comparison.mjs:96`、`:139`、`:173` | 已有完整证据、整项可靠通过、身份/规则/依据/环境/验证器相容性与八类关系；账本可复用该保守判定。 |
| `core/src/acceptance/managed-access.mjs:8`、`managed-run-reader.mjs:222` | legacy 隔离目前只盘点 managed-spec namespace。增加 Browser namespace 时必须统一保留身份防降级，尤其是删 managed 字段后的 reserved run。 |
| `core/src/acceptance/triage.mjs:1`、`:114`、`:159` | triage 是可选 AI 解释，不能当问题事实、问题身份或状态真值；现有 managed 隔离继续保留。 |

## 3. 一次明确的 Schema5，保留 D1/D2 身份

建议 Schema5 只新增 `browserApprovals` 与 `browserSelections` 两张组织表、对应两个事件，以及 `.currentSelections.browser`。bc、ax 与全部来源/组织/候选摘要公式保持原值。

批准建议独立 `ba-*` 身份：

```js
{ id, projectId, candidateId /* bc */, contentDigest, reason, approvedAt, actor }
```

选用建议独立 `bs-*` 身份：

```js
{ id, projectId, mode:'browser', approvalId /* ba|null */,
  previousSelectionId /* bs|null */, reason, selectedAt, actor }
```

准则：

1. `approveBrowserBaseline` 必须队列内检查 Schema5、CAS、project/bc/ax/release 归属、容量与内容摘要，然后 fresh materialize；最终 head 发布前再次完整重建并核对同一 review。拒绝前不生成批准实体。响应只是组织事实，仍 `executionReady:false`。
2. `selectBrowserBaseline` 独立于批准。非 null 选用必须完整复核被批准来源；撤销只追加 null 选用、保留链，且不要求已损坏来源恢复后才允许取消。选用不等于启动；同一个 approval 再选返回 SELECTION_UNCHANGED。
3. 不设置“批准自动选用”，不从历史列表排序推断当前选用，不从整体旧 gate 推翻合格的所选侧。
4. 当前 Schema1–4 白名单保持不变，只有显式 `4→5` 维护进入新格式；预览与六字段确认、前像、generation 切换和预算检查沿用既有维护。全链 `1→2→3→4→5` 的 migration 容量需从三步明确扩到四步，不能先写前三步才发现无余量。
5. 现有“新空 root 由引擎明确创建 Schema3”策略保持；演示 setup 显式升级到5。不要把正常部署或启动改成隐式迁移。以后若要改变新建默认格式，作为明确产品决定单独验收。
6. D2 中 `schemaVersion===4` 的已知支持点需**精确扩为 [4,5]**，包括完整 review/metadata/support/API 与 frontend validator；未知未来版本仍拒绝，D2 旧摘要与实体无字节重写。D3 写路由仅 Schema5 可用。

推荐 HTTP：

```text
POST /api/acceptance/projects/:ap/browser-baseline-approvals
  { expectedGenerationId, expectedRevision, candidateId, contentDigest, reason }
POST /api/acceptance/projects/:ap/browser-baseline-selections
  { expectedGenerationId, expectedRevision, approvalId, contentDigest, reason }
```

取消使用 `approvalId:null,contentDigest:null`，无需另一个撤销 API。集合/历史沿用 project detail，只有明确展开完整合同才读取原件。

## 4. 真正固定的 Browser 执行合同

### 4.1 输入与接纳

新私有纯函数 `prepareManagedBrowserContract(material,{project,release,binding,candidate,targetRelease})` 直接消费 private materializer 的 `{snapshot,files}`；重跑完整 verifier 和组织 review，对照已批准 bc。客户端不能提交 plan、URL、expected、遮罩、阈值、执行预算、PNG、source path、approved 或 run/task 身份。

新操作只接受完整六字段 body；连同路由的 projectId 构成七字段确认：

```js
{ operationId, expectedGenerationId, expectedRevision,
  selectionId /* bs */, contentDigest, targetReleaseId }
// projectId 取路由，不重复接受客户端替代值。
```

服务遵守现有 Spec 规则：完整同键核对先于 busy；同进程同键合并；冲突409；只有不存在记录时占用全局验收槽；只有当次成功 fresh prepare 且原 admission lease 仍 active 的调用栈能启动。旧 prepared、查询、响应重试、引擎重启均不启动。

准备在 catalog 队列中固定当前 browser selection、approval、bc、ax、source release、明确 target release、完整源摘要、head 原字节和目标 URL。前发布重建来源、核对目录双 head 与 admission。源原件在候选创建后发生同长度改动也必须409，且目标请求计数为0。

建议专用 `managed-browser-dispatches/v1` 与新严格 envelope；保留 `managed-spec-dispatches/v1` 原结构，不改写原 Spec records。两种 namespace 由一个有界 registry 汇总 reserved operation/run/task 身份，消除同 ID 跨 namespace 冲突；未知/损坏内容不能被当作“不存在”。

### 4.2 最少需要固化的合同

新 envelope 必须包含来源 context、selection/approval/bc/ax、sourceProjection、scope、完整 rules、selectedOracles、selectedEvidence metadata、源环境、明确 targetRelease、固定 run/task、planFingerprint 与 executor 标识。必须是完整有界 JSON；D2 review 上限12 MiB不能静默裁剪到旧 Spec dispatch 的8 MiB。新合同应独立定义预算（建议12 MiB JSON，沿用源文件/总量预算），超限在发布前拒绝。

执行内存只拿**最终核验捕获的同一 Map**。prepare的内部返回可携带私有material handoff，且只允许当次fresh调用栈消费；它不是HTTP字段，不写入JSON，不允许从旧record重建成新的启动许可。不接受显示 DTO，不在 fresh prepare 之后按路径重新读取 PNG 来替换基线。Browser source reader 本身并未返回可跨整个异步运行存活的 capability；不能把一次成功读取冒充永久文件权限。

在第一条目标请求前，owner-bound writer 将所选侧 `screenshot/repeat/details` 原 bytes 复制为新运行自己的 baseline evidence，并按 envelope 对大小/SHA/角色/槽位做核验。使用明确的 sourceFile→runFile 命名映射为source副本加独立前缀，防止原所选侧为target时和本次target文件重名；不重新序列化details以伪装成原baseline侧，其内部原引用由固定映射解释，不跟随原路径。这些副本有独立严格文件上下文，受同一个 owner/lease/fd/current-head 约束。复制失败保留 partial、零目标请求；不通过 hardlink、symlink 或可变原路径来省略复制。

后续报告读取与下载依赖本运行的 baseline 副本和 fixed envelope，原采集运行被移动或损坏不会改变已完成运行的原结论。新的执行仍需重新验证原来源；若原来源已损坏，新执行拒绝。**v1 固定的是已确认合同和单次执行使用的字节，不承诺永久归档原采集数据。** 这足以达到演示价值，并避免先建第三套 archive store 再开始检测。

批准时另存永久来源包可后续扩展；本片不要求，避免为了永续 archive 生命周期增加孤儿包管理、另一份恢复和跨文件发布协议。

### 4.3 target-only runner

新 `runManagedBrowserAcceptance` 使用原 Browser 只读语义：isolated contexts、service worker block、GET/HEAD/OPTIONS、WebSocket block、相同 timeout/capture/mask/stability 规则、相同 slots 与声明 point steps/assertions。**基线 entryUrl 仅保留来源追溯，不调用 navigate/fetch，不把截图渲染成伪页面执行。**

从固定 source details/PNG 与 selectedOracles 取 expected：

- navigation：已资格核验的源 HTTP 状态；target HTTP/导航/采集故障按原 bug/environment 口径区分。
- console/network/overflow：源所选侧已要求健康，期待为空/无溢出；target 只读策略阻断的连带现象仍属于环境受阻。
- structure：固定 title/headings/controls；保留原规范化规则，不因 target 回应重新学习 expected。
- visual：固定 PNG 对 target first screenshot，target first/repeat 验稳定性；来源稳定性与mask/full-page资格来自已核验原件。
- behavior：重放声明 steps，在 target 校验**完整声明断言**；源已验证全部通过。stepError、未执行、预算、写请求不构成可靠通过。

所有六基础槽与 point 槽必须完整覆盖，不裁剪当前 bc 的范围凑“成功”。原 health BUG 可能使 visual/structure 受阻，保持原因区分。completed+failed 是检测完成，任务 done；取消/超时/owner丢失沿用 Spec 收尾规则。

源截图环境与目标环境是两件事。v1 最稳妥的策略是在启动 Chromium、取得版本且尚未请求 target 时核对源 environment；不相容则 completed+blocked/ENVIRONMENT_MISMATCH，明确原因为环境，并不产目标视觉 BUG 或可靠修复。不要把 Windows 基线与 Linux/升级后 Chromium 的渲染差异当代码缺陷。演示 fixture 在同一执行环境采集与检测；跨环境容差是后续能力，不能隐式放宽。

取消和 active fence 必须覆盖 Chromium launch、newContext、goto、step、assertion、wait、evaluate、截图、文件写入及事件等待；信号终止时 close page/context/browser，旧 runner 当前缺少此控制，不能直接原样调用。原 legacy runner 与原 Console smoke 断言保持。

### 4.4 报告、身份与兼容的最短路径

建议新执行合同以 `executor:'engine-owner-browser-v1'` 和明确 captured-baseline discriminator 区分；公共报告 mode 继续使用 `regression`，因为它确实是“已批准版本与目标版本比较”。source.sourceMode 保留原始 mirror/regression，仅作 provenance。新严格 Browser raw/snapshot validator 必须要求 discriminator，不能让普通 regression 报告声称托管执行。

这条路径能让现有 `compareAcceptanceSnapshots` 消费完整 snapshots，避免为增加 mode 再重写旧 plan normalizer。每项 oracle identity 明确为 `approved-captured-browser-side`，包含 sourceContentDigest、选侧、固定 requirements/PNG SHA；绝不沿用 `kind:'runtime'` 造成旧 live-baseline 与新固定基线看似相同。

每项检查继续产生 case/context/rule/oracle/environment identity 与新验证器指纹。相同所选 bc + 相同判据和环境 + 改变 target URL/label/原始数组顺序仍能配对；更换来源、判据、viewport、步骤、遮罩、环境、验证器或缺证据不能计修复。

为了减少非必要回归，新增 formatter 用于固定基线来源说明；原 `report.mjs` 的 legacy fingerprint 内容不必为展示文字被改写。新 verifier fingerprint 覆盖新 runner、normalizer、snapshot/evidence validator、identity 与 compare 依赖，独立记录 LF/CRLF 来源规则；不能把当前 checkout 自算摘要直接加入“已独立审查的旧来源 allowlist”。如果确需修改 legacy fingerprint 输入文件，应显式评审新 verifier 语义并补来源资格兼容证据，不能动态放行。

HTTP 建议：

```text
GET  /api/acceptance/browser-execution
POST /api/acceptance/projects/:ap/browser-executions
GET  /api/acceptance/projects/:ap/browser-executions/:operationId
POST /api/jobs/:taskId/cancel           # 复用既有入口
```

新 capability 只说明 Browser 支持与当下槽位状态。既有 Spec `/execution` methods GET/HEAD 不被 Browser 的 OPTIONS 混淆；两者共用同一个 runtime。

## 5. 最小持久问题账本

### 5.1 单独、可重核验的组织投影

建立 owner-bound `bug-ledger/v1`，每项目一个有界 head+previous，独立 generation/revision/CAS；不往 run 目录写 triage/sidecar 来冒充账本。新 catalog Schema5 不塞入大量 occurrence，避免很快耗尽8 MiB目录与events预算。

账本只接收**已完成、完整核验、严格 managed Browser snapshot**。第一版不迁移旧 legacy 或 Spec 问题；它们仍可比较，不能被自动认领成已批准 Browser BUG。source candidate/project/target release 均从固定 dispatch 取得，客户端不能提交 status/verdict/severity/标题/expected。

一次显式入账是一份不可变事件，引用 runId、reportSha256、dispatchSha256、targetRelease、candidateContentDigest、来源摘要、精确检查引用与必要证据摘要。实体只存安全索引和显示文本，原 actual、合同全文、截图与敏感输入继续从鉴权核验 run artifact 读取。

建议 API：

```text
GET  /api/acceptance/projects/:ap/bugs
GET  /api/acceptance/projects/:ap/bugs/:bugId
POST /api/acceptance/projects/:ap/bug-observations
GET  /api/acceptance/projects/:ap/bug-observations/:runId

POST body = {
  expectedGenerationId, expectedRevision,   // ledger CAS，明确区别 catalog CAS
  runId, reportSha256,
  beforeRunId /* null for first import; otherwise explicit prior applied run */
}
```

`(projectId,runId)` 只入账一次；同完整 request fingerprint 的重发/查询返回原事件，换 report digest 或 beforeRunId 冲突409，先于 stale CAS 查询。未知 POST 结果只能 GET 对账，不重造 run/issue。首 import beforeRunId=null 只能创建已观察失败，不能声明回归；后续必须明确当前 applied predecessor，stale predecessor拒绝并刷新，防止迟到报告覆盖用户刚选的复验方向。

发布前重新核对 ledger 两份 head、同一读取 scope 的 completed snapshot/报告及引用原件、相容 predecessor 和容量。支持1次整批发布所有 check observations，超限整批拒绝，不写半份事件。容量建议从小的有界上限开始，明确记录限额、总JSON/单条/事件预算，不自动裁剪历史。

报告先完成、账本后登记，两者有独立提交点。账本故障显示“报告已完成，问题未登记/待核对”，保留报告 gate、运行 done 事实和原件；不能重新 finish runner。账本不确定提交只锁住本 ledger 写入直至重开核对，不伪称报告/检测失败。

### 5.2 身份和状态

推荐 `bugKey = hash(version,projectId,candidateContentDigest,caseKey,contextKey,ruleKey,oracleKey)`。不含 runId、target URL、显示 check.id、target release label；环境与验证器作为每次 observation 的 compatibility 事实，而不是让一次升级悄悄把同检查“另起一个已修复BUG”。同一 run 的重复 context 必须整批拒绝，不能靠数组顺序配对。

这表示“这个项目、此批准来源、此检查/视口的一个持续问题”，不是代码根因去重。来源或规则改变形成不同身份，原问题保留不可比，不自动迁移或关闭。

仅 `failed+bug` 可以建立问题。后续使用现有 comparer 的整项关系：

| 核验关系 | 账本动作 |
| --- | --- |
| 首次 observed_failure | 建立待修复检查问题，记录首次证据；不称新增回归。 |
| still_failed | 同 ID 追加失败观察，保持待修复。 |
| verified_passed | 同 ID 记录已可靠复验通过，引用明确 before/after；不称业务最终关单。 |
| new_failure | 若已有已复验问题则同 ID 再次失败；首次从可靠通过转失败可标新增回归。 |
| unverified/incomparable/blocked/needs_review/缺项/受限 | 追加复验未获证明的事实，不能关闭；显示最新观测未验证和上次可靠状态，不能只保留绿色旧标签。 |
| observed_passed | 没有旧失败事实时不创建“已修复 BUG”。 |

全局还有另一项失败不阻止某项可靠复验通过，但页面保留本次 gate=failed；删检查、少跑手机、改 source、改阈值/遮罩/步骤、环境变化或证据坏绝不算修复。v1 不接受用户随意 `status:'closed'`，避免再引入人工关单/重开权限状态机。

## 6. 复用 Spec 生命周期的具体边界

直接复用：唯一 root owner；原 head/previous CAS 与版本迁移协议；shared runtime lease；fresh admission和同键只读恢复；task mirror/SSE投影；watchdog/取消/shutdown语义；有界 fd捕获与 regular/nlink/path检查；completed manifest提交点；原件 SHA下载；明确 before/after comparison；frontend receipt一提交后只查原 operation、ABA/sequence guard和敏感全文清理。

必须独立实现或严格按类型分派：Browser contract normalizer；Browser dispatch envelope；source selected PNG物化；target observer及控制；Browser raw/snapshot/evidence校验；Browser provenance；专用 formatter；Browser输入确认UI；BUG ledger。Spec validator不能接受Browser字段，Browser validator不能复用 `normalizeSpecPlan` 或 approved-spec oracle。

统一接入而非漏一个入口：`managed-access`、`managed-run-reader`、`store`、`recovery`、engine task history mirror、ordinary CLI mutation/finish/path artifact、candidate/triage拒绝规则都必须识别新的 reserved Browser run。prepared不自动执行、running重启只中断、completed保持原件、未知namespace保守受阻与Spec一致。只在一个隔离reader支持Browser、其他入口仍认为legacy，会产生最高优先级的身份降级漏洞。

## 7. 建议内部工作分工；发布只按一个闭环验收

| 可并行模块 | 明确接口 |
| --- | --- |
| 生命周期/schema/API | Schema5实体与迁移；`read/prepareManagedBrowserDispatch`；统一reserved registry合同。 |
| 固定来源runner/store/reader | `prepareManagedBrowserContract`输入raw material；managed Browser envelope/result schema；target-only执行、证据副本、完成读取与恢复。 |
| BUG账本/comparison | 只接严格完成snapshots，纯 reducer+owner store+入账API；不碰runner判定。 |
| frontend与真实smoke | 候选复核上增加批准与选用，明确目标执行与原操作恢复，report→入账→复验轨迹；共享清理与证据展示。 |

先冻结合同fixture再并行，避免四组分别创造plan/identity字段。内部阶段的WIP不宣称产品交付；所有模块连通后才接受D3。若实现规模必须缩减，保留前三个真实步骤“批准选用→固定来源执行→持久失败检查入账”，推迟账本自动状态聚合，仍必须有真实target-only检测与重启同ID；不要缩成纯格式或纯按钮。

## 8. 测试与真实UI验收计划

### 单元与存储/HTTP故障

- Schema1–4完全兼容、显式4→5与完整1→5容量预检、前像和事件前缀；Browser实体禁止进入Spec链，Spec实体禁止进入Browser链；D2在4/5原内容摘要完全相同。
- 批准/选用/取消、陈旧CAS、跨项目、错误bc/ba/bs、重复选用、源同长度篡改、late guard、目录替换、容量、完整响应预算；拒绝时无批准/选用/head发布。
- source从baseline与target两侧创建；原比较另一侧失败仍可选择健康侧；不完整/不稳定/大遮罩/超页预算/缺point或未声明额外槽拒绝。
- 固定source PNG/repeat/details副本SHA与所选侧一致；copy/prepublish失败目标请求为0；原source在捕获后变化不能替换已选Map；完成后原source损坏不破坏run自己的证据读取，后续新执行拒绝。
- sourceURL关闭或返回完全不同页面仍零source请求；target实际被请求；篡改plan/expected/URL/approved字段拒绝；targetonly规则、环境不相容、readonly阻断、真实视觉/结构/行为BUG与可靠通过。
- 同键并发/丢响应/坏202只查询、不重复执行；busy共用Legacy+Spec+Browser；prepared重启不执行；running重启仅中断；cancel/watchdog/owner丢失与证据写失败保留partial，禁止补造completed。
- 两namespace身份冲突、坏dispatch、删除managed字段、仅report带marker、旧入口CLI/finish/triage/candidate/下载全量隔离；未知版本不能降级。
- ledger同run幂等、报告digest冲突、迟到before、staleCAS、出错不改run、整批预算无半写；空/坏证据拒绝；duplicate context拒绝；title/URL/显示顺序变动稳定身份；同source修复与再次失败同ID；改source/规则/viewport/环境/验证器与删检查保持未验证。

### 一个端到端native UI smoke，主线必须可录演示

1. HTTP fixture setup明确标注，真实采集Mirror/Regression原件；source完整健康、target有稳定视觉/结构/行为差异，原gate=failed。真实native UI读取完整bc、确认批准、独立选用；确认控件绑定当前CAS和digest。
2. 关闭sourceHTTP服务并保留counter。UI选明确bad targetRelease、复核来源与target后确认启动。等待严格completed结果，source请求增量0、target请求>0；看到正确维度/原gate/截图/diff及声明行为失败；下载重新核验。
3. UI明确登记本次问题，记录bugId/occurrence与report/dispatch摘要；刷新并重启引擎后读取同ID，零target自动请求。
4. 同targetURL部署修复并创建新immutable release声明；UI用相同selected bc重新确认新operation执行。可靠整项通过，明确入账并显示同bugId“已可靠复验通过”，原failed报告与gate字节不变。
5. 另一独立BUG仍失败时，该问题仍可复验通过，但本次总gate保持failed。再把已修复项恢复故障并新运行，入账后同ID“再次失败”。
6. 受控一次target unavailable/unstable/readonly写请求，另一轮删point或换source的反例；不能把旧问题算修复。篡改当前证据时账本入账与导出受阻、历史记录保留；恢复原bytes后按需重核验。
7. 受控一次新启动202服务器已接纳后丢响应；保存原receipt、GET原operation恢复，同key实际只运行一次。并发busy、取消、旧prepared重启均有counter证明。
8. 切项目/候选/选用/目标/目录lineage/readyfalse、关闭/Abort/卸载清全文、checkbox与Blob；ABA与迟到读取不能污染新上下文。桌面/手机、dark/light实截图、键盘label/focus检查；原Acceptance console smoke原断言/timeout/错误过滤完全保持。

Browser smoke继续串行，证据落专用新运行目录，失败原件保留。一次最终freeze后跑针对性新测试、完整Core、Console build与原必要回归，确认sourceguard再提交；不用因为结果已通过反复重复长门禁。D3自身LinuxCI必须核对精确新HEAD，不能沿用D1/D2父提交结果。

## 9. 主要风险与交付决定

| 风险 | 处理决定 |
| --- | --- |
| 继续细切到只有模型/按钮，比赛仍看不到新检测价值 | 把批准、选用、target-only检测、持久失败检查和至少一次修复复验连为一个D3交付。 |
| 直接复用legacy双URL runner或从target自学习expected | 新target-only入口、严格private编译；source请求counter=0是硬验收。 |
| D2“已保存”被当永久物理冻结 | 明确每次新执行fresh核验；当次同Map复制至run；长期source archive后续实现。 |
| 直接放宽Specvalidator，泄漏跨类型权限 | 新类型分支与namespace；共享物理原语和生命周期合同，严格隔离实体。 |
| 新namespace没进入legacy reserved查询 | 先做统一有界registry与降级反例，再接执行入口。 |
| Windows/Linux/字体/Chromium升级造成误报 | 明确source与current环境；v1不相容先blocked；不能依赖阈值临时放宽通过。 |
| 删断言/缺手机/改遮罩被当修复 | 稳定身份+现有整项保守comparer，未验证保持醒目，不绿色关闭。 |
| runner完成与ledger写入出现双写不一致 | 分开提交点、显式幂等登记；run事实始终权威，ledger可安全对账，失败不重跑。 |
| 多个维度失败夸大为代码BUG根因数 | 全程显示check granularity与来源/视口/维度，暂不做AI根因合并。 |

本方案建议先交付可验证的确定性闭环；LLM只在明确触发的安全摘要上补解释与修复建议，不能改gate/判据/账本状态。无需先加AI自动修代码或外部工单连接器，便能真实演示“批准的页面参考 → 自动发现还原与行为BUG → 修复复验 → 保留历史”。
