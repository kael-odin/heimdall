import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, lstatSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const helper = dirname(fileURLToPath(import.meta.url));
const repo = resolve(helper, '../../../..');
const output = join(repo, 'core/workspace/_runs/browser-bindings-smoke-e9c0f93e-73a6-4b98-b544-31f3fedde0a8');
const sha = value => createHash('sha256').update(value).digest('hex');
const parse = file => JSON.parse(readFileSync(join(output, file)));
const save = (file, value) => writeFileSync(join(helper, file), Buffer.isBuffer(value) ? value : JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const tree = directory => {
  const entries = [];
  function visit(path) {
    const stat = lstatSync(path);
    if (stat.isDirectory()) { for (const name of readdirSync(path).sort()) visit(join(path, name)); return; }
    assert.ok(stat.isFile() && !stat.isSymbolicLink());
    const bytes = readFileSync(path);
    entries.push({ file: relative(directory, path).replaceAll('\\', '/'), bytes: bytes.length, sha256: sha(bytes) });
  }
  visit(directory); return entries;
};

const summary = parse('summary.json'), checks = parse('checks.json'), index = parse('capture-index.json');
assert.equal(summary.status, 'passed'); assert.equal(summary.checkCount, Object.keys(checks).length);
assert.equal(summary.checkCount, 30); assert.ok(Object.values(checks).every(value => value === true));
assert.deepEqual(summary.checks, checks); assert.equal(index.samples.length, 2);
const samples = [];
for (const sample of index.samples) {
  const runtime = join(output, sample.runtimeDirectory), archive = join(output, sample.archivedRun);
  const current = tree(runtime), copied = tree(archive);
  assert.deepEqual(current, sample.originalFiles); assert.deepEqual(copied, sample.originalFiles);
  const manifest = JSON.parse(readFileSync(join(runtime, 'manifest.json'))), reportBytes = readFileSync(join(runtime, 'report.json'));
  const report = JSON.parse(reportBytes);
  assert.equal(manifest.status, 'completed'); assert.equal(manifest.reportSha256, sha(reportBytes));
  assert.equal(report.mode, sample.mode); assert.equal(report.gate, 'failed'); assert.equal(report.checks.length, 14);
  assert.equal(report.evidenceManifest.length, 26); // 24 side artifacts plus two comparison diff images.
  for (const evidence of report.evidenceManifest) {
    const bytes = readFileSync(join(runtime, evidence.file));
    assert.equal(evidence.bytes, bytes.length); assert.equal(evidence.sha256, sha(bytes));
  }
  samples.push({ mode: sample.mode, runId: sample.runId, runFiles: current.length, runBytes: current.reduce((sum, entry) => sum + entry.bytes, 0), reportChecks: report.checks.length, evidenceEntries: report.evidenceManifest.length, reportSha256: sha(reportBytes) });
}
const rawCatalog = readFileSync(join(output, 'runtime/acceptance/catalog.json'));
assert.deepEqual(rawCatalog, readFileSync(join(output, 'catalog-final.bytes.json')));
const catalog = JSON.parse(rawCatalog); assert.deepEqual(catalog, parse('catalog-final.json'));
assert.equal(Object.keys(catalog.browserSourceBindings).length, 4); assert.equal(Object.keys(catalog.runBindings).length, 2);
assert.equal(catalog.events.filter(event => event.kind === 'browser-source-bound').length, 4);
assert.equal(Object.keys(catalog.candidates).length, 0); assert.equal(Object.keys(catalog.approvals).length, 0); assert.equal(Object.keys(catalog.selections).length, 0);
const records = parse('bindings-and-previews.json');
assert.equal(records.length, 3);
assert.equal(records.slice(0, 2).reduce((sum, entry) => sum + Object.keys(entry.reads).length, 0) + 2, summary.singleBindingReads);
assert.equal(records[2].diagnostic.preview, null); assert.equal(records[2].diagnostic.diagnostics.eligible, false);
assert.equal(records[2].recovered.diagnostics.eligible, true);
const requests = parse('target-requests.json');
assert.equal(requests.captureRequests, 16); assert.equal(requests.bindingAndReadRequests, 0); assert.equal(requests.bindingFetchAttempts, 0);
assert.equal(requests.requests.length, 16); assert.ok(requests.requests.every(entry => entry.phase === 'capture'));
assert.deepEqual(parse('forbidden-process-events.json'), []);
const rejections = parse('rejections.json'); assert.equal(rejections.length, 14);

const before = tree(output);
const command = { executable: process.execPath, args: [join(repo, 'core/scripts/smoke-acceptance-browser-bindings.mjs'), output], cwd: repo, timeoutMs: 10000, startedAt: new Date().toISOString() };
const result = spawnSync(command.executable, command.args, { cwd: repo, windowsHide: true, timeout: command.timeoutMs });
save('refuse-overwrite.stdout.bin', result.stdout); save('refuse-overwrite.stderr.bin', result.stderr);
assert.equal(result.status, 1); assert.equal(result.signal, null); assert.equal(result.error, undefined);
assert.ok(result.stderr.toString().includes('EEXIST'));
assert.deepEqual(tree(output), before);
const verification = { status: 'passed', verifiedAt: new Date().toISOString(), summaryCheckCount: Object.keys(checks).length, samples,
  browserBindings: Object.keys(catalog.browserSourceBindings).length, legacyBindings: Object.keys(catalog.runBindings).length,
  rejectionCount: rejections.length, catalogRevision: catalog.revision, catalogEvents: catalog.events.length, catalogSha256: sha(rawCatalog),
  outputFiles: before.length, outputBytes: before.reduce((sum, entry) => sum + entry.bytes, 0), outputTreeSha256: sha(JSON.stringify(before)),
  refuseOverwrite: { ...command, exitCode: result.status, signal: result.signal, observedError: 'EEXIST', sourceTreeUnchanged: true } };
save('evidence-verification.json', verification); save('output-file-index.json', before);
console.log(JSON.stringify(verification, null, 2));
