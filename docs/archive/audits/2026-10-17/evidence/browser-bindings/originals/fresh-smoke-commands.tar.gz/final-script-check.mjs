import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, readdirSync, lstatSync } from 'node:fs';
import { dirname, join, resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
const helper = dirname(fileURLToPath(import.meta.url)), repo = resolve(helper, '../../../..');
const script = join(repo, 'core/scripts/smoke-acceptance-browser-bindings.mjs');
const output = join(repo, 'core/workspace/_runs/browser-bindings-smoke-e9c0f93e-73a6-4b98-b544-31f3fedde0a8');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const save = (name, value) => writeFileSync(join(helper, name), Buffer.isBuffer(value) ? value : JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const gates = [];
for (const [name, args, expected] of [['final-syntax', ['--check', script], 0], ['final-refuse-overwrite', [script, output], 1]]) {
  const startedAt = new Date().toISOString(), started = Date.now();
  const result = spawnSync(process.execPath, args, { cwd: repo, timeout: 10000, windowsHide: true });
  save(name + '.stdout.bin', result.stdout); save(name + '.stderr.bin', result.stderr);
  gates.push({ name, executable: process.execPath, args, cwd: repo, startedAt, endedAt: new Date().toISOString(), durationMs: Date.now() - started, exitCode: result.status, signal: result.signal, error: result.error?.message ?? null });
  assert.equal(result.status, expected); assert.equal(result.signal, null); assert.equal(result.error, undefined);
  if (expected === 1) assert.ok(result.stderr.toString().includes('EEXIST'));
}
const current = [];
function visit(path) {
  const stat = lstatSync(path);
  if (stat.isDirectory()) { for (const name of readdirSync(path).sort()) visit(join(path, name)); return; }
  const bytes = readFileSync(path); current.push({ file: relative(output, path).replaceAll('\\', '/'), bytes: bytes.length, sha256: sha(bytes) });
}
visit(output);
assert.deepEqual(current, JSON.parse(readFileSync(join(helper, 'output-file-index.json'))));
const result = { status: 'passed', scriptSha256: sha(readFileSync(script)), preservedEvidenceFileCount: current.length, gates,
  note: 'The complete fresh capture smoke passed before a final parent-directory initialization line was added. The final source passes syntax and refuses an existing output without changing any evidence bytes; capture/binding logic is unchanged.' };
save('final-script-gates.json', result); console.log(JSON.stringify(result, null, 2));
