/**
 * live/health — 交互镜像离线体检（纯静态：无浏览器、无网络）
 *
 * 从 site/live 的 HTML/CSS 出发，按 serve.mjs 的同一套解析规则
 * （本地快照 → HAR 回放）逐条检查引用，输出 health.json：
 *   资源（assets）：
 *     local       站点 live 目录已有该文件（离线可用）
 *     har         HAR 可回放（原站更新后旧 chunk 仍可用）
 *     unresolved  同站资源，离线模式下会 404 —— 交付阻断项
 *     external    站外域名；其中静态资源离线一定裂，单独列 externalAssetsTop
 *   链接（links）：站内 <a href> 指向的页面是否已在镜像里（missing = 未镜像页面）
 *
 * 入口：scanLiveBundle({ liveDir, host, origin, harIndex })
 */
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, posix, extname } from 'node:path';
import { matchHar } from './har.mjs';
import { LIVE_QUERY_DIR, liveSnapshotCandidates, liveSnapshotPath } from './live-path.mjs';
import { scanCssRefs } from '../css-refs.mjs';

const SKIP_REF = /^(?:data:|blob:|about:|javascript:|mailto:|tel:|#)/i;
const ASSET_EXT = /\.(?:png|jpe?g|gif|webp|avif|svg|ico|bmp|woff2?|ttf|otf|eot|css|js|mjs|mp4|webm|mp3|pdf)(?:$|[?#])/i;
const ASSET_RELS = new Set(['stylesheet', 'icon', 'preload', 'modulepreload', 'manifest', 'prefetch']);
const MAX_UNRESOLVED = 200;
const MAX_FILES = 4000;
const MAX_PROBES = 10000;
const MAX_MISSING_LINK_DETAILS = 5000;
const MAX_EXTERNAL_REF_DETAILS = 5000;

const stripHash = (u) => String(u ?? '').split('#')[0].trim();
const decodeEntities = (u) => String(u).replace(/&amp;/gi, '&');

/** 把一条引用解析成站内路径 / 站外标记 / null（跳过） */
export function resolveRefPath(raw, { host, origin, basePath = '/' } = {}) {
  const clean = decodeEntities(stripHash(raw));
  if (!clean || SKIP_REF.test(clean)) return null;
  // URL 编码的片段标识符（%23 = #）：它会绕过上面的 SKIP_REF（那里只认字面 #），
  // 然后被当成相对路径，生成一个永远不存在的目标。
  // 实测来源：CSS 里 data URI 内嵌 SVG 的 url(%23someFilter)。
  if (/^%23/i.test(clean)) return null;
  let u = clean;
  if (u.startsWith('//')) u = (origin ? new URL(origin).protocol : 'https:') + u;
  if (/^[a-z][a-z0-9+.-]*:/i.test(u)) {
    let parsed;
    try { parsed = new URL(u); } catch { return null; }
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return null;
    const targetHost = String(host).replace(/^www\./, '');
    if (origin ? parsed.origin !== new URL(origin).origin : parsed.hostname.replace(/^www\./, '') !== targetHost) return { external: true };
    return { path: parsed.pathname || '/', search: parsed.search };
  }
  // 根相对/相对引用：先切掉 query（Next 会产出 favicon.ico?x.ico?dpl=… 这种双 ? 形式）
  const q = u.indexOf('?');
  const pathPart = q >= 0 ? u.slice(0, q) : u;
  const search = q >= 0 ? u.slice(q) : '';
  const abs = pathPart.startsWith('/') ? posix.normalize(pathPart) : posix.normalize(posix.join(basePath || '/', pathPart));
  // /lm/<host>/ 或 /lm/<host:port>/ 前缀（本地 fixture 会带端口）
  const lm = /^\/lm\/([^/]+)(\/.*)?$/.exec(abs);
  if (lm) {
    const seg = lm[1].toLowerCase();
    const h = String(host).toLowerCase().replace(/^www\./, '');
    const bare = seg.replace(/^www\./, '');
    if (bare === h || (origin ? seg === new URL(origin).host : bare.startsWith(h + ':'))) return { path: lm[2] ?? '/', search };
  }
  return { path: abs, search };
}

function fileFor(liveDir, p, search = '', staticDir = null, host = '') {
  // The deployed server resolves the URL-encoded pathname, including Unicode links.
  p = new URL(p, 'http://localhost').pathname;
  for (const c of liveSnapshotCandidates(p, search)) {
    const f = join(liveDir, c);
    try { if (statSync(f).isFile()) return f; } catch {}
  }
  if (staticDir && host) {
    for (const prefix of ['/static/' + host + '/', '/static/www.' + host + '/']) {
      if (!p.startsWith(prefix)) continue;
      const rest = p.slice(prefix.length);
      for (const c of liveSnapshotCandidates(rest)) {
        const f = join(staticDir, host, c);
        try { if (statSync(f).isFile()) return f; } catch {}
      }
    }
  }
  return null;
}

/**
 * 取标签上的某个属性值。**前面不能是 `-` 或单词字符** —— 否则 `poster` 会命中
 * `data-heimdall-poster="0"`：那是我们自己给视频打的标记（值是个帧序号），
 * 被当成真 poster 之后，health 会报出 3 个**根本不存在的**缺口，
 * heal 再老老实实去抓 3 次、往交付包里写 3 个垃圾文件（SPA 的 fallback 页），
 * 报告上却写着"已补齐 3 个"。自检撒谎比没有自检更糟，所以这里按属性名的边界取。
 */
function attr(tag, name) {
  const m = new RegExp('(?<![\\w-])' + name + '\\s*=\\s*["\']([^"\']+)["\']', 'i').exec(tag);
  return m ? m[1] : null;
}

function isAssetRel(raw) {
  return String(raw ?? '').toLowerCase().split(/\s+/).some(rel => ASSET_RELS.has(rel));
}

/** 返回 [{ url, kind: 'asset' | 'link' }] */
export function extractRefs(text, kind) {
  const out = [];
  if (kind === 'css') {
    // 必须用 scanCssRefs 而不是朴素全局正则。
    //
    // 实测：vitest.dev 的 cssom.css 里有 data:image/svg+xml 的内联 SVG，
    // 其中含 `filter='url(%23SVGJNgLYdgK)'`（= url(#SVGJNgLYdgK)，指向同文档的 filter）。
    // 用 /url\(([^"')]+)\)/g 扫会把**内嵌的那一条**当成顶层引用，
    // 得到 `%23SVGJNgLYdgK` → 被当成相对路径 → 解析成
    // /static/<host>/pages/<page>/clone/styles/%23SVGJNgLYdgK → 记为"未解析"。
    // 于是健康报告写着 unresolved=91，而真实缺口只有 4 个 —— 报告因此完全失去指向性
    // （用户要么无视它，要么去追 87 个不存在的洞）。
    for (const r of scanCssRefs(text)) out.push({ url: r.raw, kind: 'asset', required: true });
    for (const m of text.matchAll(/@import\s+(?:url\(\s*)?["']([^"']+)["']/gi)) out.push({ url: m[1], kind: 'asset', required: true });
    return out;
  }
  for (const m of text.matchAll(/<(a|link|script|img|source|video|audio|iframe|embed|track|input)\b[^>]*>/gi)) {
    const tag = m[0];
    const name = m[1].toLowerCase();
    if (name === 'a') { const h = attr(tag, 'href'); if (h) out.push({ url: h, kind: 'link', tag: name }); continue; }
    if (name === 'link') {
      const h = attr(tag, 'href');
      if (h) out.push({ url: h, kind: isAssetRel(attr(tag, 'rel')) ? 'asset' : 'link', required: true, tag: name });
      continue;
    }
    for (const n of ['src', 'poster']) { const v = attr(tag, n); if (v) out.push({ url: v, kind: 'asset', required: !['iframe', 'embed'].includes(name), tag: name }); }
    const ss = attr(tag, 'srcset');
    if (ss) for (const part of ss.split(',')) { const u = part.trim().split(/\s+/)[0]; if (u) out.push({ url: u, kind: 'asset', required: true, tag: name }); }
  }
  // Inline CSS is part of the rendered page just like a linked stylesheet.
  // Scan it with the same tokenizer so nested url() inside data URIs is ignored.
  for (const m of text.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style\s*>/gi)) {
    out.push(...extractRefs(m[1], 'css'));
  }
  for (const m of text.matchAll(/<[a-z][^>]*>/gi)) {
    const style = attr(m[0], 'style');
    if (style) out.push(...extractRefs(style, 'css'));
  }
  return out;
}

function pageFiles(liveDir) {
  const pages = [];
  const walk = (dir, rel) => {
    let names = [];
    try { names = readdirSync(dir); } catch { return; }
    for (const n of names) {
      const p = join(dir, n);
      let st;
      try { st = statSync(p); } catch { continue; }
      if (st.isDirectory() && !(rel === '' && n === LIVE_QUERY_DIR)) walk(p, rel ? rel + '/' + n : n);
      else if (n === 'index.html') pages.push(rel ? '/' + rel + '/' : '/');
    }
  };
  walk(liveDir, '');
  return pages.sort();
}

function scanPage(liveDir, pagePath, { host, origin, harIndex, staticDir, onMissingLink }) {
  const visited = new Set();
  const pageUrl = new URL(pagePath, origin);
  const queue = [{ path: pageUrl.pathname, search: pageUrl.search, kind: 'html', base: new URL('.', pageUrl).pathname }];
  const out = {
    assets: { total: 0, local: 0, har: 0, unresolvedCount: 0, dynamic: 0, unresolved: [], external: 0, externalAssetUrls: [], externalRefs: [] },
    links: { total: 0, local: 0, missing: [] },
    probePaths: new Set(),
  };
  while (queue.length && visited.size < MAX_FILES) {
    const item = queue.shift();
    const file = fileFor(liveDir, item.path, item.search, staticDir, host);
    if (!file) continue;
    const key = file + '|' + item.kind;
    if (visited.has(key)) continue;
    visited.add(key);
    let text = '';
    try { text = readFileSync(file, 'utf8'); } catch { continue; }
    let base = item.base;
    if (item.kind === 'html') {
      const bm = /<base\s[^>]*href\s*=\s*["']([^"']+)["']/i.exec(text);
      if (bm) {
        const br = resolveRefPath(bm[1], { host, origin, basePath: item.base });
        if (br && !br.external) base = br.path.endsWith('/') ? br.path : posix.dirname(br.path) + '/';
      }
    }
    for (const ref of extractRefs(text, item.kind)) {
      const r = resolveRefPath(ref.url, { host, origin, basePath: base });
      if (!r) continue;
      if (r.external) {
        if (ref.kind !== 'asset') continue;
        out.assets.external++;
        const raw = decodeEntities(stripHash(ref.url));
        const externalUrl = new URL(raw.startsWith('//') ? 'https:' + raw : raw);
        externalUrl.username = '';
        externalUrl.password = '';
        externalUrl.search = '';
        const clean = externalUrl.href.slice(0, 300);
        if (ref.required || ASSET_EXT.test(raw)) out.assets.externalAssetUrls.push(clean);
        out.assets.externalRefs.push({ url: clean, required: Boolean(ref.required), tag: ref.tag ?? null });
        continue;
      }
      const target = (r.path || '/') + (r.search || '');
      const localFile = fileFor(liveDir, r.path, r.search, staticDir, host);
      if (ref.kind === 'link') {
        out.links.total++;
        if (localFile) { out.links.local++; out.probePaths.add(target); }
        else {
          if (out.links.missing.length < MAX_UNRESOLVED) out.links.missing.push(target);
          onMissingLink?.(target);
        }
        continue;
      }
      out.assets.total++;
      if (localFile) {
        out.assets.local++;
        out.probePaths.add(target);
        if (extname(r.path).toLowerCase() === '.css') queue.push({ path: r.path, kind: 'css', base: posix.dirname(r.path) + '/' });
        continue;
      }
      // 只有**真能放出来的** HAR 条目才算已覆盖。
      // serve.mjs 回放的两个前提：条目有 body（`if (hit && hit.body)`），且它会把录到的
      // 状态码原样返回。所以 **404 / 无 body 的条目不算数** —— 它们以前被计进 assets.har，
      // 于是交付包的 landing 页和 README 说"离线可用"，而部署出去的 serve.mjs
      // 递给浏览器的是一个 404（或落到代理/离线 404）。判据必须与实际回放一致。
      const harHit = harIndex && (matchHar(harIndex, 'GET', origin + target) || matchHar(harIndex, 'GET', origin + r.path));
      if (harHit?.body && harHit.status < 400) { out.assets.har++; out.probePaths.add(target); continue; }
      if (/^\/(?:_next\/image|_next\/data)\b/.test(target)) { out.assets.dynamic++; continue; }
      out.assets.unresolvedCount++;
      if (out.assets.unresolved.length < MAX_UNRESOLVED) out.assets.unresolved.push(target);
    }
  }
  out.scanTruncated = queue.length > 0;
  return out;
}

/** List navigable snapshots, including query pages stored under hashed paths. */
export function listLivePageRoutes(liveDir, origin, queryPages = []) {
  const pages = pageFiles(liveDir);
  for (const page of queryPages) {
    try {
      const target = new URL(page, origin);
      if (target.origin !== origin || !target.search) continue;
      const file = join(liveDir, liveSnapshotPath(target.pathname, target.search));
      if (statSync(file).isFile() && !pages.includes(target.pathname + target.search)) pages.push(target.pathname + target.search);
    } catch {}
  }
  pages.sort();
  return pages;
}

/** 扫描整个交互镜像目录，返回可写入 health.json 的报告对象 */
export function scanLiveBundle({ liveDir, host, origin, harIndex, staticDir = null, queryPages = [], onMissingLink }) {
  const pages = listLivePageRoutes(liveDir, origin, queryPages);
  const details = [];
  const externalAssets = new Map();
  const externalRefs = new Map();
  const missingLinks = new Map();
  const assets = { total: 0, local: 0, har: 0, unresolved: 0, dynamic: 0, external: 0, externalAssets: 0 };
  const unresolvedPaths = new Set();
  const probePaths = new Set(pages);
  let scanTruncated = pages.length > 1000;
  const links = { total: 0, local: 0, missing: 0 };
  for (const pagePath of pages.slice(0, 1000)) {
    const r = scanPage(liveDir, pagePath, { host, origin, harIndex, staticDir, onMissingLink });
    if (r.scanTruncated) scanTruncated = true;
    for (const path of r.probePaths) {
      if (probePaths.size < MAX_PROBES) probePaths.add(path);
      else scanTruncated = true;
    }
    assets.total += r.assets.total;
    assets.local += r.assets.local;
    assets.har += r.assets.har;
    assets.external += r.assets.external;
    assets.unresolved += r.assets.unresolvedCount;
    assets.dynamic += r.assets.dynamic ?? 0;
    for (const u of r.assets.unresolved) { if (unresolvedPaths.size < 5000) unresolvedPaths.add(u); }
    for (const ref of r.assets.externalRefs) {
      if (externalRefs.size >= MAX_EXTERNAL_REF_DETAILS) break;
      const cur = externalRefs.get(ref.url) ?? { url: ref.url, references: 0, required: ref.required, tags: new Set(), pages: [] };
      cur.references++;
      cur.tags.add(ref.tag ?? 'asset');
      const publicPath = pagePath.split('?')[0];
      if (cur.pages.length < 20 && !cur.pages.includes(publicPath)) cur.pages.push(publicPath);
      externalRefs.set(ref.url, cur);
    }
    links.total += r.links.total;
    links.local += r.links.local;
    links.missing += r.links.missing.length;
    for (const target of r.links.missing) {
      if (missingLinks.size >= MAX_MISSING_LINK_DETAILS) break;
      const path = target.split('?')[0];
      const kind = /\.(?:md|markdown|txt|rss|atom|xml)$/i.test(path) ? 'source-document'
        : !extname(path) ? 'path-alias' : 'resource-link';
      const cur = missingLinks.get(path) ?? { path, kind, references: 0, pages: [] };
      cur.references++;
      const publicPath = pagePath.split('?')[0];
      if (cur.pages.length < 20 && !cur.pages.includes(publicPath)) cur.pages.push(publicPath);
      missingLinks.set(path, cur);
    }
    if (r.assets.unresolvedCount) {
      details.push({ page: pagePath.split('?')[0], unresolvedCount: r.assets.unresolvedCount, unresolved: r.assets.unresolved, refs: { total: r.assets.total, local: r.assets.local, har: r.assets.har } });
    }
    for (const url of r.assets.externalAssetUrls) {
      assets.externalAssets++;
      const cur = externalAssets.get(url) ?? { url, pages: [] };
      const publicPath = pagePath.split('?')[0];
      if (cur.pages.length < 5 && !cur.pages.includes(publicPath)) cur.pages.push(publicPath);
      externalAssets.set(url, cur);
    }
  }
  return {
    version: 1,
    host,
    origin,
    generatedAt: new Date().toISOString(),
    pages: pages.length,
    assets,
    links,
    pagesWithUnresolved: details.length,
    unresolvedPaths: [...unresolvedPaths],
    probePaths: [...probePaths],
    pageRoutes: pages,
    scanTruncated,
    details: details.slice(0, 40),
    externalAssetsTop: [...externalAssets.values()].slice(0, 25),
    externalRefsTop: [...externalRefs.values()].map(ref => ({ ...ref, tags: [...ref.tags] })).slice(0, 100),
    missingLinkDetails: [...missingLinks.values()].sort((a, b) => b.references - a.references || a.path.localeCompare(b.path)),
    missingLinkDetailsTruncated: missingLinks.size >= MAX_MISSING_LINK_DETAILS,
  };
}
