import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
const root = process.cwd(), file = 'core/scripts/smoke-acceptance-browser-resolution-console.mjs';
const out = join(root, 'core/workspace/_runs/d4-round7-smoke-render-wait-20261018');
mkdirSync(out);
const current = readFileSync(join(root, file)), text = current.toString('utf8');
const first = text.indexOf('  const freshRow = component().locator('), last = text.indexOf('  checks.explicitFreshReviewUsesNewBoAndRunsNormally = true;', first);
assert.ok(first > 0 && last > first);
const reconstructed = text.slice(0, first) + text.slice(last), sha = value => createHash('sha256').update(value).digest('hex');
const old = JSON.parse(readFileSync(join(root, 'core/workspace/_runs/d4-validation-round6-20261017/source-snapshot.json'), 'utf8')).files.find(row => row.file === file);
const candidates = [reconstructed, reconstructed.replace(/\r?\n/g, '\n'), reconstructed.replace(/\r?\n/g, '\r\n')].map(value => Buffer.from(value));
const before = candidates.find(value => value.length === old.bytes && sha(value) === old.sha256);
assert.ok(before, 'Reconstructed prior script must match the exact round6 frozen bytes');
for (const [name, value] of [['before-reconstructed-verified.mjs', before], ['after.mjs', current]]) writeFileSync(join(out, name), value, { flag: 'wx' });
writeFileSync(join(out, 'change.json'), JSON.stringify({ file, reason: 'Wait for completed/passed UI before taking the fresh-operation screenshot; old gate filters and deadlines unchanged',
  before: { method: 'reverse the added block and independently match round6 snapshot', ...old }, after: { bytes: current.length, sha256: sha(current) } }, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ preserved: true, root: out, priorExactMatch: true }));
