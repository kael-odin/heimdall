
import { browserOperationFixture } from './core/test/fixtures/acceptance-browser-operation.mjs';
import { createBrowserExecutionService } from './core/src/acceptance/browser-execution-service.mjs';
import { createAcceptanceExecutionRuntime } from './core/src/acceptance/execution-runtime.mjs';
const cleanup=[];
const f=await browserOperationFixture({after(fn){cleanup.push(fn);}});
try {
  const request=f.request(), original=createAcceptanceExecutionRuntime();
  const runtime={...original,release(lease){original.release(lease);throw Error('controlled post-release failure');}};
  const store={...f.store,publishRejection(...args){f.store.publishRejection(...args);throw Object.assign(Error('controlled error after actual commit'),{writeMayHaveCommitted:true});}};
  const catalog={read(){return {generationId:request.expectedGenerationId,projects:{[f.project.id]:f.project}};}};
  const service=createBrowserExecutionService({owner:f.owner,catalog,runtime,store});
  service.recover();
  let denialError;
  try {service.denyStart(f.project.id,request.operationId,{action:'deny-future-starts-for-operation',request});}
  catch(error){denialError={code:error.code,status:error.status,writeMayHaveCommitted:error.writeMayHaveCommitted===true};}
  let foreignRead;
  try {service.read('ap-ffffffff-ffff-ffff-ffff-ffffffffffff',request.operationId);foreignRead={unexpectedSuccess:true};}
  catch(error){foreignRead={code:error.code,status:error.status};}
  const result={combinedActualCommitThenStoreErrorAndReleaseError:denialError,foreignProjectLegacyReadOfRejectedOperation:foreignRead,
    persistedDecision:f.store.inspectDecision(request.operationId).kind,runtimeState:original.state(),
    proofStillReadable:service.resolution(f.project.id,request.operationId).outcome};
  console.log(JSON.stringify(result,null,2));
} finally {for(const fn of cleanup.reverse()) await fn();}
