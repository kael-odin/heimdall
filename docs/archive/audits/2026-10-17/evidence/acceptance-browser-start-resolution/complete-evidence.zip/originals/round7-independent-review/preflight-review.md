# round7 启动决定恢复预检独立审查

记录日期：2026-10-18（Asia/Hong_Kong）。本稿只对应 round7 的 **preflight-resolution-ui**；最终串行 `browser-resolution-ui` 尚未在此审查，不能把预检 9/9 当成最终全门禁结论。只读核验原件及图片，没有修改源码、启动 Browser/Core 或提交推送。

预检 smoke 为 `browser-resolution-console-smoke-1e399928-0f01-4308-b357-70bc71516aff`，UTC 2026-10-17T16:11:41.246Z–16:12:35.360Z，香港 2026-10-18 00:11:41.246–00:12:35.360。summary/checks 均为 passed、9/9；外层 preflight guard UTC 16:11:40.764–16:12:40.525，exit 0、unchanged true、600 files，冻结快照 SHA `f700d54a3bb10a55748818d68b6d33fe43724f8485ec72063e0a35d253c078d8`。独立原件验证 exit 0，实际执行只读 guard check 返回 unchanged/600。

## 原生锁与原子准入

直接读取四组 `native-lock-interleavings.json`，每组均为同 origin/project key、exclusive holder 1、pending 2、两个不同 pending clientId。完整原集合逐项衔接，不只统计长度：

| 交错 | 集合变化 | 返回值及核验 |
| --- | --- | --- |
| save-save | 0→2 | `[null, null]`，原两条完整确认均保留。 |
| resolve-save | 2→2 | `[null, null]`，精确解除首条，保留第二条并新增第三条。 |
| resolve-resolve | 2→0 | `[null, null]`，两条精确解除。 |
| claim-start-claim-start | 0→1 | `[true, false]`，唯一 after 严格等于首组原 a 确认，没有第二条回执。 |

最后 browser-storage 的两个 receipt key 均为字符串 `[]`，sessionStorage 为空、无来源 sentinel 泄漏。这是实际 helper 在两个真实页面中使用原生 navigator.locks/localStorage 的证据；两页实际 Vue 同时 start 的准入由独立纯状态测试覆盖，不扩大声称为双 Vue DOM/storage-event 闭环。

## 真实终态渲染与四图

四张本轮 PNG 已逐张实际打开；图片字节与 SHA 落在 `preflight/independent-evidence-check.json`。

- 桌面 light：原启动未知确认可见；重新复核并勾选后新启动按钮灰置。内部滚动导致下部动作没有全部进入本张采样，完整说明另有 DOM 原件。
- 手机 dark：未知提示、原操作号和原确认上半部可读；下部拒绝后 pending 说明仅由完整 DOM 证明，不声称首屏目视覆盖。
- 桌面 dark recovered：原永久拒绝证明已核验、本机原确认已解除的提示可见。页面下方仍展示先前 broken 参考比较的“发现缺陷”，与这次解除事实分属各自状态，没有把解除冒称旧比较通过。
- 手机 light fresh：已目视显示 “Healthy new target / 已完成 · 通过”、对应 `bo-e383231a-194e-41bf-9a6b-09e4fee25a67` 及“读取完成报告与证据”按钮；停止按钮不存在。

`fresh-rendered-state.json` 与 fresh API 的原操作号严格一致，text 为“已完成 · 通过”，reportButtons=1、stopButtons=0；`layouts.json` 的 fresh 文本同样包含该 bo 和终态，排除“请求停止”。fresh API completed/passed，声明检查14/14。与 round6 截图过早采样不同，这次预检已实际等待正确 DOM 终态。待最终串行 smoke 完成后必须重新打开其四图，不沿用本轮图片作为最终证据。

桌面 client/scroll=964/964、手机296/296，documentWidth 分别等于1440/390视口，没有采样横向溢出。它们不构成全量无障碍认证。

## 其他原件一致性

A 仍为原 UI JSON body 经单一 Node HTTP relay 分段进入真实 engine：342 bytes，prefix171，唯一 ingress request/connection，body SHA `af7dcd739e7ebc6e2885159eeb325ab479d2928b1e5d769934bdcbe2443e477a`；不是 Chromium 原生 socket 拆包。A/B 实盘拒绝均761 bytes、canonical JSON+单个LF，SHA分别为 `48222098cdee304f55b72cf4186b4f939923216ba55589840f1ed763c8d9be6f` 和 `1cad87e948a70a7ed0ceb97f6e0fd010c0a7cdec4b9978fd68ebb33b0bf0f075`。

B 重启前后 origin `http://127.0.0.1:56867` 和 storage key 相同，丢失一次真实拒绝响应后，恢复只发3次GET。总start3、deny2，没有恢复重发POST。SIGTERM/可能SIGKILL的重启策略不能单独证明优雅退出。

原来源29文件SHA逐项一致，source/broken/healthy请求各4。pageErrors为空；5条error全部逐条匹配受控503，错误原件保留，没有将其删除后声称零错误。受控站点、固定路由/视口/交互与只读策略的证据不扩大为任意业务、登录态、PRD或Figma还原度保证。

原件验证结果见 `preflight/independent-evidence-check.json`；源码冻结原件见 `preflight/source-freeze-check.json`。后续最终全Core、11组兼容门禁、D4提交及其自身CI均需协调者按各自完成原件填写。
