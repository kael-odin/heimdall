# D4 最小实施切片、并行接口与验收矩阵

日期：2026-10-17（Asia/Hong_Kong）。状态：只读实施审查，**尚未实现、尚未运行任何 D4 测试**。本稿基于 `core/workspace/_runs/d4-unknown-operation-design-20261017.md` 和当前 D3 service/API/store/schema/UI。D3 源码及 publisher 已收集的原件保持冻结；本轮仅新增本独立 ignored sibling，不启动 Browser/Core、不改旧稿、不提交推送。

## 1. 可交付的最小闭环

交付目标是：未知原启动通过同一数据根内的不可变永久拒绝事实安全结束；所有迟到的同 bo 启动均被挡住；用户只在核对完整 proof 后解除原回执，并自行重新复核、用全新 bo 开始。等待时长、普通 HTTP 错误或某次 GET 查不到都不构成 proof。

最小发布必须同时包含 Store/schema、Service/API、Console 三条实现及两条真实主线。可以按接口并行写代码和离线测试，不能先单独上线“清除等待”按钮。没有 TTL、拒绝删除、同 bo 重用、自动重 POST、partial 自动修复、全局批准或业务问题最终关闭。

决定单元仍为 `browser-operations/v1/bo-*`。exclusive mkdir 只是本次调用的占用，完整 immutable dispatch 或 rejection 提交并回读后才形成可公开证明的决定。新 accepted 与新 rejected 都必须独占新目录；已有目录只能 inspect，不得补文件。

## 2. 先锁定的 accepted / rejected / partial 边界

当前 store `readInternal`（153–182）以有效 dispatch 定义原接受事实；head 可选，无 head 为 prepared。仅在 completed 且 full 读取时验证 report 和索引证据。`recover`（299–313）先整批预检，prepared 不启动，running 收束 interrupted。必须保留这些接受与恢复含义。

| 现场 | D4 分类及处理 |
| --- | --- |
| 整个 bo 目录不存在 | absent；GET 只报告瞬时 unresolved，不建立文件事实 |
| 有效 dispatch，head 不存在 | recorded/prepared；不重新接纳或启动，不以当前来源状态阻断原事实 proof |
| 有效 dispatch，有效 running/failed/interrupted head | recorded；非 completed 的 report 残片及安全平面 evidence 作为 opaque 执行残留保留，不拿它们证明完成或通过 |
| 有效 dispatch，有效 completed head | recorded；公开完整读取/证明按现有 completed 校验检查 report 绑定、摘要和索引证据，坏产物返回受控核验失败，不伪装为 absence |
| 只有严格有效、canonical+LF 的 rejection.json | rejected；原件字节/时间永久不变，不生成 run/task、执行列表或 BUG 观察 |
| 空目录、evidence-only、缺 dispatch 且无完整 rejection、坏 dispatch/head | 未完成/损坏决定，失败关闭，保留全部现场，不补 rejection |
| rejection 与 dispatch/head/report/evidence/observations 或其他条目混合 | integrity failure，不按优先级选一类继续 |

accepted 根目录允许的语义条目为必需 `dispatch.json`，可选 `head.json`、`report.json`、`observations.json` 和安全 `evidence/` 目录。非 completed 的 `report.json` 不要求 JSON 可解析、不要求匹配 completed 摘要；安全的空文件或半写入内容同样不能被解释成通过。非 completed 的 observations 不进入账本，后续只有合法 completed 读取及登记路径才可解释它。

`evidence/` 只接受现有 `browserOperationFileName` 规则允许的安全平面 png/json 文件形状：无子目录、symlink、hardlink、路径跳转或超预算条目。非 completed 的这类产物可以为空或半写入，保持 opaque，不做 PNG/JSON 解码，不删除、不补齐；它们不属于完成 proof。completed 索引引用仍按现有 bytes/SHA 校验，未索引文件不能被界面使用或计入检查通过。来源文件在真正需要消费时仍按原合同验证，不能把“已有 accepted 决定”写成“全部产物完好”。

新增保守形状规则拒绝未知根 entry、未受本次调用追踪的根临时文件和其他不安全节点；这是 D4 明确新增的完整性边界，不能声称 D3 原先已检查全部根条目。当前调用发布期间的自有 temporary 只能由私有 capability 按精确名称/inode 临时纳入预期集合，不能全局允许任意 `*.tmp.*`。重启后没有该 capability，不自动清理或采纳残留 temporary。

**必须原样保留旧测试** `acceptance-browser-operation-store.test.mjs:116–129`：running a 下 `report.json = '{partial'` 后 recover 返回 2 interrupted、1 prepared；`store.read(a)` 可读 interrupted，残片原字节保留。新增 D4 测试用同一场景再加入有效 rejection；再加入一个混合/坏决定，证明全批预检失败时第一个 running head 也未修改。

现有 `captures().current()`（103–117）只回查已经读过的文件，不验证 rejection 的不存在或根 entry 集合。D4 首次 inspect、提交前 guard、提交后 proof 都必须重新验证决定互斥及 forbidden entries。不能只固定 dispatch SHA/inode；也不能机械要求运行中所有合法 evidence 文件集合永远不变，因为原 runner 会正常增加产物。固定决定类型和禁止条目的负条件，按阶段检查允许集合；新 claim 临界区则要求精确的自有条目集合。

## 3. 三条并行实现的最小接口约定

以下名称是下一步实施契约，**当前 D3 尚未提供**。先以此搭建测试 fake 和共享向量，合并时保持原 D3 方法及返回形状。

### A. Store/schema 负责

```text
inspectDecision(operationId, { full = true } = {}) -> 同步严格 union
  { kind: 'absent', operationId }
  { kind: 'recorded', value: 原 D3 internal operation }
  { kind: 'rejected', record: { envelope: Rejection, bytes: Buffer, sha256 } }

publishRejection({ projectId, request }, { assertCurrent }) -> 同步
  { decision: recorded 或 rejected, replayed: boolean }

publish(原输入, { assertCurrent }) -> 保持 { record, replayed }
```

`inspectDecision` 是纯读：不创建 namespace，不修复，不调用 recover，不写 marker。坏/混合决定抛受控错误，永不返回 absent。公开 proof 使用 full 校验；恢复内部可按状态保留非 completed opaque 产物，但仍检查决定、head 和安全形状。

`publishRejection` 内部持有新目录的私有 claim；已有 matching recorded/rejected 只返回原决定，其他 fingerprint 冲突。accepted 的 `publish` 也改用同一独占 claim；遇到 rejected 必须受控拒绝，绝不先写 source evidence。claim 绑定本 store、本 bo、决定类型、fingerprint 和目录身份，用闭包/私有 WeakMap 等真实能力表示，不能从 JSON、路径或 bo 重建。

沿用不可覆盖临时文件发布与 fsync，提交前后重新验证 owner、claim、active lease guard、目录身份及互斥形状。拒绝编码单独固定为 `UTF8(canonicalAcceptanceJson(record) + '\n')`，上限 16 KiB；不能改写旧 dispatch 编码或旧原件。提交/读回不明继续传播 `writeMayHaveCommitted`，不能被 store boundary 吞掉。

list/ledger 先验证决定类型，执行列表和 BUG 账本只使用 accepted；容量计算包含 accepted+rejected。recover 对全部决定预检后才写任何 head，拒绝不变、prepared 不启动。保持现有 recover 返回字段，避免给全旧 accepted 场景增加无意义字段而破坏原 deepEqual 断言。

主要文件：`browser-operation-schema.mjs`、`browser-operation-store.mjs` 及对应 schema/store 测试。Store 不依赖 runtime 私有对象；现有同步 guard 由 Service 提供。

### B. Service/API 负责

```text
service.resolution(projectId, operationId) -> 同步 Resolution
service.denyStart(projectId, operationId, { action, request })
  -> 同步 { status: 200, payload: Resolution(recorded | rejected) }

GET  /projects/:projectId/browser-executions/:bo/resolution
POST /projects/:projectId/browser-executions/:bo/deny-start
```

新拒绝算法：owner/严格输入 → inspect 原事实优先 → 查 private pending/handles → recovery/readiness/closing/blocked/项目范围 → 当前 generation 必须等于原 generation（revision 可变化）→ reserve 共享槽 → 持槽后再次检查原事实/private maps/owner/lease → 同步有界发布 → 回读完整 proof → 只释放自己的确切 lease。此段不能 await catalog queue、runner 或外部回调，不 bind run/task，不读来源或重新物化候选。

已有原事实优先于当前 catalog revision、来源可用性和 busy/readiness；prepared 只读、不续跑，running 不被 deny 停止。pending 保存 projectId 以供项目隔离；不能只凭同 bo 向另一项目暴露在途状态。原 execute 的最前端也改为 decision inspect，迟到请求读取 rejected 后 runner=0；inner catch/settle 同样分流，不能对 rejected 调旧 `store.read()` 再把一个已知拒绝误作未知发布或尝试 settlement。

GET resolution 只做 owner、指定决定、必要的项目存在性及 private 在途状态读取。禁止调用 ready/capability 中可执行的 readiness 回调、reserve/bind/stop/release、recover、publish、mkdir、来源读取或 runner；不等待 pending Promise。已有匹配事实即使引擎 busy/blocked/closing/recovery 未就绪仍可读。仅不存在时可返回 ABSENT_OBSERVED 或 ADMISSION_PENDING，均不是安全忘记证明。

API 新 action 必须显式方法表：resolution 仅 GET，deny-start 仅 POST。现有 router 的方法推导（91–92）会把未列出的单操作 action 默认视为 GET，只加 suffix 不够。两个新端点继续 no-store、鉴权、owner、16 KiB fatal UTF-8/object-only body、精确路径/查询参数及安全错误边界。

新增受控错误至少明确 BROWSER_ADMISSION_PENDING、BROWSER_START_REJECTED、BROWSER_OPERATION_SCOPE_UNVERIFIED 的 409 映射；保留 writeMayHaveCommitted→outcomeUnknown。拒绝首发/重放均 200，已有 recorded 亦 200；busy/pending/conflict/partial/鉴权等失败没有解除能力。原启动成功仍只接受既有 200/202，不扩大为任意 2xx。启动遇到永久拒绝可返回 409 proof，但客户端若 helper 不保留该 payload，必须继续 GET resolution，而不是凭错误码清回执。

主要文件：`browser-execution-service.mjs`、`browser-execution-api.mjs`，必要时 engine 路由接线和对应 service/API/runtime 测试。Service 与 Store 按上述 union 对接，不把内部路径或完整 source 暴露到 API。

### C. Console 负责

公共 `Resolution` 严格 union 采用设计稿合同：共同字段 schemaVersion=1、kind=browser-start-resolution、projectId、operationId、observedAt、outcome；仅以下额外字段允许：

| outcome | 额外字段 | 解除条件 |
| --- | --- | --- |
| recorded | request、requestFingerprint、dispatchSha256、operation | project/bo/原六字段、domain fingerprint、严格原 operation view 全部绑定通过 |
| rejected | rejection、rejectionSha256 | 原件严格字段及 canonical+LF 字节摘要独立重算，project/bo/原六字段/fingerprint 全部通过 |
| unresolved | reasonCode=ABSENT_OBSERVED 或 ADMISSION_PENDING | 永不解除 |

原六字段固定为 operationId、expectedGenerationId、expectedRevision、candidateId、contentDigest、targetReleaseId；fingerprint 输入还包含 projectId，复用 domain `heimdall-browser-operation-request`、version=1。generation/revision 不能从当前页面重建。原有 `browserOperationView`（helper:83）仅比较 bo/candidate/digest/target 四字段，不能作为 D4 完整 proof。客户端需新增严格异步 union 验证及 SHA 计算，使用服务端共享的固定 canonical/hash 测试向量，不能因字段顺序或 pretty JSON 产生另一种摘要。

必须同时处理所有回执清理/绕过分支：

1. 移除 Vue `load():62–65` 按列表 view 自动 resolve；列表只是展示，不是完整原请求证明。
2. 移除 `start` catch `104–106` 的普通 4xx resolve。400/401/404/405/409/413/429、网络失败、坏 JSON、超时均保留回执。
3. 移除 `unknown:20` 按 bo 已出现在列表就排除的逻辑；所有未通过完整 proof 的 pending 都阻断 canStart，即使列表包含同 bo。
4. 成功 start 的旧 operation view 仍不能直接解除；继续专用 GET proof。显式 deny 只有核验后的 recorded/rejected 解除。任何错误码附带的未经验证 proof 不可直接使用。
5. 将单条清理收紧为 `resolveExact(expectedRequest)`：清理前重新读取并核对原六字段，删除该确切条目后回读完整剩余集合，保留其他条目。裸 bo 不足以授权删除同 bo 另一确认。storage 写/回读失败不得显示解除成功。
6. 请求前捕获 project/origin/receipt client；旧响应不得使用当前的新 client 清理另一项目，不能回填新 UI。切换上下文可选择保留旧回执待返回后只读恢复。初始化 storage 失败继续阻断提交，不能因 pending 为空恢复 canStart。

deny-start POST 复用独立最长 60 秒期限，覆盖 fetch **及 response.json body**，不随 read epoch 重置，不自动重发；timeout/abort/fetch/body 失败均 outcomeUnknown。finally 释放 writing 并清理 timer/listener。resolution GET 用独立 read guard，GET 取消传播，永不触发 POST。UI 显示原 bo/候选/目标/原确认摘要和“永久拒绝此操作的迟到启动”，不叫重试、不取消真实 running、不自动创建新 bo。

主要文件：`acceptance-browser-execution.js`、`AcceptanceBrowserExecution.vue`、对应 console 测试及新的 D4 专项 smoke。保存完整来源继续仅在内存；localStorage 仅保留原六字段。

当前 localStorage 整集合 read→set→read 不是跨标签页事务：仅即时完整回读无法证明两个标签页交错写不会丢条目。D4 不应宣称已支持该并发保证；实施前需明确单写入者范围，或将 save/resolve 放入同 origin/project 的实际跨页互斥/事务并加双页交错测试。不能以新增回读断言代替真实互斥。

## 4. 必须测试的 race / crash / unknown 恢复矩阵

以下全部是待实施的验收要求，没有在本轮运行。每个测试同时观察决定类型、原始字节/目录身份、runtime lease 和实际 runner/POST 次数，不能只断言 UI 提示或 HTTP 状态。

| 场景 | 必须证明 |
| --- | --- |
| 空 namespace 连续 GET、长期 unresolved/404 | 不创建任何 namespace/marker；文件树、字节、inode 及非访问时间属性不变；runtime 写方法、来源物化和 runner 全 0；回执保留 |
| GET 已有事实，当前 busy/blocked/closing/recovery 未就绪/来源坏 | 原匹配 proof 可读；不调用 ready/recover、不改变 lease/状态 |
| GET foreign project、foreign pending、unknown project、partial | 隔离为 404/受控失败或正确 unresolved；无跨项目事实泄漏、无持久修改、不 await pending |
| 原 HTTP POST body 未 end，deny 先赢 | 原连接完成同一 body 后被永久拒绝；只一个原 POST、一个 deny；拒绝字节不变、runner 0 |
| execute await catalog 且 pending 存在；reserve 已拿但 pending 尚未可见 | 分别 pending/busy；不写 rejection、不停止原 Promise、不释放原 lease，原执行最多 1 次 |
| accepted 先赢，覆盖 prepared/running/completed/failed/interrupted | deny 返回原 recorded；不改写、不取消 running、不续跑 prepared；原 fingerprint 不变 |
| rejected 先赢，再 execute、重复 deny、直接 store.publish | 同确认原拒绝/异确认冲突；bo 永久占用，0 source 写入、0 run/task/runner；rejectedAt/bytes/SHA 恒定 |
| 同 generation 不同 revision；不同 generation | 前者可提交原确认拒绝，后者 scope-unverified 无新目录；不替换原六字段 |
| legacy/Spec/Browser 各自占共享槽 | 新拒绝失败无持久变化；不能强占/释放别人 lease；已有事实仍可读 |
| 两条决定路径在 mkdir 前竞争；EEXIST 为 recorded/rejected/空目录 | 只有一个 claim；重 inspect 原决定或 fail closed，不补文件、不重用目录 |
| 首次 inspect 后或最终 guard 前插入 rejection/unknown entry | 负条件和形状回查拒绝发布另一决定；不得依靠初次 SHA 快照 |
| root/parent/bo 替换，symlink/hardlink、容量/IO失败 | 受控完整性失败、保留现场、无私有路径泄漏；不认 absence |
| mkdir 后、临时写后、link 后 unlink 前强停 | 残留未完成决定/多链接按现场 fail closed；重启不补 rejection、不启动，全部原字节保留 |
| rejection 完整提交后、回包前崩溃/丢响应 | 同根正常重启后 GET 读同一原件/SHA；回执仍在，只读核验后只删该条；不重 deny/启动 POST |
| 提交后 readback/owner/lease 失败 | writeMayHaveCommitted→outcomeUnknown 保留，runtime block；只释放自有 lease，不删现场/回执 |
| 批次最后一个决定坏/混合 | recover 在首个 head 写入之前失败；没有部分 running 提前改写或任何隐式执行 |
| 有效 running + '{partial' report + 安全半成品 evidence | 原旧测试不变；recover→interrupted，原片保留可读；prepared 不启动 |
| rejection 被 createRun/finish/settle/register/evidence/ledger 访问 | 永不进入 accepted 写路径、执行状态、检查通过或 BUG 观察 |
| 六字段逐一错配，尤其仅 generation/revision 错 | proof 拒绝、回执保留；不能被同 bo 列表 view 或旧四字段校验旁路 |
| union 多/缺/跨 variant 字段、canonical/摘要/ISO错误、原件篡改 | 严格拒绝，无清理；服务端 accessor/Proxy/thenable 测试不执行 hooks |
| deny fetch 永挂、response body 永挂、timeout/abort/JSON/普通4xx/5xx | 有界释放 writing，原回执仍在、只一个 POST；之后只读恢复 |
| 项目/候选/目标/epoch 改变、迟到 proof、ABA、storage 故障 | 不回填新上下文，不清另一确认/其他回执，不把 storage 失败报告成解除成功 |
| accepted+rejected 达容量，旧 D3 打开 D4 root | 新决定被拒、原 proof 可读、无 TTL；旧版 fail closed，不删除 marker “修复” |
| D3→D4 及连续 D4 pass 的混合 verifier 复验 | 仍 incomparable，不放宽原 verifier 固定/首次 BUG 来源；旧 issue 不自动 verified_passed |

真实 kill-point 使用独立 child process 和临时数据根，对 mkdir/temporary/link/commit/readback 精确停点后终止并重开；不能只 mock existsSync。测试专用控制不得把任意异步用户回调引入产品同步临界段。只读快照不使用 atime 作为“无写入”反例；运行中的独立 owner heartbeat 应与被测方法的持久行为分开记录。

## 5. 两条真实主线与关键 harness 约定

**A：同一原慢 body 请求被拒绝。** native UI 先保存真实原回执，受控流式代理/HTTP harness 将同一原 POST 的部分 body 交给引擎并保持连接未 end；显式 deny 成功后释放余下原字节。记录 ingress 连接标识、Content-Length、拒绝前收到的 body 字节、最终 body SHA、原 bo/fingerprint、请求计数和 runner=0。不能在拒绝后新发一条相同 JSON POST 来冒充尚未完成的原请求。若为了让 UI 进入 unknown 主动丢前端响应，应如实区分浏览器响应与仍在途的引擎 ingress。

**B：拒绝已提交但响应丢失，重启后只读恢复。** 回执保留；引擎按保留事实的同一真实 root 正常重启；仅 GET resolution 核验原 rejection 并精确删原回执；用户重新复核后新 bo 正常执行。**必须保持相同 engine origin/端口和原 storage key**。当前 D3 execution smoke 的 startEngine 每次取新端口；D4 B 不得沿用后复制 localStorage 到新 origin 来伪称原回执自动恢复。可先 about:blank 结束无关轮询，再停引擎、同端口重启及重新打开控制台，完整保留同一 context/storage。

A 与 B 独立运行。重启会摧毁旧引擎 socket，不能声称原连接跨重启存活；需要跨重启迟到交付时，须由引擎外代理保留且只交付一次，并明确证据边界。实际 UI 记录至少包含请求清单、回执原始值、决定目录/字节摘要、重启前后 proof、runner 次数、桌面/手机明暗截图。先跑离线 store/service/API/DTO 门禁，再只用一个 Browser slot 跑这些主线。

## 6. 集成顺序与发布边界

1. 锁定本稿 Store union、Service 方法、公共 Resolution 和 canonical/hash 向量；三条 agent 按文件责任并行实现，各自先用 fake/fixture 验证契约。
2. 合并 Store/Service 后跑真实临时根互斥、kill-point、共享槽和纯读 GET；合并 Console 后覆盖所有旧回执清理分支及完整响应体期限。
3. 单 Browser 跑 A/B 与原先赢/busy/partial/跨项目场景；保留失败，不放宽错误过滤或比较门禁。
4. store/schema 改变报告 verifier 后，单独审查固定来源兼容 manifest；保留 D3 已审查原件，不将新旧指纹自动等价。连续 BUG 复验与所有旧消费者回归后再形成 D4 发布冻结。

保证限定当前 owner 对应真实数据根及保留拒绝事实的正常进程重启。六字段回执没有稳定 dataRootId，generation 门禁不能证明复制 root、磁盘回滚或备份丢失事实后仍 exactly-once。Windows 目录元数据 flush/整机掉电耐久性未实测时不得扩大承诺。

本轮只读审查完成。当前没有实施 D4、没有运行上述验收，没有改动 D3 源码或发布原件。
