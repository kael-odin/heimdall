# D4 设计稿：长期不存在的未知 Browser 启动安全解除

日期：2026-10-17（Asia/Hong_Kong）。状态：只读设计，尚未实现。D3 产品源码继续冻结；本稿不构成已通过的功能或测试声明。

## 目标与自主选择

让用户能安全结束一个始终查不到的原启动确认，并继续重新复核新的验收。安全依据是服务端为原 `bo-*` 发布不可变的永久拒绝事实，令任何迟到的同操作号启动都失去执行可能；不能证明“等了足够久，所以没有提交”。

选择 **同一 `browser-operations/v1/bo-*` 目录作为唯一持久决定单元**：它只能是有效原执行记录，或者有效 `rejection.json`，不能二者并存。所有已有空目录、缺文件、损坏或混合现场都保持未知并原样阻断。新接受与新拒绝都必须独占创建全新操作目录；创建成功只是占用，完整事实提交并核验后才是决定。

不选独立的 sibling tombstone namespace 作为首版方案：旧 D3 引擎会忽略陌生目录，可能重新接受同 `bo`；把拒绝放入同一 `bo` 决定单元，旧 D3 会因缺少 dispatch 而失败关闭。代价是 D4 必须明确更新 list/recover 的类型分流，且回退旧版会阻断接纳，不能宣称透明降级兼容。

“长期”的时间阈值只用于显示帮助文字或减小按钮干扰，不进入任何安全判定。没有自动解除、自动重发、自动生成新操作或重新使用原操作号。

## 已核对的 D3 基础与缺口

| 当前源码事实 | 对 D4 的影响 |
| --- | --- |
| `browser-execution-service.mjs` 的 execute 先查原记录，再查 pending，然后 reserve 共享槽 | 保留历史事实优先；不得把 prepared 当作可重新启动的队列 |
| service 有私有 pending Map 和 handles Map；pending 覆盖异步 catalog 准备，handles 覆盖真实执行 | 拒绝前必须同时检查；但尚未读完 HTTP body 的迟到请求不在这两个 Map 中 |
| `browser-operation-store.mjs` 仅在整个操作目录不存在时返回 null；有目录但缺 dispatch 会失败 | 不能捕获该失败后将 partial 当作 absence；不能删除后重建 |
| store publish 当前 `pathOf(id, true)` 允许既有目录，先复制 source evidence 再提交 dispatch | D4 需要改成仅向本次独占创建的目录写入，防止在拒绝目录内先写 evidence 后才发现冲突 |
| runtime 的 reserve 是共享唯一 lease；state 的 busy 是瞬时观测 | `busy === false` 不能替代 reserve；拒绝必须获得自己的 lease，且不能释放其他工作的 lease |
| store recover 当前整批预检，再将 running 收束为 interrupted | D4 必须先完整检查 accepted/rejected/partial 全部目录，再允许任何恢复写入 |
| 公开 operation view 不含原 expectedGenerationId / expectedRevision | D4 解除需要新增完整原确认 proof，不能只比 candidate/digest/target |
| 前端 load 当前按列表中 operation view 自动 resolve，unknown 又排除已出现在列表的 bo | D4 必须移除这两个旁路；所有尚未通过完整 resolution proof 的 receipt 都继续阻断新启动 |
| 前端 start catch 当前会根据普通非 unknown 的 4xx 删除回执 | D4 应删除这种泛化解除；回执只凭匹配的原记录或永久拒绝事实解除 |
| 浏览器 POST 有独立 60 秒期限，超时保留原回执并不重发 | 新拒绝 POST 复用这个期限；超时后只读查询 resolution |

实际读取的源文件：`core/src/acceptance/browser-execution-service.mjs`、`browser-operation-store.mjs`、`browser-operation-schema.mjs`、`browser-execution-api.mjs`、`execution-runtime.mjs`、`owner.mjs`、`catalog.mjs`、`identity.mjs`、`core/src/engine-server.mjs`，以及 `console/src/AcceptanceBrowserExecution.vue` 和 `acceptance-browser-execution.js`。以上是当前工作树事实，不是 D4 已有能力。

## 核心状态机与不变量

服务端局部状态：

```text
ABSENT --原启动获得共享 lease + exclusive mkdir--> CLAIMED_FOR_ACCEPT
       --显式拒绝获得共享 lease + exclusive mkdir--> CLAIMED_FOR_REJECT

CLAIMED_FOR_ACCEPT --来源核对 + immutable dispatch 提交--> RECORDED(prepared)
RECORDED(prepared) --仅本次新接纳调用栈--> running --> completed / failed / interrupted

CLAIMED_FOR_REJECT --immutable rejection 提交并回读核对--> REJECTED

任一 CLAIMED 中断/崩溃/不完整 --> PARTIAL（保持现场，禁止自动转移）
RECORDED 或 REJECTED 冲突/损坏 --> INTEGRITY_BLOCKED（保持现场）
```

CLAIMED 是实现中的临时能力，不作为“安全未启动”公开；新进程看到未完成目录只认 partial。REJECTED 不分配 `br-*`、`a-*`，不产生通过门禁或 BUG 观察，也不伪装成 interrupted / prepared。

必须保持：

1. 同一真实数据根内，一个 `bo` 永久占用；任何 fingerprint 都不能使已拒绝的 `bo` 再开始。
2. 同 fingerprint 的既有 accepted / rejected 只读返回原事实；不同 fingerprint 冲突。不能以新 revision 替换原确认再试。
3. 只有完全不存在的决定目录才能被本次 exclusive mkdir 占用。`EEXIST` 后只重新 inspect，绝不向既有目录补文件。
4. partial、未知条目、符号链接、硬链接、替换根目录、容量超限或无法确认身份，全部失败关闭；不 catch 后当作不存在。
5. 原事实读取先于今天的来源、revision、readiness、busy；新增拒绝才需要新的 owner / recovery / runtime 接纳能力。
6. 拒绝只约束原操作号，不证明历史上从未发送 HTTP 或从未发生外部副作用；本方案不改变旧执行的取消语义。

## 持久拒绝记录

首版目录形状：

```text
acceptance/browser-operations/v1/bo-<UUID>/
  rejection.json       # 唯一允许的完整拒绝目录内容
```

接受目录继续采用 D3 dispatch/head/report/evidence/observations。新增一个严格的 inspect 原语，区分 `absent | recorded | rejected`；partial 和混合形状直接抛受控 integrity/unavailable 错误，不返回一个可解除的“partial”成功对象。

拒绝记录严格为下列字段，无任意 reason、路径、URL、来源文本或进程细节：

```json
{
  "schemaVersion": 1,
  "kind": "browser-start-rejection",
  "projectId": "ap-<UUID>",
  "operationId": "bo-<UUID>",
  "request": {
    "operationId": "bo-<UUID>",
    "expectedGenerationId": "ag-<UUID>",
    "expectedRevision": 12,
    "candidateId": "bc-<UUID>",
    "contentDigest": "<64 lowercase hex>",
    "targetReleaseId": "ar-<UUID>"
  },
  "requestFingerprint": "<64 lowercase hex>",
  "rejectedAt": "<canonical ISO UTC>",
  "reasonCode": "USER_REJECTED_UNKNOWN_START",
  "effect": "deny-future-starts-for-operation",
  "actor": { "kind": "local-user" }
}
```

`requestFingerprint` 复用现有 `browserOperationRequestFingerprint({projectId, ...request})`，其 domain 是 `heimdall-browser-operation-request`、version 1。它包括 projectId 和原六字段，不能只比较可见的 candidate/digest/target。所有字段使用现有 strict plain-data 边界，拒绝未知字段、accessor、Proxy、thenable、symbol、非规范 ID/时间/摘要。

新 rejection 原件编码固定为 `UTF8(canonicalAcceptanceJson(record) + '\n')`，上限 16 KiB。持久前与读取后都要求原字节等于该固定编码，`rejectionSha256` 是这份原字节的 SHA-256，不把摘要写进记录自身。前端按同一编码独立重算；这是一致性核对，不是数字签名，仍依赖受鉴权的当前引擎事实。

拒绝目录不允许 dispatch/head/report/evidence/observations、额外文件、临时文件残留或其他 accepted / partial 事实。record 与 rejection 任意混合都整体阻断，不能根据优先级任选其一。拒绝记录没有 TTL、删除 API、解除拒绝 API 或操作号复用机制；它计入现有全局操作及目录容量，容量满时保留回执并明确阻断。

## 精确 API 与 DTO

沿用 `/api/acceptance/projects/:projectId`、引擎鉴权、真实 root owner、`Cache-Control: no-store` 和受控错误。新增两个专用端点，不改变 D3 原 GET 查询、报告或证据的含义。

| 方法与后缀 | 精确定义 |
| --- | --- |
| `GET /browser-executions/:operationId/resolution` | 只读查 accepted/rejected 原事实；absence 或 admission pending 只能返回 unresolved，不写文件、不 reserve、不发起执行 |
| `POST /browser-executions/:operationId/deny-start` | 用户明确永久拒绝原操作号的迟到启动；body 必须携带原六字段，不能用当前页面版本重新生成 |

POST body 严格为：

```json
{
  "action": "deny-future-starts-for-operation",
  "request": {
    "operationId": "bo-<与路径相同的UUID>",
    "expectedGenerationId": "ag-<原UUID>",
    "expectedRevision": 12,
    "candidateId": "bc-<原UUID>",
    "contentDigest": "<原64位摘要>",
    "targetReleaseId": "ar-<原UUID>"
  }
}
```

没有 force、expiry、重新批准、删除记录、取消当前真实执行或重发启动选项。action 是明确意图，reason/actor/effect 由服务端固定生成。

公共 response 是严格的 discriminated union。共同字段仅 `schemaVersion:1`、`kind:'browser-start-resolution'`、`projectId`、`operationId`、`observedAt`、`outcome`，各变体只能有下面的额外字段：

| outcome | 额外字段 | 前端可否解除回执 |
| --- | --- | --- |
| `recorded` | `request`（原六字段）、`requestFingerprint`、`dispatchSha256`、`operation`（现有严格 view） | 全部绑定核对通过后可以；prepared 仍是原事实，不会启动 |
| `rejected` | `rejection`（上述完整原件）、`rejectionSha256` | 原六字段/project/fingerprint/字节摘要全部核对通过后可以 |
| `unresolved` | `reasonCode:'ABSENT_OBSERVED' \| 'ADMISSION_PENDING'` | 绝不可以；不返回 `safeToForget:true` 等误导能力 |

GET 原事实若属于其他项目返回 404；未知项目也返回 404。存在的匹配原事实先于当前 catalog 查询，因此即使目录 revision 变化或来源不可用，仍可核对它。GET absence 只有瞬时观测含义，不能被客户端缓存为永久否定。

POST 状态与效果：

| HTTP / code | 行为与 response |
| --- | --- |
| `200` / `rejected` | 首次拒绝完整提交、回读核验后返回 proof；同确认已拒绝则返回同一 rejection 原件 |
| `200` / `recorded` | 原接受记录已存在，返回原 proof，不改写、不取消、不启动 |
| `409 BROWSER_ADMISSION_PENDING` | 原 pending/handle 尚在；不等它、不中止它、不写拒绝；回执保持 |
| `409 ACCEPTANCE_BUSY` | 共享 legacy / Spec / Browser 槽被占；不强占、不写拒绝；回执保持 |
| `409 IDEMPOTENCY_CONFLICT` | 同 bo 另一确认；不返回他项目内容，回执保持 |
| `409 BROWSER_OPERATION_SCOPE_UNVERIFIED` | 新拒绝无法确认原 generation 仍属于当前项目存储范围；不写拒绝，回执保持 |
| `400 / 401 / 404 / 405 / 413` | 输入、鉴权、归属或方法失败；不构成解除 proof，回执保持 |
| `503 BROWSER_OPERATION_INTEGRITY_FAILED` / `BROWSER_EXECUTION_UNAVAILABLE` | partial、身份异常、owner/recovery/closing/blocked、I/O 等；保留现场和回执 |
| `503` 且 `outcomeUnknown:true` | 提交可能已发生，但读回/owner/响应失败；阻断新接纳，之后只读查 resolution |

原启动 POST 遇到完整同 fingerprint 的 rejection，返回 `409 BROWSER_START_REJECTED`，可附同一严格 `rejected` proof；其他 fingerprint 返回幂等冲突。两者 runner 启动次数都必须为 0。前端仍必须核对 proof，不能只看 409 码。

deny-start 首次与重复都使用 200，避免复用 helper 时与 D3 POST 仅接受 200/202 的合同冲突；不把原启动扩成接受任意 2xx。helper 仅增加两个受限路径和各自 DTO 验证，原启动的 200/202 含义保持。

## 服务端拒绝算法与竞态闭合

1. owner 校验；严格解析路径和原请求，计算 project + 原六字段 fingerprint。先 inspect 此 bo 的完整决定。匹配 recorded/rejected 直接返回原 proof；异项目隐藏、其他 fingerprint 冲突；partial 直接失败。该步骤不重新物化来源。
2. 查 pending 和 handles。发现原启动尚在内存中则返回 admission pending，不等待 Promise、不替它释放 lease，也不把超时当作失活。
3. **仅新增拒绝**要求 recoveryReady、当前引擎接纳健康、未 closing/blocked，并确认当前项目存在。首版再要求当前 catalog generation 等于原 expectedGenerationId，revision 可以变化；不刷新原请求、不要求当前候选仍可执行、不读取来源。generation 不匹配保持 unresolved/冲突，防止把另一数据根或重建目录当成原请求的空白现场。此条件是额外保守门禁，不能替代下文的数据根边界。
4. 使用现有 runtime `reserve({kind:'browser', operationId})` 获得共享 lease。它仅是元数据决定的互斥锁，不 bind run/task、不启动 Browser、不生成作业投影。state().busy 的观测不能替代 reserve。
5. 持 lease 后再次验证 owner、active lease、pending、handles 和完整决定目录。已有事实则释放自己的 lease 后只读返回；新出现 partial/冲突则失败。pending/handle 不得仅以 operationId 字符串推断已完成。
6. 保持后续决定段同步且有界，不 await catalog queue、runner、外部 Promise 或用户回调。先完成所有 DTO、预算、编码和当前 catalog scope 核验，再用非 recursive exclusive mkdir 占用全新 bo 目录。`EEXIST` 只重新 inspect；绝不复用 `pathOf(id,true)` 的既有目录分支。
7. 固定该新目录真实 inode。发布 rejection 的最终 guard 再查 owner、active lease、pending/handles、根/父/操作目录身份及其预期文件集合，要求没有任何 accepted 或异物事实。只能向本次调用持有的私有 reservation capability 对应目录写入；该能力不能由 JSON、路径或 operationId 重建。
8. 使用不可覆盖发布：新临时文件 exclusive open → 写入固定字节 → fsync → 身份与字节回查 → guard → no-replace link/提交 → 清理本次已追踪临时 inode → owner/目录/lease 和完整原件回查。响应只能在完整 proof 可重新读取后发出。
9. 成功或失败都仅释放本次确切 lease。发布后任何步骤失败设置 `writeMayHaveCommitted` 并 block `PUBLICATION_UNCERTAIN`；不删除操作目录、不覆盖拒绝、不清回执。失败临时文件只能清理本次追踪且身份仍一致的 inode；残留不确定现场保持 partial。

原启动路径必须同时补齐以下边界，否则拒绝不成立：

- execute 最前端严格 inspect accepted/rejected/partial，然后才查 pending / readiness / reserve。
- store.publish 开始再次检查决定；新的 accepted 同样采用 exclusive mkdir，不能在拒绝后把 source evidence 写入既有 bo。
- dispatch 最终提交 guard 验证本次 reservation capability、owner、active lease、目录身份、无 rejection、来源与 catalog 当前性。独占创建后不允许调用另一写路径“补全”同 bo。
- createRun、finish/settle、register/evidence/read 都严格使用 accepted 分支；rejected 永远不能进入 runner。store 层保护不能只放在 HTTP handler，直接服务调用也必须安全。

HTTP body 在 deny 提交前尚未读完的原 POST 不在 pending 内，但它稍后进入 execute 时会读到永久拒绝。原 POST 若已经 reserve，deny 无法 reserve；若已经 publish，deny 只返回原事实。事件循环中的同步决定段加 owner 与共享 lease 封住正常调用交错，exclusive mkdir 与最终 guard 再封住目录竞争及未来误用。

## 恢复、兼容与耐久性范围

- D4 startup 对所有 bo 先严格 inspect 两类完整决定和所有异常现场；任一 partial/混合/损坏/超容量阻断整批恢复，不得先修改其他 running。完整 rejection 只核验，不转换、不产生 run；完整 accepted 沿用 D3 的 running → interrupted、prepared 不启动。
- 执行列表仅列 accepted；专用 resolution 可读取 rejection；BUG 账本只处理 accepted 的完整观察。不能把 rejection 作为某个声明检查“通过”或业务问题关闭。
- 同目录方案让 D3 旧版 fail closed，但不承诺旧版可以继续运行。不得以删 rejection、挪走目录、伪造 dispatch 或启动旧执行入口来“修复”降级阻断。
- D4 必改的 store/schema 都在报告 verifier 指纹集合内，新 D4 报告与历史 D3 报告的 verifier 不同，会按现有 browserCheckRelation 判为 incomparable。继承问题链始终核对首次 BUG 的原 verifier，因此连续多个 D4 pass 也不能自动将旧 D3 issue 设为 verified_passed。首版保留这个保守边界并加入 D3→D4 混合报告回归；不能自动把新旧摘要视为等价。来源兼容指纹另须审查固定，旧 D3 已审查原件保持不变。
- 首版永久拒绝保证限定**当前 owner 对应的真实数据根及保留其事实的后续正常进程重启**。文件 fsync、不可覆盖发布、目录身份和提交后回读是必需项；实现必须明确所用平台目录元数据持久化语义。Windows 无法执行目录 flush 时不能悄悄声称已验证整机掉电耐久性。
- 现有六字段 receipt 没有稳定 dataRootId；generation 门禁只能缩小误范围，不能覆盖复制相同 catalog 到另一 root、磁盘回滚、备份恢复丢失拒绝或人为删除。D4 不宣称跨这些操作的 exactly-once。若以后需要扩大范围，应另立存储身份及备份/回滚门禁，不在本切片临时增加弱 root 字符串。
- 不按时间清理 tombstone。1024 决定容量包含 accepted + rejected；到限拒绝新增决定，已有匹配事实仍能读取。扩容或归档必须另行设计能保留拒绝约束的机制。

## 前端最小流程

1. 原 receipt 继续仅保存原六字段，按 engine origin + project 隔离；原内容不可被当前页面 revision/候选/目标覆盖。对账新 GET resolution 时核对 schema、variant 字段、项目/操作号、原六字段及 domain fingerprint；recorded 还校验既有 operation view 和 dispatch 摘要形状，rejected 还独立重算 canonical 原件摘要。
2. 未知条目继续提示“原启动结果尚待核对”。GET 404、absence、deadline、HTTP 错误、JSON 错误和普通 4xx 都不能清 receipt。同步移除 D3 中按一般 4xx 直接 resolve receipt 的分支。
   同时移除 load 根据操作列表自动 client.resolve 的分支，并修改 unknown/canStart：所有尚未通过 resolution proof 的 receipt 都阻断启动，即使同 bo 已出现在列表也不能绕过。列表只用于展示和触发专用只读对账，不作为解除 proof；新 GET resolution 可逐项自动读取，但只在完整 proof 校验后精确解除。
3. 未知条目提供显式动作“永久拒绝此操作的迟到启动并解除等待”。说明若原记录已存在只读取它，不取消真实任务；若服务端仍在接纳或现场不完整则保持等待。点击前显示原操作号、候选、目标及原确认摘要，不能把这个动作包装为“重试启动”。
4. 点击一次发送 deny-start 原确认，沿用独立 60 秒 POST 期限；不绑定 read epoch，不自动重发。成功 proof 核对通过后，才通过原 capture 的 receiptStore 删除这一个 receipt，并回读完整剩余集合；storage 失败继续保持待核对。
5. POST 超时、丢响应或上下文改变后，后续只读查询原 resolution。旧响应只能处理它捕获的 origin/project/receipt，不污染新项目的 operations、错误或按钮状态；read guard / channel 防 ABA，POST 写请求不随项目切换重发或复制。
6. 解除只释放这次未知等待。后续新启动仍要完整复核、手动确认、生成全新 bo；不能因为成功拒绝自动启动。返回 recorded prepared 也不能续跑。
7. 本机 receipt 损坏无法验证时，仍阻止提交；本切片不增加“清全部 localStorage”或“忽略错误继续”入口。

## 故障与竞态矩阵（实现后必须验证）

| 场景/注入点 | 预期事实与响应 | 前端 / runner |
| --- | --- | --- |
| 连续 GET 404 或 unresolved 多次，时间很久 | 不写决定，不推导安全 absence | receipt 保留；0 次重发 |
| 原 POST body 尚未送完，deny 先成功 | rejection 完整提交；原 body 到齐后返回拒绝 | 核对 proof 后解除；runner 0 |
| 原 execute pending，尚未写目录 | admission pending，不中止原 Promise、不写拒绝 | receipt 保留；最多原执行 1 次 |
| 原 execute 已 reserve，pending 尚未可见 | deny reserve busy，不写拒绝 | 不释放原 lease |
| 原 prepared/running/completed/failed/interrupted | 匹配原 fingerprint 返回 recorded | 不改写，不续跑 prepared，不停止 running |
| 目录/source 已变化但原事实有效 | 原 fact 先于当前目录/ready/busy 返回 | 可按完整 proof 解除 |
| 未知 bo 的原 generation 与当前目录不同 | scope unverified，不刷新 CAS、不写拒绝 | receipt 保留 |
| 同 bo 其他项目或 fingerprint | 隐藏/冲突，不暴露原合同 | 不解除，不启动 |
| 已拒绝后，同确认重复 deny | 原拒绝字节、时间、digest 不变 | 可恢复解除；runner 0 |
| 已拒绝后，同/不同确认迟到启动 | 相同拒绝 / 幂等冲突 | 所有路径 runner 0 |
| legacy / Spec / Browser 占槽 | 新拒绝 busy，既有事实仍可查 | 不强占，不创建 run/task |
| 已有空 bo 目录、evidence-only、临时文件或缺 dispatch | partial/unavailable，全部字节和 inode 保留 | 不解除，不补 rejection |
| exclusive mkdir 前出现 EEXIST | 重新严格 inspect | 不向既有目录写 source 或拒绝 |
| 新拒绝 mkdir 后、record 提交前进程崩溃 | partial 保留；重启 fail closed | 不解除，不自动修复 |
| source 写入中崩溃 / dispatch 提交前失败 | accepted partial 保留 | 不转成 rejected |
| rejection 提交后、响应前丢连接/崩溃 | 重启读取同一 rejection 原件 | GET proof 后解除；无 POST retry |
| rejection 提交后读回失败/owner 丢失 | outcomeUnknown + runtime block | receipt 保留；不删目录 |
| link 后临时 hardlink 残留或 marker 非规范编码 | integrity failure，保留现场 | 不凭解析后的内容解除 |
| dispatch 与 rejection 或其他 partial 事实共存 | 整体 integrity failure | 不择一继续，恢复无任何写入 |
| 任一 root/parent/bo 替换、symlink、hardlink、I/O异常 | 身份/边界失败，受控错误无私有路径 | receipt 保留，runner 0 |
| malformed DTO / 注入 getter、Proxy、thenable / oversized body | 验证失败且不调用可执行 accessor | 不发布、无执行 |
| receipt 仅 generation/revision 与 proof 不同 | fingerprint/六字段校验失败 | 不解除 |
| UI 项目/候选/目标/epoch 在请求中改变 | 旧结果不回填新上下文 | 原 receipt 独立核对，无新 POST |
| 删除 receipt 时 storage 丢失其他条目或写失败 | 完整集合回读失败 | 不报告解除成功 |
| 1024 决定已满 / 未知条目超预算 | capacity fail，无 TTL 清理 | receipt 保留；原 proof 仍能查 |
| D4 目录交给 D3 旧服务 | 缺 dispatch 导致旧恢复/执行失败关闭 | 不启动，不自动转换 |

## 最小可交付切片与门禁

一个可交付切片必须包含完整闭环，不能只加前端“忘记”按钮：

1. **Store/schema**：strict decision inspection、不可变 rejection、accepted/rejected 双方 exclusive claim、迟到提交 guard、双类型恢复/容量/账本边界；保留所有 partial 证据。
2. **Service/API**：两个专用端点与上述 union；owner + 原事实优先 + private maps + shared lease 前后双查；安全错误与提交不明传播；原启动的 durable rejection fence。
3. **Console**：完整原六字段/fingerprint/原件摘要验证、显式 deny、独立 deadline、只读恢复、精确单 receipt 回读解除、移除普通 4xx 解除。现有来源全文继续只放内存。
4. **验证与交付**：离线 store/service/API/DTO 测试先通过；随后只开一个 Browser slot 跑受控真实 UI/CDP 场景，落请求计数、原始目录树/字节摘要、重启前后 proof、localStorage 与截图；更新专用文档和导航，不先拓展其他功能。

必须真实跑两条独立新增主线：A）已保存回执 → 原 POST body 已连接引擎但未 end → 显式永久拒绝 → 释放原 body → 同一原 POST 被拒绝且 runner=0；B）未知回执 → 显式拒绝已提交但响应丢失 → 引擎重启 → 只读 proof → 只删原 receipt → 用户重新复核，以全新 bo 正常启动。旧引擎连接会被重启销毁，不能把重启后新发的 POST 伪称为存活的原请求；若要同一原请求跨重启延迟交付，须在引擎外代理/浏览器 route 保留尚未交付的请求，并记录只交付一次。另跑原操作先赢（prepared/running/completed）、pending/其他槽 busy、partial 崩溃、提交后读回不明、错误 fingerprint、手机/桌面明暗、跨项目迟到响应和 D3→D4 混合 verifier 复验边界。

store 的 kill-point 与 inode/字节污染需要真实进程及临时数据根测试，不能只 mock `existsSync`；共享槽竞态用 deferred catalog / HTTP body 精确控制。整机掉电、复制数据根或备份回滚若未实测，不纳入保证。原 D3 单次完整确认、来源不重访、证据 SHA、连续复验、正常取消和所有旧消费者边界必须继续回归。

## Review 边界

审查重点是“证明一个安全的持久终止决定”，不是“猜测未执行”。必须逐条审查每个 accepted 写入口、拒绝写入口、startup recovery、API DTO、receipt 清理分支和持槽期间的 await/回调，确认不存在绕过 rejection 或污染另一类型目录的路径。

特别要检视：普通 4xx 被误当 proof；只比较 candidate/digest/target；检查 tombstone 后先写 source 再最终发现冲突；只读 busy 不 reserve；lease 被其他路径释放；pending 缺口及慢 HTTP body；既有 partial 被空目录复用；错误映射丢掉 writeMayHaveCommitted；跨项目旧响应；tombstone TTL/容量/降级兼容；Windows 持久性承诺与实际证据不匹配。

本切片不建设全局 Browser approval/selection、业务工单聚合/最终关闭、自动重新提交、通用队列、AI triage、任意修复流水线或 partial 自动修复。发现需要这些能力时另开范围，不把 D4 的安全解除变成新的隐式执行入口。
