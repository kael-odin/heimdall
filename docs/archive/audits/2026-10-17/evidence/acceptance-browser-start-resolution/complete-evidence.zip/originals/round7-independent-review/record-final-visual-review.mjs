import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const review = dirname(fileURLToPath(import.meta.url)), final = join(review, 'final'), root = resolve(review, '../../../..');
const read = name => JSON.parse(fs.readFileSync(join(final, name), 'utf8'));
const write = (name, value) => fs.writeFileSync(join(final, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const machine = read('machine-summary.json'), evidence = read('independent-evidence-check.json');
assert.equal(machine.status, 'machine-passed-awaiting-visual-review'); assert.equal(evidence.status, 'passed');
assert.equal(machine.sourceDirectory, evidence.sourceDirectory);
const observations = [
  { name: 'resolution-A-desktop-light.png', visible: '桌面light显示原启动未知提示、原bo与候选/目标、重新复核和勾选后的灰置启动按钮；原确认说明可读。', limitation: '内部滚动采样未覆盖原确认下部的全部动作，完整说明另见DOM。' },
  { name: 'resolution-B-mobile-dark.png', visible: '手机dark显示未知确认提示、原bo和原候选上半部，文字可读且未见采样横溢。', limitation: '首屏只覆盖原确认上半部；拒绝后pending说明由完整DOM原件证明，不能称为截图目视覆盖。' },
  { name: 'resolution-recovered-desktop-dark.png', visible: '桌面dark显示原永久拒绝证明已核验、本机原确认已解除及要求重新复核的提示，没有自动启动。', limitation: '下方旧broken参考比较仍为发现缺陷；它不是随后fresh操作结果，不能混为通过。' },
  { name: 'resolution-fresh-mobile-light.png', visible: `手机light显示Healthy new target、已完成·通过、${evidence.freshRenderedState.operationId}及读取完成报告与证据按钮，停止按钮不存在。`, limitation: '只证明此受控操作在采样视口的终态渲染，不构成任意业务站点或全量无障碍保证。' },
];
assert.equal(observations.length, evidence.screenshots.length);
for (const item of observations) {
  const fact = evidence.screenshots.find(value => value.name === item.name); assert(fact);
  const bytes = fs.readFileSync(join(machine.sourceDirectory, item.name)); assert.equal(bytes.length, fact.bytes); assert.equal(sha(bytes), fact.sha256);
  Object.assign(item, { absolutePath: join(machine.sourceDirectory, item.name), bytes: fact.bytes, sha256: fact.sha256,
    actuallyOpened: true, method: 'tools.view_image of this final root, after completed final gate and machine re-read' });
}
const reviewedAt = new Date().toISOString();
write('visual-review.json', { status: 'passed', phase: 'final-browser-resolution-ui', reviewedAt, sourceDirectory: machine.sourceDirectory,
  screenshotCount: observations.length, screenshots: observations, usedPreflightImages: false, freshRenderedState: evidence.freshRenderedState });
const snapshotBytes = fs.readFileSync(join(root, 'core/workspace/_runs/d4-validation-round7-20261018/source-snapshot.json'));
const snapshot = JSON.parse(snapshotBytes); assert.equal(snapshot.files.length, 600); assert.equal(sha(snapshotBytes), machine.baselineSha256);
for (const file of snapshot.files) { const bytes = fs.readFileSync(join(root, file.file)); assert.equal(bytes.length, file.bytes); assert.equal(sha(bytes), file.sha256, file.file); }
write('source-after-visual-check.json', { status: 'passed', verifiedAt: new Date().toISOString(), sourceFiles: snapshot.files.length,
  baselineSha256: sha(snapshotBytes), currentFileBytesMatch: true, phase: 'final-browser-resolution-ui-after-actual-visual-review' });
const manifestBytes = fs.readFileSync(join(final, 'artifact-manifest.json')), manifest = JSON.parse(manifestBytes);
assert.equal(manifest.files.length, 25);
write('review-summary.json', { status: 'passed', phase: 'final-browser-resolution-ui-only', completedAt: new Date().toISOString(),
  sourceDirectory: machine.sourceDirectory, checks: evidence.checks, sourceFiles: snapshot.files.length, baselineSha256: sha(snapshotBytes),
  screenshotsActuallyOpened: 4, artifactFiles: manifest.files.length, artifactBytes: manifest.files.reduce((total, file) => total + file.bytes, 0),
  artifactManifestSha256: sha(manifestBytes), fullReleaseOrCiConclusion: false });
console.log(JSON.stringify(read('review-summary.json'), null, 2));
