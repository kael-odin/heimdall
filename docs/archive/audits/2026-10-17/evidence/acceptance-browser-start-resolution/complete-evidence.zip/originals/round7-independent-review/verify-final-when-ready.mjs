import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { dirname, join, resolve, relative, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';

const review = dirname(fileURLToPath(import.meta.url)), root = resolve(review, '../../../..');
const validation = join(root, 'core/workspace/_runs/d4-validation-round7-20261018');
const final = join(review, 'final'), gateRoot = join(validation, 'browser-resolution-ui');
const summaryPath = join(gateRoot, 'summary.json');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const read = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const write = (file, value) => fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
fs.mkdirSync(final, { recursive: true });
if (!fs.existsSync(summaryPath)) {
  console.log(JSON.stringify({ status: 'waiting', phase: 'final-browser-resolution-ui', reason: 'The final gate has not completed.', summaryPath }));
  process.exit(0);
}
const gate = read(summaryPath);
assert.equal(gate.label, 'browser-resolution-ui'); assert.equal(gate.exitCode, 0); assert.equal(gate.unchanged, true);
const stdout = fs.readFileSync(join(gateRoot, 'stdout.log'), 'utf8').trim().split(/\r?\n/);
const completed = stdout.map(line => { try { return JSON.parse(line); } catch { return null; } })
  .filter(value => value?.status === 'passed' && typeof value.outputDirectory === 'string');
assert.equal(completed.length, 1, 'Need exactly one completed final smoke output record.');
assert.equal(completed[0].checks, 9); const smoke = resolve(completed[0].outputDirectory);
const within = relative(join(root, 'core/workspace/_runs'), smoke);
assert(within && !within.startsWith('..') && !isAbsolute(within));
assert.match(within, /^browser-resolution-console-smoke-[0-9a-f-]+$/);
assert.notEqual(smoke, join(root, 'core/workspace/_runs/browser-resolution-console-smoke-1e399928-0f01-4308-b357-70bc71516aff'));
const smokeSummary = read(join(smoke, 'summary.json'));
assert.equal(resolve(smokeSummary.outputDirectory), smoke); assert.equal(smokeSummary.status, 'passed');
assert(Date.parse(smokeSummary.startedAt) >= Date.parse(gate.startedAt));
assert(Date.parse(smokeSummary.endedAt) <= Date.parse(gate.endedAt));

const snapshotBytes = fs.readFileSync(join(validation, 'source-snapshot.json')), snapshot = JSON.parse(snapshotBytes);
assert.equal(sha(snapshotBytes), 'f700d54a3bb10a55748818d68b6d33fe43724f8485ec72063e0a35d253c078d8');
assert.equal(sha(snapshotBytes), gate.baselineSha256); assert.equal(snapshot.files.length, 600);
const before = read(join(gateRoot, 'before.json')), after = read(join(gateRoot, 'after.json'));
assert.deepEqual(before, snapshot.files); assert.deepEqual(after, snapshot.files);
for (const file of snapshot.files) { const bytes = fs.readFileSync(join(root, file.file)); assert.equal(bytes.length, file.bytes); assert.equal(sha(bytes), file.sha256, file.file); }
write(join(final, 'source-freeze-check.json'), { status: 'passed', verifiedAt: new Date().toISOString(), phase: 'final-browser-resolution-ui',
  sourceFiles: snapshot.files.length, baselineSha256: sha(snapshotBytes), gate, beforeMatches: true, afterMatches: true, currentFileBytesMatch: true });

const startedAt = new Date().toISOString();
const verifierArgs = [join(review, 'verify-completed-smoke.mjs'), smoke, final];
const result = spawnSync(process.execPath, verifierArgs, { cwd: root, windowsHide: true, encoding: null, maxBuffer: 16 * 1024 * 1024 });
fs.writeFileSync(join(final, 'verifier.stdout.txt'), result.stdout ?? Buffer.alloc(0), { flag: 'wx' });
fs.writeFileSync(join(final, 'verifier.stderr.txt'), result.stderr ?? Buffer.alloc(0), { flag: 'wx' });
write(join(final, 'verifier-command.json'), { startedAt, endedAt: new Date().toISOString(), executable: process.execPath, args: verifierArgs,
  cwd: root, exitCode: result.status, signal: result.signal, error: result.error?.message ?? null });
assert.equal(result.status, 0, result.stderr?.toString('utf8'));
const evidence = read(join(final, 'independent-evidence-check.json'));
assert.equal(evidence.status, 'passed'); assert.equal(evidence.sourceDirectory, smoke);
const manifestNames = ['summary.json', 'checks.json', 'A-original-request.json', 'B-restart-proof.json', 'native-lock-interleavings.json',
  'fresh-rendered-state.json', 'fresh-after-resolution.json', 'final-operation-collection.json', 'engine-ingress.jsonl', 'layouts.json',
  'browser-requests.json', 'browser-errors.json', 'controlled-transport-replies.json', 'target-requests.json', 'browser-storage.json',
  'source-file-digests.json', 'source-and-candidate.json', ...smokeSummary.captures,
  ...smokeSummary.captures.map(name => name.replace(/\.png$/, '-dom.txt'))];
const manifest = manifestNames.map(file => { const bytes = fs.readFileSync(join(smoke, file)); return { file, bytes: bytes.length, sha256: sha(bytes) }; });
write(join(final, 'artifact-manifest.json'), { sourceDirectory: smoke, files: manifest });
const outcome = { status: 'machine-passed-awaiting-visual-review', verifiedAt: new Date().toISOString(), phase: 'final-browser-resolution-ui',
  sourceDirectory: smoke, sourceFiles: snapshot.files.length, baselineSha256: sha(snapshotBytes), artifactFiles: manifest.length,
  checks: evidence.checks, freshOperationId: evidence.freshRenderedState.operationId, screenshotsToOpen: smokeSummary.captures.map(file => join(smoke, file)) };
write(join(final, 'machine-summary.json'), outcome); console.log(JSON.stringify(outcome, null, 2));
