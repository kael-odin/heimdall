import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const output = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(output, '../../../..');
const files = ['console/src/acceptance-browser-execution.js', 'console/src/AcceptanceBrowserExecution.vue',
  'core/test/acceptance-browser-start-resolution-console.test.mjs', 'core/test/acceptance-browser-start-resolution-console-state.test.mjs'];
const snapshot = () => files.map(file => {
  const bytes = fs.readFileSync(path.join(root, file));
  return { file, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') };
});
const before = snapshot(), startedAt = new Date().toISOString();
const args = ['--test', files[2], files[3]];
const result = spawnSync(process.execPath, args, { cwd: root, encoding: null, maxBuffer: 16 * 1024 * 1024 });
const finishedAt = new Date().toISOString(), after = snapshot();
fs.writeFileSync(path.join(output, 'pure-tests.stdout.txt'), result.stdout ?? Buffer.alloc(0));
fs.writeFileSync(path.join(output, 'pure-tests.stderr.txt'), result.stderr ?? Buffer.alloc(0));
const metadata = { startedAt, finishedAt, executable: process.execPath, args, cwd: root, exitCode: result.status,
  signal: result.signal, error: result.error?.message ?? null, before, after, unchanged: JSON.stringify(before) === JSON.stringify(after) };
fs.writeFileSync(path.join(output, 'pure-tests.json'), JSON.stringify(metadata, null, 2) + '\n');
process.stdout.write(result.stdout ?? Buffer.alloc(0));
process.stderr.write(result.stderr ?? Buffer.alloc(0));
process.exit(result.status ?? 1);
