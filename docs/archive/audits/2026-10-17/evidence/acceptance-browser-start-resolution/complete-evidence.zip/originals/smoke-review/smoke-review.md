# D4 新真实 smoke 独立只读审查

日期：2026-10-17（Asia/Hong_Kong）。审查人：browser_fixed_runner。只读检查脚本、fixture、产品源码和协调者产生的第二轮失败原件；未启动 Browser/Chromium/Core，未修改产品或 smoke 源码，未修改 D3 门禁。

## 结论与当前证据等级

最终轮已通过 9 项真实 smoke 检查，四张截图已逐张打开，A/B/双页 helper 原件已独立交叉核验；未发现阻断。详见末尾“最终轮原件与视觉复核”。下文初审和第二轮失败记录保留，以区分原始脚本缺陷、协调者修复及最终证据。

第二轮目录：`../browser-resolution-console-smoke-28c823ae-12d0-4332-bb98-6ea57728c4c5/`。已读 failure.json、failure-dom.txt、browser-requests.json、engine-ingress.jsonl，并直接查看 failure.png。

## A：原确认、单一未完成 ingress 与持久拒绝

脚本取得原生 UI 唯一 start 请求的 postData 原字节，路由拦截后交给 openSlowBrowserPost。fixture 创建一个 Node HTTP ClientRequest，声明完整 Content-Length，flush headers 后只 write 前半包，直到 finish 才在同一个 request end 剩余尾部。没有在拒绝后新建同 bo 的补发请求。

ingress fixture 通过预加载观察 Server 的 request 以及产品 req.emit 事件；不安装 data listener，不 read/resume，不改变 body。它只匹配独立 scope 文件中的路径、operationId 与 trace header，记录连接编号、累计字节和增量 SHA。

脚本先等待 engine 实际 data 累计等于 splitAt 且没有 end，再向原 UI 回 503 形成未知状态。后续预定断言为：显式拒绝成功并清理精确回执时原 body 仍未 end；此后才 finish；同一 ingress 完整字节及 SHA 与原 UI body 一致；operationId/traceId 一致；只有一个连接、一个 ingress request；原 start 返回 409 BROWSER_START_REJECTED；无目标请求增加，无接纳 operation；拒绝目录只有 rejection.json 且字节不变。

准确叙述应为“拦截原 UI 请求 body 后，通过单一真实 HTTP relay 将同一原确认分段传入 engine”。它不是 Chromium 原生 socket 的分段发送。

第二轮实际观测：Content-Length=342；唯一连接收到 171 字节 data，ended=false；之后因 smoke 失败 teardown close，仍没有 end。仅此部分可声明已真实观测。

## B：丢失拒绝响应、同 origin 进程重启与只读恢复

脚本的 B start 被拦截、不送达 engine；deny 通过 route.fetch 真正送达，先核对服务端 rejected 响应，再将浏览器回复替换成受控 503。proof 暂时同样被阻断，以保证原回执保留。

重启前保留 DATA/ROOT、完整 base URL、BrowserContext 和 receipt storage key；停止 engine 后使用原端口重启，不重建 context。恢复时要求 GET resolution 出现，相关恢复请求全为 GET，全页面 POST 计数不变，start 仍只有 A/B 两次，deny 只一次。拒绝文件字节和原回执变化单独留证。

stop(child) 先 SIGTERM，等待五秒仍未退出则可 SIGKILL；未断言或记录精确退出方式。因此该 smoke 能证明的是同 root/origin/port/context 的真实进程重启，不单凭它扩称已验证优雅退出。

## 双页原生 Web Locks

脚本在同一个真实 BrowserContext 新建同 origin 第二页，两页均导入实际 helper 源码为 data module，客户端使用真实 localStorage 和默认 navigator.locks。

每种 interleave 先用真实原生 exclusive 锁占用精确 storage key，再分别从两页发起写入，使用 navigator.locks.query 要求两个同 key pending waiter。释放前存储值必须不变；释放后两页读取结果必须一致。覆盖 save-save、resolve-save、resolve-resolve，另测试 locks:null 只读且 save reject。

该证据针对实际 helper 与原生双页锁；没有在两页都挂载 Vue 组件并验证 storage event 对 UI 的更新，不能扩称为该种 DOM 闭环。

## 第二轮脚本缺陷与产品 UI 核对

unknown() 在回执行出现后直接读取 start.isDisabled。Vue 的 start finally 会 clearReview，启动按钮位于 v-if validReview 内；因此此时按钮缺席，Playwright 等待元素超时。failure.json 的错误位置就是 unknown()。

failure.png 与 DOM 一致：待核对提示、原操作编号、候选、目标、完整六字段展开入口和明确拒绝确认均可见。原批准 review 不再出现，符合一次批准消耗后失效的行为。当前截图内未见控件遮挡或横向溢出；这只覆盖该轮桌面暗色局部状态，不代替最终四种视口主题截图。

建议只修新 smoke：先核对原回执精确内容、可见 unknown 文案和 start POST 计数不增。若要检验用户重新核对后的 gate，可重新点击复核、等待 confirmation、勾选原批准框，再要求新出现的 start disabled，同时回执仍在且 POST 计数不增。无需改产品或放宽 D3。

## 静态检查与源码快照

三个新脚本 node --check 均通过。以下为此次只读审查时的 SHA-256 快照，不表示协调者后续 smoke 修正后的版本已冻结。

| 文件 | SHA-256 |
|---|---|
| core/scripts/smoke-acceptance-browser-resolution-console.mjs | c0f03986267f6fef5be19c9fc34537aed79e25e305a3a95732d5ed6446855516 |
| core/scripts/fixtures/browser-resolution-stream.mjs | 0c6f8079ece2cc92c1765e1f9237b9ff85ba55d249b2408c07a2f88ea88a81bd |
| core/scripts/fixtures/browser-resolution-ingress.mjs | a828895be70e7f011437be8da0f0dd603656f65c1c61fc7e8a2f2182437b574c |
| console/src/AcceptanceBrowserExecution.vue | 605eb1b43ab5bc9281b49bd4d6013b3d833b38528749c85989dfb4e1fdb73fdc |
| console/src/acceptance-browser-execution.js | ad8f5e20be1c3d88a29a2bed64f7a3b41c967d99d9499a6dd61c55574f770c3e |

初审阶段等待实际运行和截图；其后的最终复核见下。本报告不覆盖或删除前两轮失败证据。
## 最终轮原件与视觉复核

最终运行目录：`../browser-resolution-console-smoke-6f362c69-28ab-4455-ac69-4e3a2d4dae98/`。运行 UTC 2026-10-17 15:08:58.960–15:09:52.953，即香港时间 23:08:58.960–23:09:52.953。summary.status=passed，checks.json 的九项全部 true。round4 外部 guard 记录 smoke exitCode=0。

独立核对脚本及结果保存在本报告目录：`independent-evidence-check.mjs`、`independent-evidence-check.json`。该脚本仅读取最终原件及其 runtime 文件，不发 HTTP，不启动 Browser/Core。执行 exit 0。

### 实际原件核对

- A 原 UI JSON 为 342 字节；重算 SHA-256 为 `dd589f5e275cd7322df38176cc8b9b8bb3feb267ac0adbd4425b2403c93eb3f3`，与 relay 和 engine 完整 ingress 一致。唯一连接、唯一 request 先到 171 字节，再到 342 字节和 end；只释放一次尾部，原 start 返回 409 BROWSER_START_REJECTED。此处继续准确标注为原 UI body 的单一 HTTP relay，不称 Chromium socket 分段。
- A/B 实盘拒绝目录分别仅有一份 rejection.json，均为 761 字节，实际字节均等于 canonical JSON 加 LF。重算 SHA 分别为 `5b936cf948dfda2560056a432a56af9f9cf452a0b6a2798746b496764f668520` 和 `be29f1f64ed7f95345960c1a9355f1512387e759193167136b482782aec59398`，与 proof 原件匹配，原六字段一致。
- B origin 前后均为 `http://127.0.0.1:62466`，storage key 完全相同；lostDenyCount=1，原回执保留到重启后验证证明，再变为空。recoveryRequests 记录 3 次 GET resolution，无恢复 POST。拒绝内容与 SHA 在重启前后不变。
- 双页 helper 的 save-save、resolve-save、resolve-resolve 均记录原生锁 held=1、pending=2，两个等待者有不同 clientId，且均为同 key exclusive。集合长度依次 0→2、2→2、2→0，各轮内容衔接正确。这是同 origin 双页实际 helper 锁验证，不扩称两页 Vue storage-event DOM 验证。
- browser-requests.json 中 start 共 3 次，按 A、B、新 bo 顺序；deny 共 2 次。最终 operation collection 只有显式重新批准的新 bo，completed/passed，声明 14 项全部通过；源文件快照 29 份逐一重算 SHA 均一致。
- target-requests.json 中 source/broken/healthy 各四次。前两组属于新建来源运行，后四次 healthy 属于新 bo 目标验收；没有来源重新抓取。browser-storage.json 的回执均为空数组，session 为空，未出现 URL/fill/source 三种 sentinel。
- pageErrors=[]。控制台恰有 5 条 error，均是完全相同的受控 503 resource 文案，路径逐条匹配五次 controlled transport replies；没有其他 console warning/error。

### 四张截图独立目视

已实际用 view_image 逐张打开原始尺寸文件，没有只依赖 screenshot 文件存在或 DOM 文本：

| 截图 | 目视结论 | 布局数值 |
|---|---|---|
| resolution-A-desktop-light.png | 原确认、未知状态提示及重新复核后的批准区同时出现；批准框已勾选而 start 灰置，阻断含义清晰。原确认的标识和永久拒绝确认可读。 | 1440×1000；documentWidth=1440；组件 client/scroll=964/964 |
| resolution-B-mobile-dark.png | 未知状态警示和原确认行在 390 宽度内自然折行，选择框不超出列宽。首屏显示原确认上半段，未见横向溢出。 | 390×844；documentWidth=390；组件 client/scroll=296/296 |
| resolution-recovered-desktop-dark.png | 原确认已解除，显示永久拒绝证明核验完成和重新复核要求；没有自动出现新启动结果。 | 1440×1000；documentWidth=1440；组件 client/scroll=964/964 |
| resolution-fresh-mobile-light.png | 新 bo 的目标行显示“已完成 · 通过”，读取报告按钮清楚，文字和控件未重叠。 | 390×844；documentWidth=390；组件 client/scroll=296/296 |

手机 B 截图只覆盖组件的可滚动上部；“已提交本次拒绝请求，正在只读核对”的说明由完整 DOM 原件证明存在，此张首屏没有目视覆盖该下部说明。桌面 A 的拒绝区域也部分处于内部滚动边界；实际 deny 操作随后由 Playwright 自动滚动并执行。未将首屏截图误写成组件全部内容的视觉覆盖。

### 脚本修复与冻结边界

最终 unknown() 已改为核对原回执、等写操作落定、重新复核并勾选、确认 start disabled、检查 POST 计数不增和原回执不变。修复只针对新 smoke；产品两个前端 SHA 与初审一致。最终 smoke SHA 为 `3ea3f3a3f4479d8b06e53f87f036a4708c8003c23b927db08504ea594c883f34`；两个 fixture SHA 与初审一致。

独立读取 round4 的 before.json / after.json / source-snapshot.json：三者 600 项逐一完全相等，外部 guard 运行 exit 0；round4 快照 SHA 为 `244c25441fa4b477fbaa82ab789fd82a230f284d29de820802fee584bbcd4185`。这证明最终 smoke 当时受测范围未变。

协调者在该 smoke 后主动拷入 D3 runner 测试 driver 保活修复，随后另建 round5。复核过程中旧 round4 的 current check 因该明确变更失败，已向协调者报告；没有将它解释成无来源漂移。2026-10-17T15:19:04.804Z 已实际执行 round5 guard check，event=unchanged、600 项相同，round5 快照 SHA 为 `bed82f629fa6350292378e3d1d1ccfb4cda034186cc35bf9e541b0031b0fb65f`。历史 round4 smoke 与当前 round5 检查分开记录，见 `source-freeze-review.mjs` / `source-freeze-review.json`。

本轮独立审查未发现产品或 smoke 阻断，未修改源码，未主动运行其他 Browser。round5 的全 Core 和后续门禁由协调者运行，本报告不预报那些仍在运行的结果。