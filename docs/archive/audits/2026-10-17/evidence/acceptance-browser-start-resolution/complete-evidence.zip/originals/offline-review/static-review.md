# D4 独立验证线：离线结果与静态自核

日期：2026-10-17。源码冻结快照已核对：dca7dc736043a0cbf539fa14e36f5040ac18aeacc5e54445c460c388614d003f。收到冻结通知后未修改源码、测试、脚本；仅新增本 ignored 交接文档及摘要清单。

## 已运行证据

- [完整离线 stdout 原件](offline-tests.txt)：6 tests，6 pass，0 fail/skip/cancel；最终轮耗时 30569.4994 ms。
- [11 个归属文件、3 个只读复核文件及原件 SHA-256](source-review-sha256.json)。
- 原件 offline-tests.txt SHA-256：72abf44c8ce2a44d58e726909a1a38a2c7b9ad56a8849f6f92eaf575a6675ca0。
- 摘要清单 SHA-256：52ba97223f5d318d5145a2c16aeaad277c2a8019dbe90a17ec11e72f1659ef6e。
- node --check 新 smoke、被动 ingress 观察器和慢流工具通过；git diff --check 通过。

最终轮命令：

    node --test --test-concurrency=1 core/test/acceptance-browser-start-resolution-crash.test.mjs core/test/acceptance-browser-start-resolution-race.test.mjs core/test/acceptance-browser-start-resolution-engine.test.mjs

三个 kill case 分别在真实子进程观察到 empty、temporary、唯一 rejection 已提交时自发 SIGKILL；新 owner 打开同根后，partial 不补写/不采纳，完整 rejection 保持原字节并可重放。HTTP race 分别验证原 body 未 end 时 deny 先赢（同一原 socket 完成后 409、注入 runner 精确计数 0）以及原 admission pending 先赢（deny 不抢占，原 runner 只启动 1 次）。真实 engine case 使用同时保留完整旧 accepted/rejected 和独立坏 legacy/empty Browser 场景的数据根，不含 Browser。

首轮 pending case 曾撞到本次新建 HTTP harness 的 5 秒整体 fetch 期限；该 harness 已改成与真实 API smoke 相同的 30 秒，后续两轮 6/6。产品独立 60 秒期限、原 D3 smoke 的任何 timeout/过滤/断言均未修改。

## smoke 的静态负断言自核

以下已写入脚本并静态核对，尚未运行 Chromium，不能标为真实 Browser 通过。

| 位置 | 负断言与证据 |
| --- | --- |
| A 原始请求 | 原 UI 的六字段与转交 body 严格一致；只创建一个 Node HTTP request；prefix 写后保留原 request，只有 deny proof 成功才允许 finish tail |
| A 被动观察 | 仅精确 path/bo/trace 命中；只包裹实际 req.emit 事件；没有 data listener、read/resume 或重新发 body；不记录 token/cookie/正文，只记连接标识、字节数和 SHA |
| A deny 前后 | deny 完成前无 end 事件；结束后同 operation/trace、完整 body SHA/bytes、唯一连接与唯一 ingress request；原 UI start 和 deny 各只有一次 |
| A runner 证据范围 | 真 engine 中唯一 rejection、零 accepted operation、无新增 target navigation；精确 runner=0 由已通过的真实 service HTTP race 注入计数补充，不把网络计数独立冒充 runner hook |
| B 丢响应 | 原 start 明确未交付，真实 deny 经 route.fetch 提交并取得 rejected proof 后才注入 503；读取 proof 的传输在重启前暂时不可用，receipt 保持原值 |
| B 重启恢复 | about:blank 结束轮询；同真实 root、同 origin/端口、同 storage key、同 context；恢复窗口仅 GET、POST 总数不增加、原 start/deny 仍各一次；拒绝字节前后相同 |
| B 后续 | 恢复之后必须重新通过原生复核，以全新 bo 启动；不可用 a/b 的 bo，不能自动再发原 POST |
| 原生 Web Locks | 同 origin 两页导入实际零依赖 helper；外部 native holder 保持锁，query 实际观察两个 pending waiter 后才释放；save/save、resolve/save、resolve/resolve 各比较两页完整集合 |
| 其他 | 无 locks 可读禁写；来源请求不增加且原捕获树不变；storage/href 无全文哨兵；pageErrors=0；仅允许本脚本精确列出的受控 503 console error，数量不超过注入数；四组手机/桌面明暗布局不溢出 |

新入口是 acceptance:browser:resolution:smoke，root/core package scripts 和 CI 均追加独立接线，保留 D3 execute smoke。失败证据 glob 为 core/workspace/_runs/browser-resolution-console-smoke-*/**。

## root service/API/engine 接线只读复核

已静态读取 root 的 browser-execution-service.mjs、browser-execution-api.mjs、engine-server.mjs，未发现本轮阻断：

1. engine 在鉴权、owner 之后，仅对 POST 加完整合法 ap/bo 的精确 deny-start pathname 设置例外；它只让请求进入 service，没有直接授予写权限。
2. service 在任何 ready/scope/reserve 前检查已有完整决定并核对 project/fingerprint；未知决定仍先 ready，再 scope、reserve，并在发布 guard 重验；未 ready 不会写新拒绝。
3. GET resolution 不进入 ready/capability，不 reserve、不等 pending Promise；原 fact 直接 proof，absent 才读取当前项目存在性。
4. API 对新 action 的方法集合、16 KiB/fatal UTF-8/object-only、精确 query 和受控错误保留边界；普通错误码没有解除能力。

新 engine 专项对以下扩大旁路能直接报错：

| 错误扩大 | 将失败的真实 HTTP 断言 |
| --- | --- |
| 整体允许 acceptance 写入 | 普通 POST projects 必须 503/ACCEPTANCE_RECOVERY_BLOCKED |
| 允许所有 Browser 写入 | collection execute 与 report POST 必须仍由外层返回 recovery blocked，不能落到 service/router 的其他错误码 |
| 允许 deny 的其他方法 | PUT/DELETE 精确 deny-start 必须 recovery blocked |
| 放松后缀或 ID | trailing slash、deny-start-extra、坏 bo ID 必须 recovery blocked |
| 从 service 省略新拒绝 ready 门禁 | exact absent deny 必须 503，且全 Browser 树不得出现新目录或原件变化 |
| 把外层门禁保留为无例外 | 旧 accepted/rejected 的同确认 deny 必须 200 原 proof；原完整字节与 prepared 状态不变 |

真实 engine fixture 中旧 accepted 是不依赖当前 catalog 项目/来源的历史事实；当前 catalog 存在性并不作为旧事实 proof 的先决条件。新拒绝 ready 的完整当前项目/generation/共享槽边界同时由 root 的 service 专项负责。本 engine case 的主要职责是检测外层接线和拒绝门禁扩大。

## 交接边界

Browser 启动次数为 0；没有运行全 Core，没有 commit/push。后续由父协调者在冻结快照 guard 下串行运行新 smoke 和旧门禁。所有新 Browser 情景与 screenshots 的最终证据须以实际运行目录为准，本文件只给离线已运行结果及静态脚本复核结论。
