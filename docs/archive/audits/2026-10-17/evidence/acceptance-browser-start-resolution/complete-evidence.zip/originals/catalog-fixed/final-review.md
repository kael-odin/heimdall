# Catalog 最后栅栏修后专项核验

日期：2026-10-17。产品仅修正 accepted claim 后的外部完整 guard 时机及 legacy partial-read 错误合同。原 `acceptance-browser-execution-catalog.test.mjs` 和 `acceptance-browser-operation-decision.test.mjs` 均未修改。

结果：原 catalog 整文件 **9/9 通过**，原样 decision 专项 **16/16 通过**，均 exit 0、0 fail、0 skipped。两组依次执行；没有启动 Browser，也没有运行或代替主代理的最终完整 Core 与串行门禁。

| 组别 | UTC 开始 | UTC 结束 | 结果 |
| --- | --- | --- | --- |
| `original-catalog-file` | 2026-10-17T15:35:41.984Z | 2026-10-17T15:39:41.542Z | 9 tests / 9 pass / 0 fail / 0 skipped |
| `decision-original` | 2026-10-17T15:40:25.455Z | 2026-10-17T15:44:02.343Z | 16 tests / 16 pass / 0 fail / 0 skipped |

每组 before/after 与本目录动态冻结的 600 项源码完全一致，并已独立比较为与最终 round6 快照 `3fca1cbf4a61afd38fe8f1fda5cd0743d9049516aff8307b060d8e83fe40698f` 的 `files` 集合和每项 bytes/SHA 完全相同。本目录快照自身 SHA 因 capturedAt 不同而不同，不能混写为同一原始 JSON 文件。

`final-review.json` 汇总原始 summary、stdout 提取的统计、两组前后完整集合比较、与 round6 的集合比较和下列当前字节：

| 文件 | bytes | SHA-256 |
| --- | ---: | --- |
| `browser-operation-store.mjs` | 46174 | f1b3a61fc0e88838f987e46375f8311e7819e348c7484b94ef8a57e42166684a |
| 原 catalog 测试 | 12500 | 27211ad0edda4da76d401485a2986d5edb0606854c5e6d7b3df823717cbab223 |
| 原 decision 测试 | 22326 | 20d1d5b7c6d22c5b47bdf1f31beea28efce8095d1cd4ddca1cce7d70c15cf262 |

原 catalog 的最后栅栏测试在 `fences === 2` 才改变来源，修后通过其完整原断言：已复制 evidence 保留，dispatch/head 不存在，legacy read 返回不可用，原来源恢复且 catalog 原字节不变。新增 decision 的拒绝 claim/final 注入、容量复核、guard 改临时字节、rejection 缺席负条件和连续 D4 pass 不可比等原断言也全部保留通过。

修前失败、额外探针、store 前后原件与最小补丁保留在 sibling `d4-catalog-last-fence-review-20261017-e4287e05-b494-4d34-8e08-bf94f56dcdb4`；这些失败没有覆盖或删除。此前 store 16+12 的旧结果归开发证据，不能代替主代理当前 round6 最终门禁。
