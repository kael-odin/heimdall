# round7 最终发布计划只读审查

日期：2026-10-18（Asia/Hong_Kong）。仅静态读取prepare、publisher、independent verifier、冻结草稿和相关runner；没有运行prepare/publish/verify，没有改源码或既有原证据。本文件置于review根，避免最终原件子目录在归档前再被嵌套选择。

当前草稿有33组、33唯一key，实际只读比较未发现路径相同或祖先/后代重叠；12个required labels、12个finalGates、12个唯一gate label一致。首轮发现两处合同缺口，已即时发给协调者；协调者随后修正三份ignored工具，本代理已逐项回读确认，修后状态见文末。本轮最终图片与目视审查实际已经完成，首轮缺口不代表该事实有误。

## 已有合同成立的部分

- prepare只有completed.status=passed、completed包含精确12label集合且每个final summary均label匹配/exit0/signalNone/unchanged/同sourceFiles与baselineSHA后，才会写新readyToPublish=true计划；输出使用独占创建，不覆盖草稿或旧计划。当前冻结草稿仍ready=false。
- 六个外部runtime根仅从对应最终gate目录的stdout提取，要求所有outputDirectory落在唯一同一目录并位于_runs内；不会扫描“最近一次目录”或使用预检变量。resolution会被选入finalSmoke。`"preflight" not in relative`本身不能识别无preflight字样的UUID根，实际主要保护来自最终stdout绑定；publisher和verifier还独立要求选中的resolution summary在最终gate时间范围内、成功stdout精确记录同root、summary.outputDirectory相同，因此不能用当前预检root冒充该最终resolution。
- add_group对已被父组包含的根直接沿用父组，拒绝新增祖先组吞并旧组；publisher会进一步拒绝重复原件sourcePath与归档名，独立verifier再复核无重叠。original-console与console-cdp显式写到最终validation/runtime下，由final-gates父组递归纳入，不再添加重叠组。Forge临时数据自行清理，仅保留其门禁stdout/stderr等，不冒称保留了已删临时runtime。
- 新增整个round7-independent-review根可包括preflight与final的分离原件、目视记录、机器记录、补充proof绑定和本检查；最终4PNG另作直接可读副本。最终6runtime roots也递归纳入；Chromium profile明确排除且本机保留，不是无记录漏件。
- publisher要求最终12label及完成标记完整归档，逐项核对summary/stdout/stderr/before/after；当前动态源码集合与冻结快照逐字节匹配，归档后再重读全部原件。ZIP每项长度/SHA、CRC、源集合、直接副本均核验并写INDEX。
- independent verifier不导入publisher，working/staged分开读取；复核sealed plan、精确公有文件清单、ZIP条目、完整本机selected originals、源码集合与字节、12门禁、完成标记、finalSmoke精确checks及时间/root绑定；最后再次盘点原件。当前未以测试/发布实际运行来替代静态结论。

## 首轮发现的两项合同缺口

1. **最终视觉只按Markdown存在放行。** prepare仅`final-review.md.is_file()`，publisher/verifier没有读取最终`review-summary.json`、`visual-review.json`的完成状态或root绑定。因而从脚本逻辑上，缺少visual记录但存在空/旧Markdown也可跨过该条件；不能只靠这条assert宣称机器passed-awaiting-visual-review必然不能发布。本轮真实final-review与四图已完成，因此当前原件事实正确。建议prepare同时要求review-summary.status=passed、phase=final-browser-resolution-ui-only、screenshotsActuallyOpened=4、sourceDirectory=最终选root；visual-review.status=passed、usedPreflightImages=false，4项actuallyOpened及路径/字节/SHA与最终captures一致。publisher与独立verifier宜再以封存计划中明确审查路径复核同一组事实，不能只信ready标记。
2. **独立verifier没有要求直接副本集合等于sealed plan。** publisher实际会逐项写plan.readableCopies，且每份复制会对照归档原件；但verify只遍历index.readableCopies并检查已列项相等，没有比较其`file + sourcePath`集合与plan.readableCopies。因此若某个副本同时从public文件和INDEX的相应列表中漏掉，verify可能仍通过，无法独立保证计划要求的最终审查和4PNG直接可读副本全部存在。建议把sealed plan的副本集合与index副本映射回原sourcePath后的集合严格比较，并拒绝重复file或sourcePath映射歧义。

这两项是首轮版本的验证边界，没有运行反例或更改输入来证明当前发布发生了错误。下节保留首轮版本身份，文末单独记录修后回读，避免把修前静态结论冒充修后验证。

## 首轮审查版本

| 文件 | SHA-256 |
| --- | --- |
| prepare-round7-final-plan.py | `49994dc5e23d13b2e44c2be8d0a11729883f218f31533cd0c1908a884cd0ad16` |
| publish-d4.py | `0295452f58ba3b4c4406581179bcfa616e54deed4a4034e636691cf7e7a7f79e` |
| verify-d4.py | `ee695c5ccab04288d5b001bdfba0a8c036d9644becc98a30b644c7185fd9e0cd` |
| plan.round7.frozen.draft.json | `5c5f80b69c35b0c27adb9eb7531083550d239563af80804db15d4397229ad62f` |

本审查不提前认定仍在运行的后续门禁通过，不生成ready计划、公开ZIP或暂存核验结果，也不代替最终D4提交自身CI。

## 修后独立回读确认

协调者在首轮反馈后仅修改三份ignored发布工具，未触maintained源码。本代理重新读取全部prepare及publisher/verifier新增合同，确认两项缺口在当前发布链中均已补齐：

- prepare在设置ready前读取最终review-summary、visual-review和artifact-manifest，要求summary.status=passed、正确最终phase、同冻结SHA/sourceFiles，visual.status=passed、usedPreflightImages=false、截图数4、完整capture名称有序集合、每图actuallyOpened、绝对路径/字节/SHA均属于最终选定root。manifest本身SHA与review-summary一致，所有manifest条目重新读盘核验。
- 封存计划新增independentFinalReview的summary/visual/manifest/text四原件路径。publisher要求这些原件被归档、书面审查非空，并再次核验终态review、root、冻结SHA、manifest每项和实际四图。
- 独立verifier从ZIP读取四审查原件重复验证，不导入publisher、不仅相信ready标记；逐项核验manifest所列原件和visual图片都入包且字节/SHA一致。当前实际manifest为25份，包括四PNG及其四DOM。原机器等待目视记录仍可作为历史原件保留，但只有最终passed review-summary与visual完成事实才能满足发布合同。
- verifier新增plan.readableCopies与INDEX中副本映射回原sourcePath后的完整有序集合比较，且file名唯一；漏掉计划中的最终审查或任一PNG直接副本会失败。每一直接副本仍须与ZIP原件逐字节一致。

未发现修后新增阻断。此处是静态独立回读确认，没有执行prepare、publisher、package verifier或反例；三Python语法检查由协调者负责。12门禁最终结果由协调者自己的已完成原件判断，本文件不补造封包、working/staged核验或CI结果。

| 修后文件 | SHA-256 |
| --- | --- |
| prepare-round7-final-plan.py | `0cfba11707012abb941c8b57110a54565d6b0a3afac4a927e746a2701a92614f` |
| publish-d4.py | `1e4b047a3f1ec2fbac5c19fcce97219b56c94c479cb77b42461f79486b1d86f2` |
| verify-d4.py | `f4021a49e4e4810921c1bcfb3a9fdc64106ca1f4dfb529e75cf08aac56ebbb32` |

本文件完成后review根冻结，供协调者整体归档；未经新的明确协调，不再修改本review根内文件。
