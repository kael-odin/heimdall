import { readdirSync } from 'node:fs';
import assert from 'node:assert/strict';
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, realpathSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { createAcceptanceCatalogStore } from "file:///C:/Users/44548/.codex/worktrees/browser-start-resolution-d4/heimdall/core/src/acceptance/catalog.mjs";
import { acquireAcceptanceOwner } from "file:///C:/Users/44548/.codex/worktrees/browser-start-resolution-d4/heimdall/core/src/acceptance/owner.mjs";
import { createBrowserOperationStore } from "file:///C:/Users/44548/.codex/worktrees/browser-start-resolution-d4/heimdall/core/src/acceptance/browser-operation-store.mjs";
import { fixedBrowserRuntimeOf } from "file:///C:/Users/44548/.codex/worktrees/browser-start-resolution-d4/heimdall/core/src/acceptance/browser-fixed-contract.mjs";
import { facts } from "file:///C:/Users/44548/.codex/worktrees/browser-start-resolution-d4/heimdall/core/scripts/fixtures/managed-execution.mjs";

const SAMPLE = "C:\\Users\\44548\\.codex\\worktrees\\browser-start-resolution-d4\\heimdall\\core\\test\\fixtures\\acceptance-browser-source\\matrix";
const cas = f => { const value = f.catalog.read(); return { expectedGenerationId: value.generationId, expectedRevision: value.revision }; };
const copy = value => JSON.parse(JSON.stringify(value));
async function fixture(t, side = 'baseline') {
  const root = realpathSync(mkdtempSync(join(tmpdir(), 'heimdall-browser-execution-catalog-')));
  const manifest = JSON.parse(readFileSync(join(SAMPLE, 'manifest.json'))), sourceDir = join(root, manifest.runId);
  cpSync(SAMPLE, sourceDir, { recursive: true });
  const owner = acquireAcceptanceOwner({ root }), catalog = createAcceptanceCatalogStore({ root, owner }), operations = createBrowserOperationStore({ owner });
  t.after(() => { owner.release(); rmSync(root, { recursive: true, force: true }); });
  const f = { root, sourceDir, owner, catalog, operations }; await catalog.initialize({ createSchemaVersion: 4 });
  f.project = (await catalog.createProject({ ...cas(f), name: 'Single-operation Browser project' })).project;
  f.sourceRelease = (await catalog.createRelease(f.project.id, { ...cas(f), label: 'Captured source', targetUrl: manifest.plan[side + 'Url'] })).release;
  f.binding = (await catalog.bindBrowserSource(f.project.id, { ...cas(f), runId: manifest.runId, sourceSide: side, releaseId: f.sourceRelease.id })).binding;
  const preview = catalog.previewBrowserBaselineCandidate(f.project.id, f.binding.id);
  f.candidate = (await catalog.createBrowserBaselineCandidate(f.project.id, { ...cas(f), sourceBindingId: f.binding.id, contentDigest: preview.contentDigest })).candidate;
  f.targetRelease = (await catalog.createRelease(f.project.id, { ...cas(f), label: 'New target', targetUrl: 'https://catalog-target.test/application?version=two' })).release;
  f.request = patch => ({ ...cas(f), operationId: 'bo-' + randomUUID(), candidateId: f.candidate.id,
    contentDigest: f.candidate.contentDigest, targetReleaseId: f.targetRelease.id, ...patch });
  f.execute = (request = f.request(), options = { assertAdmission: () => true,
    publish: (context, fence) => operations.publish(context, fence) }, projectId = f.project.id) => catalog.withBrowserExecutionCandidate(projectId, request, options);
  return f;
}

const cleanups = [], f = await fixture({ after(fn) { cleanups.push(fn); } });
let changedFile, originalBytes;
const events = [];
try {
  const input = f.request(), sourceBefore = facts(f.sourceDir), catalogBefore = readFileSync(join(f.root, 'catalog.json'));
  const operation = join(f.root, 'browser-operations', 'v1', input.operationId);
  let fences = 0, injected = false;
  await assert.rejects(f.execute(input, { assertAdmission: () => true, publish(context, fence) {
    changedFile = context.contract.sourceEvidence[0].sourceFile;
    originalBytes = readFileSync(join(f.sourceDir, changedFile));
    return f.operations.publish(context, { assertCurrent() {
      fences++;
      const evidence = join(operation, 'evidence');
      const entries = existsSync(operation) ? readdirSync(operation).sort() : [];
      const staged = context.contract.sourceEvidence.filter(entry => existsSync(join(evidence, entry.file))).length;
      const copiedExactly = staged === context.contract.sourceEvidence.length && context.contract.sourceEvidence.every(entry =>
        readFileSync(join(evidence, entry.file)).equals(Map.prototype.get.call(context.sourceFiles, entry.sourceFile)));
      const dispatchTemporary = entries.filter(name => /^dispatch\.json\.tmp\./.test(name));
      events.push({ fence: fences, operationExists: existsSync(operation), evidenceExists: existsSync(evidence), entries,
        staged, expectedCopies: context.sourceFiles.size, copiedExactly, dispatchTemporary: dispatchTemporary.length });
      if (copiedExactly && dispatchTemporary.length === 1 && !injected) {
        writeFileSync(join(f.sourceDir, changedFile), Buffer.concat([originalBytes, Buffer.from('true last dispatch fence change')]));
        injected = true;
      }
      fence.assertCurrent();
    } });
  } }), { code: 'BASELINE_CHANGED' });
  assert.equal(injected, true);
  assert.equal(fences, 3);
  writeFileSync(join(f.sourceDir, changedFile), originalBytes); originalBytes = undefined;
  const entries = readdirSync(operation).sort(), evidenceEntries = readdirSync(join(operation, 'evidence')).sort();
  assert.equal(existsSync(join(operation, 'evidence')), true);
  assert.equal(evidenceEntries.length, 24);
  assert.equal(existsSync(join(operation, 'dispatch.json')), false);
  assert.equal(existsSync(join(operation, 'head.json')), false);
  assert.deepEqual(entries, ['evidence']);
  assert.throws(() => f.operations.read(input.operationId), { code: 'BROWSER_OPERATION_UNAVAILABLE' });
  assert.deepEqual(facts(f.sourceDir), sourceBefore);
  assert.deepEqual(readFileSync(join(f.root, 'catalog.json')), catalogBefore);
  console.log(JSON.stringify({ passed: true, offlineProbe: true, trigger: 'all 24 source copies exact plus one dispatch temporary',
    rejectedCode: 'BASELINE_CHANGED', fences, events, retainedEvidenceFiles: evidenceEntries.length,
    retainedOperationEntries: entries, originalSourceRestored: true, catalogUnchanged: true, dispatchMissing: true,
    headMissing: true, incompleteOperationUnreadable: true }, null, 2));
} finally {
  if (originalBytes) writeFileSync(join(f.sourceDir, changedFile), originalBytes);
  for (const cleanup of cleanups.reverse()) cleanup();
}
