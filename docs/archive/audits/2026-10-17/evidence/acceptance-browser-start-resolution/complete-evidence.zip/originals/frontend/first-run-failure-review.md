# D4 前端首次 Core-backed 复验失败记录

命令：`node --test core/test/acceptance-browser-execution-console.test.mjs core/test/acceptance-browser-start-resolution-console.test.mjs`。

该次进程终态为 exit 1，Node 输出：30 tests、27 pass、3 fail、0 skipped。三个 fail 包括父测试的聚合失败；独立断言失败两项如下。完整分段 stdout/stderr 保留在本任务工具会话 `session_id=4528` 的执行记录中；本文件为原终端失败片段整理，不冒称整段原始 stdout。

```text
test at core\test\acceptance-browser-execution-console.test.mjs:140:11
✖ registered results bind the report, dispatch, candidate, target and explicit previous operation
  AssertionError [ERR_ASSERTION]: Expected values to be strictly equal:
  + actual - expected
  + 'incomparable'
  - 'verified_passed'

test at core\test\acceptance-browser-execution-console.test.mjs:150:11
✖ ledger rebuilds verified passes and reopened issues and rejects fabricated closure
  AssertionError [ERR_ASSERTION]: Expected values to be strictly equal:
  + actual - expected
  + 'unverified'
  - 'verified_passed'
```

首跑未记录八个 verifier 源文件的运行前后 SHA-256，不能据此确认是并行源码变化引起。前端实现线没有修改或放宽上述原有 `verified_passed` / `reopened` 断言。等待协调者冻结产品源码后，以相同断言记录前后源码摘要并复验；新结果单独保存，不覆盖该失败记录。
