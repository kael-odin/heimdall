# D4 前端实现与离线验证

日期：2026-10-17，Asia/Hong_Kong。前端实现线独占修改 helper、Vue 与三个 console 测试文件；未修改 Store/schema/service/API/engine，未启动 Browser、Chromium 或完整 Core，未 commit/push，也未触碰 D3 冻结证据。

## 已实现

- `console/src/acceptance-browser-execution.js` 新增异步 `browserStartResolution(raw, { projectId, request, crypto })`。严格校验 recorded / rejected / unresolved union；核对 project、原六字段和 domain fingerprint；rejected 独立重算 canonical 原件加 LF 的 SHA-256。Web Crypto 等待期间使用惰性数据快照，外部对象变动不能替换正在核验的证明。
- 回执 API 保持 `read()` 同步，新增 `canWrite`，`save()` 和 `resolveExact()` 必须 await。锁注入精确为 `locks.request(key, { mode: 'exclusive' }, callback)`；key 即 `heimdall:browser-operations:v1:${origin}:${projectId}`。所有集合写在锁内重新读取、严格比较六字段、写入并完整回读；干净集合的精确缺席可幂等成功，损坏集合不能伪装缺席。旧裸 `resolve(operationId)` 已移除。
- 无 Web Locks 时保留只读查询与完整 proof 核验，禁止保存、解除、启动和显式拒绝写操作。Vue 不调用必失败的解除入口，也不会把无锁误标为存储写故障。
- Vue 的全部未解除回执都继续阻断新启动，即使列表含同 bo。列表、普通 4xx 和成功 start 的旧 view 都不能直接清回执；仅专用 GET resolution 的完整证明可以触发精确解除。
- start 在等待安全保存前捕获 project/client/六字段/epoch；保存成功后上下文失效则不发送旧请求。旧 proof 与锁完成只使用原 client，不能清除另一条同 bo 确认或回填新项目状态。各写操作使用独立 token，迟到 finally 不改变新的 writing 状态。
- 显式永久拒绝要求核对原六字段并勾选确认。一次请求后仅 GET 核对，不自动重发拒绝、不自动新建 bo、不自动重发 start。POST 沿用独立 60 秒期限，覆盖 fetch 和 response body；读 epoch 重置不会重发或取消它。
- 当前页面按 origin/project 锁存保存或完整回读失败。后续存储读到空数组不能把已知写故障重新解释为安全解除；持久化仍只有原六字段。

## 固定契约交叉核对

只读核对后端 schema、store inspect/publish 和 service proof，确认与 helper 使用同一字段集、domain `heimdall-browser-operation-request`、version=1 和 canonical 排序。

实际调用后端 `browserOperationRequestFingerprint` / `browserOperationRejectionBytes`，用其输出的 rejected proof 再交给前端校验，revision 0、12、9007199254740991 全部通过。原件长度分别为 761、762、776 字节，fingerprint 与 SHA-256 均与正式 fixed fixture 完全一致。Store inspect 还要求实际 `rejection.json` 字节恰为 canonical+LF；前端核验同一序列。

## 测试与原件

| 检查 | 结果 | 原件 |
|---|---|---|
| 最终纯 helper + 实际 Vue refs/watchers 状态测试 | 20/20，0 skip | `final-pure-tests.txt` |
| 最终原 Core-backed console 回归 + 上述两个新专项 | 39/39，0 skip | `final-tests.txt` |
| 最终 console production build | pass；保留已有大 chunk 提示 | `final-console-build.txt` |
| 最终受测文件运行前后 SHA-256 | 14 文件完全一致，其中包含全部 8 verifier | `final-before-sha256.json`、`final-after-sha256.json`、`final-summary.json` |
| 修改文件 diff 空白检查与新增测试 JS syntax | pass | 任务工具记录 |

最终 39 项运行时段：`2026-10-17T14:44:02.3171090Z` 至 `2026-10-17T14:46:08.7110618Z`，香港时间 `2026-10-17 22:44:02.317–22:46:08.711`。`testExitCode=0`、`identicalSource=true`、`differences=[]`。

Vue 状态测试执行组件保存的 `<script setup>` 与真实 Vue `ref/computed/watch`，通过注入 transport、storage 和真正排队的串行锁调度器验证状态；不伪造 DOM 或声称已渲染。覆盖列表同 bo 仍阻断、旧 view/普通 409 不解除、save 等锁时切项目不 POST、旧 proof 等锁时项目 ABA 与同 bo 原确认变化、deny 超时只一次 POST 后 GET 恢复、无锁、存储拒读、写及全量回读失败锁存。

首次 Core-backed 运行曾出现两个 relation 断言失败，原断言保持不变，失败与解释边界保留在 `first-run-failure-review.md`。首跑未记录前后 SHA，因此不能确认失败原因。后续冻结复验 38/38 及最终补充后的 39/39 均单独保留，未覆盖旧失败。

## Browser 交接

helper 保持零 import，导出签名已锁定，smoke 可在同 origin 两页通过 data module 导入并测试原生 `navigator.locks`。

- `browser-execution-unknown`：所有未解除回执。
- `li[data-browser-receipt="bo-…"]`：原确认行。
- `browser-execution-deny-confirm[data-operation-id="bo-…"]`：显式勾选。
- `browser-execution-deny[data-operation-id="bo-…"]`：单次永久拒绝。
- `browser-execution-deny-pending`：随后只读核对说明。
- `browser-execution-readonly`：无 Web Locks 说明。
- 既有 `browser-execution-refresh`：并行读列表与专用 resolution，不使用列表作清理证明。

真实同 origin 双页锁、真实慢 body / 拒绝响应丢失 / 同端口正常重启、桌面手机明暗渲染和截图由 Browser smoke 实现线与协调者串行验证，本报告不代替这些未运行的证据。
