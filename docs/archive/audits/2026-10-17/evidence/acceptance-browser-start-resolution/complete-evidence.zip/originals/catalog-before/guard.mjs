import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { createWriteStream, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const OUT = dirname(fileURLToPath(import.meta.url)), ROOT = resolve(OUT, '../../../..');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const write = (file, value) => writeFileSync(file, JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
function snapshot() {
  const result = spawnSync('git', ['ls-files', '-z', '--cached', '--others', '--exclude-standard'], { cwd: ROOT, encoding: 'utf8' });
  assert.equal(result.status, 0, result.stderr);
  const names = [...new Set(result.stdout.split('\0').filter(Boolean))].filter(file =>
    /^(?:core\/(?:src|scripts|test)\/|console\/(?:src|public)\/|\.github\/workflows\/|config\/)/.test(file)
    || /^(?:(?:core|console)\/)?(?:package\.json|pnpm-lock\.yaml|vite\.config\.[cm]?[jt]s|eslint\.config\.[cm]?[jt]s|\.gitattributes|\.npmrc)$/.test(file)).sort();
  return names.map(file => { const bytes = readFileSync(join(ROOT, file)); return { file, bytes: bytes.length, sha256: sha(bytes) }; });
}
const [mode, label, command, ...args] = process.argv.slice(2), baselinePath = join(OUT, 'source-snapshot.json');
if (mode === 'freeze') {
  const files = snapshot(); write(baselinePath, { schemaVersion: 1, capturedAt: new Date().toISOString(), root: ROOT, files });
  console.log(JSON.stringify({ event: 'frozen', files: files.length, sha256: sha(readFileSync(baselinePath)), path: baselinePath }));
} else if (mode === 'check') {
  const files = snapshot(), baseline = JSON.parse(readFileSync(baselinePath, 'utf8'));
  assert.deepEqual(files, baseline.files); console.log(JSON.stringify({ event: 'unchanged', files: files.length }));
} else if (mode === 'run') {
  assert.match(label ?? '', /^[a-z0-9-]+$/); assert.ok(command);
  const directory = join(OUT, label); mkdirSync(directory);
  const baseline = JSON.parse(readFileSync(baselinePath, 'utf8')), before = snapshot(); write(join(directory, 'before.json'), before);
  assert.deepEqual(before, baseline.files, 'Source changed before gate ' + label);
  const executable = command === 'node' ? process.execPath : command, startedAt = new Date().toISOString();
  const stdout = createWriteStream(join(directory, 'stdout.log'), { flags: 'wx' });
  const stderr = createWriteStream(join(directory, 'stderr.log'), { flags: 'wx' });
  const child = spawn(executable, args, { cwd: ROOT, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
  child.stdout.pipe(stdout); child.stderr.pipe(stderr);
  const result = await new Promise(done => { let error; child.once('error', cause => { error = String(cause); });
    child.once('close', (exitCode, signal) => done({ exitCode, signal, ...(error ? { error } : {}) })); });
  await Promise.all([new Promise(done => stdout.end(done)), new Promise(done => stderr.end(done))]);
  const after = snapshot(); write(join(directory, 'after.json'), after);
  const unchanged = JSON.stringify(after) === JSON.stringify(baseline.files);
  const summary = { label, executable, args, cwd: ROOT, startedAt, endedAt: new Date().toISOString(), ...result,
    unchanged, sourceFiles: after.length, baselineSha256: sha(readFileSync(baselinePath)) };
  write(join(directory, 'summary.json'), summary); console.log(JSON.stringify(summary));
  assert.equal(unchanged, true, 'Source changed during gate ' + label); process.exitCode = result.exitCode ?? 1;
} else throw Error('Use freeze, check or run.');
