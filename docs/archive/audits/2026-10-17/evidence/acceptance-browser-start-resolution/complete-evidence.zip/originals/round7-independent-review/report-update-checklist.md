# round7 报告更新清单

2026-10-18（Asia/Hong_Kong）。只读审查，不改冻结源码。下述内容是最终报告的更新依据与待办，**预检不等于最终门禁**。

1. 将最终冻结改为 round7，快照SHA `f700d54a3bb10a55748818d68b6d33fe43724f8485ec72063e0a35d253c078d8`、600项。已经完成的预检guard只写自己的preflight label、UTC和exit；全Core与串行后续阶段未完成时继续标待完成。
2. 补上实际发现的双Vue同时start缺陷及最小修复：通用save锁内保留集合不等于新启动准入；专用claimForStart锁内仅空集合写唯一回执并完整回读，非空false不写。Vue false正常待核对、不fault、不POST、消耗复核。保存前后原件在 `../d4-cross-page-start-fix-20261017/`。
3. 前端纯专项新结果为25/25、0fail/skip/cancel，保留旧20/20、39/39为历史重叠结果，不能相加。新增真实Vue状态双start为1POST/1receipt；等待时已有回执为0新POST无fault；空值与同ID改字段坏回读持续锁存。Browser/Core未参与该纯专项。
4. 原生helper双页交错由3组变4组，新增claim-start-claim-start；实际queued held1/pending2/两个clientId，results[true,false]、唯一原a回执。原save/save等3组仍保留。不要把4组交错改写成4个额外顶层checks：新smoke仍9/9。
5. 保留round6已完成原件及停止原因：其smoke9/9和全Core历史通过不代表没有双start缺陷；managed-execution-ui被停止时没有完成summary，不记通过。round6 fresh手机图当时running/blocked而APIcomplete的差异照实保留，不能用预检新图覆盖旧原件事实。
6. 本次预检已核实fresh-rendered-state与API/DOM同bo，completed/passed14/14、report按钮1、stop按钮0，且四图已实际打开。最终browser-resolution-ui完成后必须使用其新root、新bo、trace/body/拒绝SHA、fresh-rendered-state和四张新图重新复核；不能把预检root当最终root。
7. 保留四图可见范围：手机dark仅原确认上半部，下部说明由DOM覆盖；桌面light内部滚动未覆盖全部动作；recovered图下方旧broken比较仍显示缺陷，不能混作fresh结果。采样横溢只代表当次桌面/手机视口，不宣称全量无障碍。
8. 保留精确证据边界：A为UI原body经单一NodeHTTP relay分段，不是Chromiumsocket；双页真实helper原生锁与纯Vue状态各自界定；重启可能SIGKILL不单独证明优雅退出；5条受控503保留逐项匹配。来源29文件SHA、请求各4、回执空集合和sentinel结果都按最终root重算。
9. 原catalog末栅栏/partial旧查询投影的修前失败、定位、修后9/9继续保留，不重新写为未定位，也不放宽旧测试。D4 lineage/verifier变化继续保守incomparable/unverified，不能靠连续新pass自动升级旧D3first-BUG。
10. 全Core完成后按真正summary+stdout记录total/pass/fail/cancel/skip、实际UTC、exit、12项或实际skip原因、before/after等。其余11组逐项各记command/exit/SHA及原件，重叠测试不累加。
11. 最终发布仍需精确D4commit、自身LinuxCI、证据包/INDEX/文件数/ZIP字节与SHA、暂存字节同受测快照。D3或hotfix自身CI不能替代D4自身CI；本代理未刷新CI，不补造结果。
