# round7 最终独立复核入口已准备

最终 `browser-resolution-ui/summary.json` 目前尚不存在。只准备入口，没有运行 Browser/Core，没有改冻结源码，没有循环轮询。

等待协调者确认该阶段完成后，运行 `node core/workspace/_runs/d4-round7-independent-review-20261018/verify-final-when-ready.mjs`。入口仅在最终外层 summary 为正确 label、exit0、unchanged true 后读取 stdout 的唯一 passed 输出记录；拒绝使用 preflight root。没有完成 summary 时仅返回 waiting，不产生通过记录。

入口读取最终 before/after/snapshot，并重算当前600文件字节与SHA，要求冻结SHA固定为 `f700d54a3bb10a55748818d68b6d33fe43724f8485ec72063e0a35d253c078d8`；随后执行原件只读校验脚本（纯Node，无HTTP/Browser/Core）、保存原始输出和命令元数据、重算25份原件manifest。

机器校验覆盖A原UIbody经单一HTTP relay的唯一ingress、A/B实盘拒绝canonical+LF及完整原字段、同origin/key重启只GET、4组原生锁集合与claim[true,false]、fresh同boAPI与DOM终态、请求计数、错误逐项对应、布局/PNG尺寸、storage/sentinel和29份来源SHA。预检与最终目录完全分开。

机器通过后状态仍为 `machine-passed-awaiting-visual-review`。必须实际打开最终新root的四张PNG，逐张核对可见范围与fresh终态，再保存visual-review与final-review；不能用预检图片代替最终图片。此处没有提前声称最终通过。
