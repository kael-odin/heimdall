import assert from 'node:assert/strict';
import * as fs from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve, join } from 'node:path';
assert(process.argv[2], 'Pass the completed new smoke directory.');
const root = resolve(process.argv[2]);
const out = resolve('core/workspace/_runs/d4-round6-independent-review-20261017');
const read = name => JSON.parse(fs.readFileSync(join(root, name), 'utf8'));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const canonical = value => JSON.stringify(value === null || typeof value !== 'object' ? value : Array.isArray(value) ? value.map(item => JSON.parse(canonical(item))) : Object.fromEntries(Object.keys(value).sort().map(key => [key, JSON.parse(canonical(value[key]))])));
const summary = read('summary.json'), checks = read('checks.json'), a = read('A-original-request.json'), b = read('B-restart-proof.json');
const locks = read('native-lock-interleavings.json'), errors = read('browser-errors.json'), controlled = read('controlled-transport-replies.json');
const layouts = read('layouts.json'), requests = read('browser-requests.json'), fresh = read('fresh-after-resolution.json'), collection = read('final-operation-collection.json');
assert.equal(summary.status, 'passed'); assert.equal(summary.checks, 9); assert.equal(Object.keys(checks).length, 9); assert(Object.values(checks).every(value => value === true));
const rawRequest = Buffer.from(JSON.stringify(a.request));
assert.equal(rawRequest.length, a.transport.bytes); assert.equal(sha(rawRequest), a.transport.bodySha256);
const actualIngress = fs.readFileSync(join(root, 'engine-ingress.jsonl'), 'utf8').trim().split('\n').map(JSON.parse);
assert.deepEqual(a.ingress, actualIngress); assert.equal(actualIngress.filter(item => item.event === 'request').length, 1); assert.equal(new Set(actualIngress.map(item => item.connectionId)).size, 1);
assert.equal(actualIngress.find(item => item.event === 'data').bytes, a.transport.splitAt);
const ended = actualIngress.find(item => item.event === 'end'); assert(ended); assert.equal(ended.bytes, a.transport.bytes); assert.equal(ended.bodySha256, a.transport.bodySha256); assert.equal(ended.operationId, a.request.operationId); assert.equal(ended.traceId, a.transport.traceId);
assert.equal(a.transport.events.filter(item => item.event === 'tail-released').length, 1); assert.equal(a.transport.events.find(item => item.event === 'response').status, 409); assert.equal(a.reply.code, 'BROWSER_START_REJECTED');
const rejectionFacts = [];
for (const item of [a, b]) {
  const operationId = item.request.operationId;
  const folder = join(root, 'runtime/acceptance/browser-operations/v1', operationId);
  assert.deepEqual(fs.readdirSync(folder).sort(), ['rejection.json']);
  const bytes = fs.readFileSync(join(folder, 'rejection.json'));
  assert.equal(bytes.toString('utf8'), canonical(JSON.parse(bytes)) + '\n');
  assert.equal(bytes.length, item.decision.bytes); assert.equal(sha(bytes), item.decision.sha256); assert.deepEqual(JSON.parse(bytes), item.decision.rejection);
  const proof = item.proof ?? item.proofAfter; assert.equal(proof.outcome, 'rejected'); assert.equal(sha(bytes), proof.rejectionSha256); assert.deepEqual(proof.rejection.request, item.request);
  rejectionFacts.push({ operationId, bytes: bytes.length, sha256: sha(bytes) });
}
assert.equal(b.originBefore, b.originAfter); assert.equal(b.storageKeyBefore, b.storageKeyAfter); assert.equal(b.originalStartDelivered, false); assert.equal(b.lostDenyCount, 1); assert.deepEqual(b.receiptBefore, [b.request]); assert.deepEqual(b.receiptAfter, []); assert(b.recoveryRequests.length >= 1); assert(b.recoveryRequests.every(item => item.method === 'GET')); assert.deepEqual(b.committedProof.rejection, b.proofAfter.rejection); assert.equal(b.committedProof.rejectionSha256, b.proofAfter.rejectionSha256);
assert.deepEqual(locks.map(item => item.name), ['save-save', 'resolve-save', 'resolve-resolve']);
for (const item of locks) {
  assert.equal(item.queued.held.length, 1); assert.equal(item.queued.pending.length, 2); assert.equal(new Set(item.queued.pending.map(value => value.clientId)).size, 2);
  assert([...item.queued.held, ...item.queued.pending].every(value => value.mode === 'exclusive' && value.name === item.key));
}
assert.equal(locks[0].after.length, 2); assert.deepEqual(locks[1].before, locks[0].after); assert.equal(locks[1].after.length, 2); assert.deepEqual(locks[1].after[0], locks[0].after[1]); assert.deepEqual(locks[2].before, locks[1].after); assert.deepEqual(locks[2].after, []);
const starts = requests.filter(item => item.method === 'POST' && item.path.endsWith('/browser-executions'));
const denials = requests.filter(item => item.method === 'POST' && item.path.endsWith('/deny-start'));
assert.equal(starts.length, 3); assert.equal(denials.length, 2); assert.deepEqual(starts.map(item => item.body.operationId), [a.request.operationId, b.request.operationId, fresh.request.operationId]);
assert.equal(fresh.operation.state, 'completed'); assert.equal(fresh.operation.gate, 'passed'); assert.equal(fresh.operation.summary.total, 14); assert.equal(fresh.operation.summary.passed, 14); assert.equal(fresh.proof.outcome, 'recorded'); assert.deepEqual(fresh.proof.request, fresh.request); assert.equal(collection.operations.length, 1); assert.equal(collection.operations[0].operationId, fresh.request.operationId);
assert.deepEqual(errors.pageErrors, []); assert(controlled.length >= 4); assert(errors.consoleMessages.length <= controlled.length);
for (const message of errors.consoleMessages) {
  assert.equal(message.type, 'error'); assert.equal(message.text, 'Failed to load resource: the server responded with a status of 503 (Service Unavailable)');
  assert(controlled.some(item => item.status === 503 && item.path === new URL(message.location.url).pathname));
}
assert.equal(layouts.length, 4);
for (const item of layouts) { assert.equal(item.documentWidth, item.width); assert.equal(item.scrollWidth, item.clientWidth); assert(item.clientWidth > 0); }
assert.equal(summary.captures.length, 4);
for (const name of summary.captures) { const png = fs.readFileSync(join(root, name)); assert(png.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]))); const layout = layouts.find(item => item.name + '.png' === name); assert(layout); assert.equal(png.readUInt32BE(16), layout.width); assert.equal(png.readUInt32BE(20), layout.height); }
const storage = read('browser-storage.json'); assert(!/d4-(url|fill|source)-memory-sentinel/.test(JSON.stringify(storage))); assert.deepEqual(storage.session, {});
const targetRequests = read('target-requests.json'); const targetCounts = Object.fromEntries(['/source', '/broken', '/healthy'].map(path => [path, targetRequests.filter(item => item.path === path).length])); assert.deepEqual(targetCounts, { '/source': 4, '/broken': 4, '/healthy': 4 });
const source = read('source-and-candidate.json').source, digests = read('source-file-digests.json');
for (const [name, fact] of Object.entries(digests)) { const bytes = fs.readFileSync(join(root, 'runtime/acceptance', source.runId, name)); assert.equal(bytes.length, fact.bytes); assert.equal(sha(bytes), fact.sha256); }
const result = { status: 'passed', verifiedAt: new Date().toISOString(), sourceDirectory: root, summaryStatus: summary.status, checks: 9, originalBody: { bytes: rawRequest.length, prefix: a.transport.splitAt, sha256: sha(rawRequest), ingressRequests: 1, connections: 1 }, rejections: rejectionFacts, restart: { origin: b.originAfter, sameStorageKey: true, recoveryGetRequests: b.recoveryRequests.length, lostDenyCount: b.lostDenyCount }, locks: locks.map(item => ({ name: item.name, held: item.queued.held.length, pending: item.queued.pending.length, pendingClientIds: new Set(item.queued.pending.map(value => value.clientId)).size, before: item.before.length, after: item.after.length })), browserStartRequests: starts.length, browserDenyRequests: denials.length, pageErrors: 0, expectedControlled503Messages: errors.consoleMessages.length, layouts: layouts.map(item => ({ name: item.name, viewport: [item.width, item.height], documentWidth: item.documentWidth, componentClientWidth: item.clientWidth, componentScrollWidth: item.scrollWidth })), originalSourceFilesVerified: Object.keys(digests).length, targetRequests: targetCounts, freshDeclaredChecks: [fresh.operation.summary.passed, fresh.operation.summary.total] };
fs.writeFileSync(join(out, 'independent-evidence-check.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(result, null, 2));