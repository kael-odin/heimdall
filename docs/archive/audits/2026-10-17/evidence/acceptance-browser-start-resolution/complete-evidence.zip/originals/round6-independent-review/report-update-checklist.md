# D4 round6 独立审查：报告更新清单

状态时间：2026-10-17T15:45:43.0496322Z（香港 23:45:43）。本次只读取现有源码、冻结快照和已落盘原件；未改源码，未运行 Browser/Core。

## 当前可确认的范围

- round6 已冻结 600 项，快照 SHA-256 `3fca1cbf4a61afd38fe8f1fda5cd0743d9049516aff8307b060d8e83fe40698f`；本次实际执行 guard check，返回 unchanged/600。
- 读取状态时 round6 `core-full/summary.json` 和 `browser-resolution-ui/summary.json` 均尚不存在。只能记为运行中/未完成，不能读取进行中的 stdout 拼成最终总数或预报通过。
- 原 catalog 整文件修后已完成 9 tests/9 pass/0 fail/0 skip/0 cancel，exit 0。该隔离组 before/after 保持 600 项不变；其 source-snapshot 的元数据 SHA `9035fba11f94b34b932f8637e4c253984624f2ead6b8bd6e4e8120cc5fade332` 与 round6 不同，但本次逐项比较 files 数组完全一致，没有源码差异。
- 当前 store 实际 SHA 为 `f1b3a61fc0e88838f987e46375f8311e7819e348c7484b94ef8a57e42166684a`。完整状态值见 `initial-state.json`。

## 审计草稿应更新的位置

1. 首段与“尚未解决的全局回归”：不能继续把所有因果写成猜测。现有独立 diagnosis 已确认两个兼容回归，且原 catalog 文件 9/9 修后通过；改为“已定位并完成专项修复，全量与新 Browser 回归等待 round6”。保留 round5 原始失败及被协调者终止的状态，不把 round5 写成通过。
2. 修复表补两行：accepted claim 后重复执行完整外部 guard，使第二次来源检查提前至 evidence mkdir 前；以及旧 read(partial) 将 DECISION_INCOMPLETE 改投影为 INTEGRITY_FAILED，违反旧 UNAVAILABLE 契约。前者只在 claim 后用 currentClaim，保留复制前与真正 dispatch 末栅栏；后者只在 readInternal 恢复旧投影，inspectDecision 和批次预检继续严格。原测试未放宽。
3. 证据表保留修前原单项 1/0/1 与 true-last-fence probe exit 1。探针实际到第三次外部 guard，24 项 evidence 保留，dispatch/head 不存在，但旧 partial 错误投影断言失败，不能写成探针通过。修后原 catalog 整文件 9/9 单独列出。
4. 待 round6 全 Core summary 完成后，填入实际 total/pass/fail/skipped/cancel、exit、UTC、skip 原因及 before/after；若失败，则保留失败并停止预报后续门禁。
5. 待 round6 browser-resolution-ui 完成，使用新目录和新 bo/origin/trace/body SHA/拒绝 SHA/四张截图/控制台记录更新最终 UI 段。旧 round4 9/9 留为历史通过，不用旧原件冒充新修后 UI 验证。
6. 必须保留 HTTP relay、双页实际 helper 和进程重启的精确覆盖边界。新四图也需实际打开，不能沿用旧截图目视结论；读取完整 DOM 与首屏可见范围分开说明。
7. 更新 final gate 表为 round6 或之后的实际最终冻结；旧 round4、round5 专项与所有失败原件继续保留。11 组门禁逐项填写自己的 command/exit/before/after，不累加重叠专项数字。
8. D3 hotfix 自身 CI、D4 最终提交自身 CI、发布包、INDEX、ZIP 大小与 SHA 仍由协调者按精确原件合成。本审查未联网刷新 CI，不补造结果。

## 已读取的 catalog 原件

- `../d4-catalog-last-fence-review-20261017-e4287e05-b494-4d34-8e08-bf94f56dcdb4/diagnosis.md`
- 同目录 `original-single/summary.json`：exit 1、600 项前后一致、round5 快照。
- 同目录 `true-last-fence-probe/summary.json`：exit 1、600 项前后一致、round5 快照。
- `../d4-catalog-last-fence-fixed-20261017-ec8e9a2b-de5d-4040-a55f-dedfe49ff2df/original-catalog-file/summary.json` 与 stdout：UTC 15:35:41.984–15:39:41.542，exit 0、unchanged/600、9/9。

## 待新 Browser 原件完成后的独立复核

复核新 smoke summary/checks 与外层 guard 的 before/after/snapshot，取得实际输出目录。A 重新核对原 UI JSON 字节、relay、唯一 ingress request/connection、prefix/end、完整 SHA、拒绝前后事实和精确请求计数；B 核对同 origin/port/context/storage key、一次真实 deny、丢回复、只 GET 恢复和实盘拒绝 canonical+LF SHA；双页核对真实 held/pending/clientId 和三个完整集合。

实际打开四张新截图，逐项读取 layouts、DOM、browser-requests、browser-errors、controlled replies、target requests、storage、来源原件摘要与 fresh operation。受控错误保留并与注入逐项匹配；不因预期 503 改写或过滤原错误。仅在这些新原件实际通过后出具 round6 独立结论。