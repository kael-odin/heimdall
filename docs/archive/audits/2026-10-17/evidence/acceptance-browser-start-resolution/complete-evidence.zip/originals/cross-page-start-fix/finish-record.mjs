import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const output = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(output, '../../../..');
const files = ['console/src/acceptance-browser-execution.js', 'console/src/AcceptanceBrowserExecution.vue',
  'core/test/acceptance-browser-start-resolution-console.test.mjs', 'core/test/acceptance-browser-start-resolution-console-state.test.mjs'];
const snapshot = [], patches = [];
for (const file of files) {
  const source = path.join(root, file), before = path.join(output, 'before', file), after = path.join(output, 'after', file);
  fs.mkdirSync(path.dirname(after), { recursive: true }); const bytes = fs.readFileSync(source); fs.writeFileSync(after, bytes);
  snapshot.push({ file, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') });
  const diff = spawnSync('git', ['diff', '--no-index', '--', before, after], { cwd: root, encoding: null, maxBuffer: 16 * 1024 * 1024 });
  if (![0, 1].includes(diff.status)) throw new Error(`Could not compare ${file}: ${diff.stderr}`);
  patches.push(diff.stdout);
}
fs.writeFileSync(path.join(output, 'fix-only.patch'), Buffer.concat(patches));
fs.writeFileSync(path.join(output, 'after-sha256.json'), JSON.stringify({ recordedAt: new Date().toISOString(), files: snapshot }, null, 2) + '\n');
console.log(JSON.stringify({ files: snapshot.length, patchBytes: Buffer.concat(patches).length }));
