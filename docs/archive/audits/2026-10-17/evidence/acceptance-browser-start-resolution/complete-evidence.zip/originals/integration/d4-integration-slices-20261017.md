# D4 实施切分与集成交接

日期：2026-10-17。状态：只读准备稿，尚未实现 D4，未运行 D4 测试、Core 或 Browser。本稿新增于 ignored workspace，D3 源码、发布原件及旧设计保持冻结。

本稿把既有设计重排为三条可并行的责任线，确定文件归属、最小接口和集成顺序。安全算法、持久化不变量与完整故障矩阵以以下原稿为准，不在这里另起设计：

- [D4 设计](d4-unknown-operation-design-20261017.md)
- [实施审查及验收矩阵](d4-implementation-review-20261017/implementation-review.md)
- [Web Locks 补充决定](d4-implementation-review-20261017/receipt-locking.md)，其决定已收敛，实施时不能再退回“单写者或锁二选一”。
- [固定 canonical/hash 向量](d4-implementation-review-20261017/resolution-vectors.json)

## 1. 三条责任线与文件边界

| 责任线 | 独占修改范围 | 交付给其他线的结果 |
| --- | --- | --- |
| A：Store/schema/service/API | `core/src/acceptance/browser-operation-schema.mjs`、`browser-operation-store.mjs`、`browser-execution-service.mjs`、`browser-execution-api.mjs`；必要的 `core/src/engine-server.mjs` 接线也全部归 A | 决定 union、严格 Resolution DTO、两个 HTTP 端点、原 execute 对 rejected 的分流、纯读 proof 和既有事实优先的接线 |
| B：helper/Vue | `console/src/acceptance-browser-execution.js`、`console/src/AcceptanceBrowserExecution.vue` | 完整 proof 校验、Web Locks 回执写协议、显式 deny、只读恢复及上下文隔离 |
| C：专项测试/真实 Browser smoke | `core/test/` 下 D4 新测试、fixtures 和需要适配的既有测试；新增独立 D4 smoke 及其 harness | 同一套固定向量、边界与竞态测试、两条真实主线、原生双页锁验证及证据 |

所有 test 文件由 C 独占，包括现有 `acceptance-browser-execution-console.test.mjs` 的异步适配。A、B 不顺手改测试，接口改变先发给 C；C 不修改产品源码来迁就测试。只有实现归属线修改对应产品文件。

`execution-runtime.mjs` 与 `catalog.mjs` 原则上只消费既有接口，不在本切片另起重构。如确需修改，由协调者先划给 A 单一归属，不能同时由测试线或前端线接管。

以下共享整合文件归协调者顺序处理，不分给三线并改：根 `package.json`、`core/package.json`、`.github/workflows/ci.yml`、README/HANDOFF/ROADMAP、`docs/competition/acceptance-browser-execution.md`、公开审计及证据目录、固定 verifier 兼容清单及其消费文件。新增 D4 smoke script，保留原 `acceptance:browser:execute:smoke` 回归入口。`seo-gate.yml` 不因本切片顺带改动。

## 2. 并行开始前一次锁定的接口

以下是 D4 的实施合同，当前 D3 不提供这些新方法。协调者在独立 D4 工作树开始时锁定，三线按相同名字写实现与 fake。

### 2.1 原确认与后端接口

原确认六字段保持：

```text
operationId
expectedGenerationId
expectedRevision
candidateId
contentDigest
targetReleaseId
```

Store 方法保持同步：

```text
inspectDecision(operationId, { full = true } = {})
  -> { kind: 'absent', operationId }
   | { kind: 'recorded', value: 原 D3 internal operation }
   | { kind: 'rejected', record: { envelope: Rejection, bytes: Buffer, sha256 } }

publishRejection({ projectId, request }, { assertCurrent })
  -> { decision: recorded 或 rejected, replayed: boolean }

publish(原输入, { assertCurrent })
  -> 保持 { record, replayed }
```

Service 和 HTTP：

```text
service.resolution(projectId, operationId)
  -> 同步 Resolution

service.denyStart(projectId, operationId, { action, request })
  -> 同步 { status: 200, payload: Resolution(recorded | rejected) }

GET  /api/acceptance/projects/:ap/browser-executions/:bo/resolution
POST /api/acceptance/projects/:ap/browser-executions/:bo/deny-start

deny body = {
  action: 'deny-future-starts-for-operation',
  request: 原六字段
}
```

公共 Resolution 的共同字段只允许 `schemaVersion:1`、`kind:'browser-start-resolution'`、`projectId`、`operationId`、`observedAt`、`outcome`；各变体仅附加：

| outcome | 额外字段 |
| --- | --- |
| recorded | `request`、`requestFingerprint`、`dispatchSha256`、`operation`（原严格 view） |
| rejected | `rejection`、`rejectionSha256` |
| unresolved | `reasonCode:'ABSENT_OBSERVED'` 或 `'ADMISSION_PENDING'` |

deny 的首发、匹配重放、已有 recorded 都返回 200。原 execute 成功仍只有既有 200/202 合同。错误码本身不解除回执；前端默认继续 GET resolution 取得并核验 proof，避免为本切片扩大通用错误 payload 合同。

### 2.2 前端最小导出与调用约定

在既有 helper 文件新增以下异步验证器，不再把旧 `browserOperationView` 的四字段比较当成完整 proof：

```text
async browserStartResolution(raw, { projectId, request, crypto = globalThis.crypto })
  -> 完整校验后的严格 Resolution；失败 reject

createBrowserExecutionReceipts({
  projectId, origin, storage,
  locks = globalThis.navigator?.locks
})
  -> Object.freeze({
       canWrite: boolean,
       read(): 原六字段数组,                 // 同步
       save(request): Promise<void>,         // 必须 await
       resolveExact(expectedRequest): Promise<void>
     })
```

`canWrite` 表示可使用锁协议，不能替代 `read()` 成功的判断；初始化读取、存储写入或回读失败继续阻断。没有 locks 时允许 read，两个写方法必须失败，Vue 禁用依赖安全保存/解除的写操作并给出原因。去掉产品裸 `resolve(operationId)` 入口，避免残留旁路。

锁注入沿用 Web Locks 形状 `locks.request(name, { mode:'exclusive' }, callback)`。锁名就是现有 key：`heimdall:browser-operations:v1:${origin}:${projectId}`。save 与 resolveExact 各自在锁内重新 read、严格比较原六字段、写集合、完整回读，锁不跨 HTTP/proof 查询。resolveExact 成功后由调用方 read 更新集合；干净集合中已缺席可幂等成功，集合损坏不能被缺席吞掉。

验证器需独立重算 domain fingerprint；rejected 还重算 canonical 原件加 LF 的 SHA-256。recorded/rejected 只有完整核验后才能调用 resolveExact；unresolved 永不解除。UI 不通过旧列表或错误状态码补出 proof。前端 crypto 注入只用于离线测试，实际浏览器使用 Web Crypto。

### 2.3 同一份固定向量

C 先把设计 JSON 中三条 revision（0、12、9007199254740991）的原确认、canonical 字符串、fingerprint、rejection bytes/sha256 精确转为正式 committed fixture，例如：

```text
core/test/fixtures/acceptance-browser-start-resolution-vectors.json
```

A 的 schema/store 测试和 B 的 helper 测试由 C 用同一份 fixture 验证。CI 不能 import ignored `_runs` 文档，也不能运行时用被测实现计算“预期值”。只将向量的数据及固定预期作为测试输入，不把 ignored 文档声明成运行依赖。

## 3. A 线的实际 D3 集成点

A 内部先完成 schema/store 的决定 union 与共享 claim，再接 service，最后处理 API 与 engine。

- Store 的 `readInternal`、`recover`、`ledger/list` 需要共同理解 accepted/rejected/partial；不能只在新 API 旁增写拒绝文件。现有 running partial-report 恢复语义及 accepted-only 返回合同保持，专项保护由 C 提供。
- Service 当前 execute 的首次读取以及 catch/settle 中再次读取均使用旧 `store.read()`；这些位置统一分流 rejected，防止已知拒绝被误判为未知提交或进入 settlement。pending 当前仅存 fingerprint/promise，需加入 projectId，避免另一项目观察在途状态。
- resolution 不调用 `capability()` 或 `ready()`，因为这两个既有路径可能运行 readiness 回调。GET 仅同步读取必要状态，不等待 pending Promise。
- API action→method 使用显式表。当前 suffix 增加后仍会被旧推导默认当 GET；新增 `deny-start` 必须同时声明 POST，保留已有 fatal UTF-8、16 KiB、object-only、安全错误映射和 no-store/鉴权边界。
- `engine-server.mjs` 约 1269–1274 行的全 `/api/acceptance` 写请求 recovery gate 位于 Browser handler 之前。它会在 service 尚未判断原事实时先拒绝 deny-start。A 必须协调精确 deny-start 入口，使既有匹配事实先读的 HTTP 合同真正成立，未知新拒绝仍进入 service 的严格 ready 门禁；不能整体放开 acceptance 写请求。不能只证明 service 单测通过就声称端点已接通。

交给 B/C 的完成信号必须包括：strict DTO 已稳定；GET 纯读；已有事实不被当前 busy/recovery 状态遮挡；原迟到 execute 读到 rejected 时 runner=0；受控错误映射与 `writeMayHaveCommitted` 传播齐全。不要在这一信号前让 B 对真实接口作放宽兼容。

## 4. B 线的实际 D3 集成点

B 可先用 C 提供的 DTO/fake 并行完成 helper，再接 Vue。

- helper 路径白名单仅增加 resolution/deny-start，保留原 POST 覆盖 fetch 与 response body 的独立 60 秒期限；GET 继续独立 read guard，不能把查询取消变成重 POST。
- `unknown` 改为所有尚未解除的回执；列表有同 bo 也继续阻断。canStart 同时要求读取成功和 canWrite，不能只检查 receiptStore 对象存在。
- 移除 `load()` 中按列表 view 自动 resolve，以及 `start` catch 中按普通 4xx resolve。成功 start 的旧 view 也不能直接解除，后续使用专用 GET proof。
- `start()` 先捕获原 project/origin/client/六字段与上下文，再 await save。取得锁等待期间上下文变化时不发送旧请求；已保存原回执仍归捕获的 client 核对，不能转移到新项目。
- 显式 deny 仅提交一次原六字段；失败或丢响应后只读恢复。旧 proof 只可处理原 client 的原确认，不能回填新项目的操作列表、错误或按钮状态。
- 来源全文继续只放内存；本机持久化仍只有六字段，不增加全文或隐式永久批准。

现有 helper 的实际调用方只有该 Vue 与 `core/test/acceptance-browser-execution-console.test.mjs`。后者现有同步 save、assert.throws(save)、裸 resolve 均由 C 改成异步/锁协议测试；B 发接口完成信号后不再改其签名。

## 5. C 线的专项与 Browser 责任

C 可以在 A/B 实现前先落固定 fixture、串行锁调度器及 fake 测试；接入真实实现后再验证临时根、kill-point 和 HTTP。建议新增最小专项文件集，实际可按关注点合并，但所有归属保持在 C：

```text
core/test/acceptance-browser-operation-decision.test.mjs
core/test/acceptance-browser-start-resolution-service.test.mjs
core/test/acceptance-browser-start-resolution-api.test.mjs
core/test/acceptance-browser-start-resolution-console.test.mjs
core/test/fixtures/acceptance-browser-start-resolution-vectors.json
core/test/fixtures/acceptance-browser-start-resolution.mjs
core/test/fixtures/acceptance-browser-start-resolution-kill-child.mjs   // 需要真实 kill-point 时
core/scripts/smoke-acceptance-browser-resolution-console.mjs
```

所有 helper 测试实际位于 `core/test/`，项目没有 `console/test/`。`core/scripts/test-core.mjs` 已自动发现该目录根层的 `*.test.mjs`，无需更改发现规则；fixtures 子目录不自动当测试执行。

静态 fake 不能代替真正临时根的互斥/崩溃检查，service 测试不能代替 engine 外层 gate 的 HTTP 验证，顺序调用不能代替原生双页锁竞态。完整场景矩阵引用原实施审查；本稿只强调两条主线的 harness 交接：

| 主线 | C 必须保留的真实条件 | 最小关键证据 |
| --- | --- | --- |
| A：同一原慢 body 被拒绝 | 同一原 POST 已向引擎交付部分 body 且尚未 end；deny 成功后释放其余原字节 | 连接/ingress 标识、原 Content-Length、拒绝前字节数、最终 body SHA、原 bo/fingerprint、请求计数、runner=0 |
| B：拒绝已提交但响应丢失后恢复 | 同真实 root、同 engine origin/端口、同 storage key、同 Browser context 正常重启；仅 GET proof 精确解除，然后用户复核新 bo | 重启前后回执原值、拒绝原件摘要、GET/POST 请求清单、proof、仅原回执被删、新 bo 的正常执行 |

A/B 独立执行。旧 socket 会因重启消失，不能用重启后的新 POST 冒充 A 的原连接。现有 D3 smoke 的 startEngine 每次获取随机端口；B 必须由新 harness 支持固定端口重启，不能复制 localStorage 到新 origin 伪造恢复。可先 about:blank 结束旧轮询再停引擎。旧 D3 自执行 smoke 不可 import 来复用函数，以免意外启动第二套 Browser。

另外使用同 origin 两页及原生 `navigator.locks` 实际交错两个保存、保存与解除、两个解除；离线测试注入真实串行调度器，不能用立即执行 callback 的假锁。C 提交 evidence summary、请求/错误日志、回执和决定摘要、桌面/手机明暗截图，保持原 pageErrors、console、timeout 与过滤门槛。真实 Browser 阶段只占用一个 Browser slot。

## 6. 依赖与合流顺序

1. **D3 发布先完成。** 由父协调者确认精确 D3 提交与发布门禁，再从该已推送提交开独立 D4 工作树/分支；当前冻结树只保留本准备文档。
2. **锁接口后并行。** 锁定本稿同步 Store/Service、严格 DTO、helper 异步签名与 locks 注入；C 先给固定向量和 fake，A/B/C 各在独占文件内实现。
3. **A 内部顺序。** schema/store decision → service execute/catch/settle/pending → API 方法表/错误映射 → engine recovery 接线。C 在每层接入真实实现。
4. **离线合流。** A+B 稳定后运行新增边界及原受影响测试，包含纯读/共享槽/partial/写后不明/异步调用方/无 locks/完整 body 期限/跨项目迟到响应。失败交回相应实现线，不由 C 修改产品逻辑。
5. **构建后单 Browser。** console build 成功，再串行运行 D4 A/B、原生双页锁、原先赢/busy/partial/上下文切换及原 D3 smoke；记录失败现场，不放宽门槛。
6. **协调者整合。** 审查固定 verifier 兼容清单，保持 D3→D4 条件改变不可比，不能自动等价；补 scripts/CI/docs/evidence，完整门禁后再冻结 D4 精确提交并核对对应 CI。

三线的交接消息均给出“文件、已实现接口、验证范围、尚未接通项”，不得把 fake 测试或静态审查写成真实 Browser 已通过。最小发布须同时包含 A/B/C 的完整闭环；本切片不单独发布前端解除入口，也不混入性能改造或 D5 缺陷单。

## 7. 本轮实际完成边界

本轮只静态读取既有 D4 设计/实施审查与 D3 实际源码，确认上述责任归属和集成点，并新增本 ignored sibling 文档。未修改 D3 源码/原件/旧设计，未运行测试、Core 或 Browser，未 stage、commit、push。文中的 D4 方法和验证结果均是下一阶段实施要求，不能作为已交付能力或已通过证据。
