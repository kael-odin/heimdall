import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
const review = dirname(fileURLToPath(import.meta.url)), final = join(review, 'final');
const machine = JSON.parse(fs.readFileSync(join(final, 'machine-summary.json')));
const results = [];
for (const name of ['A-original-request.json', 'B-restart-proof.json']) {
  const bytes = fs.readFileSync(join(machine.sourceDirectory, name)), value = JSON.parse(bytes), proof = value.proof ?? value.proofAfter;
  assert.deepEqual(proof.rejection, value.decision.rejection);
  assert.equal(proof.projectId, value.decision.rejection.projectId);
  assert.equal(proof.operationId, value.request.operationId);
  assert.equal(proof.rejection.operationId, value.request.operationId);
  assert.deepEqual(proof.rejection.request, value.request);
  results.push({ file: name, sha256: createHash('sha256').update(bytes).digest('hex'), projectId: proof.projectId,
    operationId: proof.operationId, fullRejectionEqual: true, originalSixFieldsEqual: true });
}
const result = { status: 'passed', verifiedAt: new Date().toISOString(), sourceDirectory: machine.sourceDirectory, results };
fs.writeFileSync(join(final, 'proof-bindings-check.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(result, null, 2));
