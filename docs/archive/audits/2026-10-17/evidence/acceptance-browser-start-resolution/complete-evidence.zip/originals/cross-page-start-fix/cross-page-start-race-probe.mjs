/** Actual Vue refs/watchers and the component's saved script, without DOM, Browser or engine. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createRequire } from 'node:module';
import { randomUUID, webcrypto } from 'node:crypto';
import * as helpers from '../../../../console/src/acceptance-browser-execution.js';

let vue;
try { vue = createRequire(new URL('../../../../console/package.json', import.meta.url))('vue'); } catch { /* Core-only installs do not contain the console runtime. */ }
const options = { skip: vue ? false : 'Install console dependencies to run the actual Vue state tests.' };
const { vectors: [vector] } = JSON.parse(fs.readFileSync(new URL('../../../test/fixtures/acceptance-browser-start-resolution-vectors.json', import.meta.url), 'utf8'));
const origin = 'http://127.0.0.1:3000', at = '2026-10-17T13:00:00.000Z';
const clone = value => JSON.parse(JSON.stringify(value));
const deferred = () => { let resolve; const promise = new Promise(done => { resolve = done; }); return { promise, resolve }; };
const keyFor = projectId => `heimdall:browser-operations:v1:${origin}:${projectId}`;
function serialLocks() {
  const tails = new Map(), log = [];
  return { log, request(name, settings, callback) {
    assert.deepEqual(settings, { mode: 'exclusive' }); log.push(name);
    const next = (tails.get(name) ?? Promise.resolve()).then(() => callback({ name, mode: 'exclusive' }));
    tails.set(name, next.catch(() => {})); return next;
  } };
}
function memoryStorage(values = []) {
  const records = new Map(values.length ? [[keyFor(vector.projectId), JSON.stringify(values)]] : []);
  return { records, getItem: key => records.get(key) ?? null, setItem: (key, value) => { records.set(key, value); } };
}
const capability = { enabled: true, ready: true, recoveryReady: true, busy: false, closing: false, blocked: false,
  code: null, kind: null, runId: null, taskId: null, approvalScope: 'single-operation', baselineNetworkRequests: false };
const response = value => new Response(JSON.stringify(value));
const operation = request => ({ schemaVersion: 1, operationId: request.operationId, runId: 'br-' + randomUUID(), taskId: 'a-' + randomUUID(),
  projectId: vector.projectId, candidateId: request.candidateId, contentDigest: request.contentDigest, targetReleaseId: request.targetReleaseId,
  targetLabel: 'Original target', approvalScope: 'single-operation', state: 'prepared', acceptedAt: at, updatedAt: at,
  gate: null, reportSha256: null, reasonCode: null, summary: null, executionReady: false });
function resolution(url) {
  const [, projectId, operationId] = /\/projects\/(ap-[^/]+)\/browser-executions\/(bo-[^/]+)\/resolution$/.exec(url);
  return { schemaVersion: 1, kind: 'browser-start-resolution', projectId, operationId, observedAt: at,
    outcome: 'unresolved', reasonCode: 'ABSENT_OBSERVED' };
}
const rejected = () => ({ schemaVersion: 1, kind: 'browser-start-resolution', projectId: vector.projectId,
  operationId: vector.request.operationId, observedAt: at, outcome: 'rejected', rejection: clone(vector.rejection), rejectionSha256: vector.rejectionSha256 });
async function waitFor(predicate) {
  const deadline = Date.now() + 3000;
  while (!predicate()) { if (Date.now() > deadline) assert.fail('State did not settle before the offline deadline.'); await new Promise(resolve => setTimeout(resolve, 5)); }
}
async function settle() { for (let i = 0; i < 4; i++) await new Promise(setImmediate); }

const script = fs.readFileSync(new URL('../../../../console/src/AcceptanceBrowserExecution.vue', import.meta.url), 'utf8')
  .match(/<script setup>([\s\S]*?)<\/script>/)[1].replace(/^import[\s\S]*?;\r?$/gm, '');
const evaluate = new Function('vue', 'helpers', 'environment', `
  const { computed, ref, watch } = vue;
  const { onBeforeUnmount, defineProps, API, apiHeaders, location, window, localStorage, crypto } = environment;
  const { browserOperationView, browserOperationCollection, browserOperationReport, browserExecutionLedger,
    browserStartResolution, browserExecutionRegistration, createBrowserExecutionReadGuard,
    createBrowserExecutionReceipts, fetchBrowserExecutionEvidence, requestBrowserExecution } = helpers;
  const browserCandidateReviewState = () => { throw new Error('This offline state test does not fabricate a candidate read.'); };
  ${script}
  return { start, denyStart, load, canStart, pending, error, notice, writing, candidateId, targetReleaseId,
    confirmed, review, denyConfirmed, operations, receiptReadable, receiptWritable };
`);
function model(t, { storage = memoryStorage(), locks = serialLocks(), transport = () => null } = {}) {
  const props = vue.reactive({ projectId: vector.projectId, active: true, ready: true,
    version: { generationId: vector.request.expectedGenerationId, revision: vector.request.expectedRevision },
    detail: { browserCandidates: [{ id: vector.request.candidateId }],
      releases: [{ id: vector.request.targetReleaseId, label: 'Original target', targetUrl: 'http://target.test/' }] } });
  const calls = [], scope = vue.effectScope(); let dispose;
  const fetcher = async (url, requestOptions) => {
    calls.push({ url, ...requestOptions }); const result = transport(url, requestOptions);
    if (result !== null && result !== undefined) return result;
    if (url.endsWith('/resolution')) return response(resolution(url));
    if (requestOptions.method === 'GET' && url.endsWith('/browser-executions')) {
      const projectId = /\/projects\/(ap-[^/]+)/.exec(url)[1];
      return response({ schemaVersion: 1, projectId, operations: [], capability });
    }
    assert.fail(`Unexpected offline transport: ${requestOptions.method} ${url}`);
  };
  const adapted = { ...helpers,
    createBrowserExecutionReceipts: value => helpers.createBrowserExecutionReceipts({ ...value, locks }),
    browserStartResolution: (raw, value) => helpers.browserStartResolution(raw, { ...value, crypto: webcrypto }),
    requestBrowserExecution: (path, value) => helpers.requestBrowserExecution(path, { ...value, timeoutMs: 20, fetcher }) };
  const state = scope.run(() => evaluate(vue, adapted, { defineProps: () => props, onBeforeUnmount: callback => { dispose = callback; },
    API: '', apiHeaders: () => ({}), location: { origin, href: origin + '/' },
    window: { addEventListener() {}, removeEventListener() {} }, localStorage: storage, crypto: { subtle: webcrypto.subtle, randomUUID } }));
  t.after(() => { dispose(); scope.stop(); }); return { ...state, props, calls, storage, locks };
}
async function prepare(state) {
  state.candidateId.value = vector.request.candidateId; state.targetReleaseId.value = vector.request.targetReleaseId;
  await settle();
  state.review.value = { candidate: { id: vector.request.candidateId, contentDigest: vector.request.contentDigest }, review: {},
    generationId: vector.request.expectedGenerationId, revision: vector.request.expectedRevision,
    diagnostics: { contentMatches: true }, presentation: { completeSourceProjection: true } };
  state.confirmed.value = true;
}
const cleanups = [], t = { after(callback) { cleanups.push(callback); } };
const storage = memoryStorage(), locks = serialLocks(), entered = deferred(), release = deferred();
const blocker = locks.request(keyFor(vector.projectId), { mode: 'exclusive' }, async () => { entered.resolve(); await release.promise; });
await entered.promise;
const originalStart = (url, requestOptions) => requestOptions.method === 'POST' && url.endsWith('/browser-executions') ? new Response(JSON.stringify({ code: 'BROWSER_EXECUTION_UNAVAILABLE', error: 'Controlled unknown original start', outcomeUnknown: true }), { status: 503 }) : null;
const a = model(t, { storage, locks, transport: originalStart });
const b = model(t, { storage, locks, transport: originalStart });
await prepare(a); await prepare(b);
assert.equal(a.canStart.value, true); assert.equal(b.canStart.value, true); assert.deepEqual(JSON.parse(storage.records.get(keyFor(vector.projectId)) ?? '[]'), []);
const first = a.start(), second = b.start(); await settle();
const beforeRelease = { storage: JSON.parse(storage.records.get(keyFor(vector.projectId)) ?? '[]'), firstPosts: a.calls.filter(item => item.method === 'POST').length, secondPosts: b.calls.filter(item => item.method === 'POST').length, lockRequests: locks.log.length };
assert.deepEqual(beforeRelease.storage, []); assert.equal(beforeRelease.firstPosts, 0); assert.equal(beforeRelease.secondPosts, 0); assert.equal(beforeRelease.lockRequests, 3);
release.resolve(); await blocker; await Promise.all([first, second]); await settle();
const firstPosts = a.calls.filter(item => item.method === 'POST'), secondPosts = b.calls.filter(item => item.method === 'POST');
const all = JSON.parse(storage.records.get(keyFor(vector.projectId)));
assert.equal(firstPosts.length, 1); assert.equal(secondPosts.length, 1); assert.equal(all.length, 2);
const firstRequest = JSON.parse(firstPosts[0].body), secondRequest = JSON.parse(secondPosts[0].body);
assert.notEqual(firstRequest.operationId, secondRequest.operationId); assert.deepEqual(all, [firstRequest, secondRequest]);
const result = { status: 'counterexample-confirmed', testedAt: new Date().toISOString(), scope: 'actual saved Vue script plus real Vue runtime and helper; two independent page-state models, shared storage, same FIFO serial lock; storage events deliberately queued/not delivered; no Browser/Core/HTTP', beforeRelease, firstPosts: firstPosts.length, secondPosts: secondPosts.length, originalRequests: all, finalFirstPending: a.pending.value.length, finalSecondPending: b.pending.value.length, firstError: a.error.value, secondError: b.error.value, firstCanStartAfter: a.canStart.value, secondCanStartAfter: b.canStart.value };
fs.writeFileSync(new URL('./cross-page-start-race-result.json', import.meta.url), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
for (const cleanup of cleanups.reverse()) cleanup();
console.log(JSON.stringify(result, null, 2));