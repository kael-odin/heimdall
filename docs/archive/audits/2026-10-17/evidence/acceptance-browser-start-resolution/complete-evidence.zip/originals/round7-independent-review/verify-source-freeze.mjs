import fs from 'node:fs';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { resolve, join } from 'node:path';
const root = resolve('.'), base = join(root, 'core/workspace/_runs/d4-validation-round7-20261018');
const output = join(root, 'core/workspace/_runs/d4-round7-independent-review-20261018/preflight/source-freeze-check.json');
const bytes = fs.readFileSync(join(base, 'source-snapshot.json')), snapshot = JSON.parse(bytes), sha = value => createHash('sha256').update(value).digest('hex');
const gate = JSON.parse(fs.readFileSync(join(base, 'preflight-resolution-ui/summary.json')));
const before = JSON.parse(fs.readFileSync(join(base, 'preflight-resolution-ui/before.json')));
const after = JSON.parse(fs.readFileSync(join(base, 'preflight-resolution-ui/after.json')));
assert.equal(gate.label, 'preflight-resolution-ui'); assert.equal(gate.exitCode, 0); assert.equal(gate.unchanged, true);
assert.equal(sha(bytes), gate.baselineSha256); assert.equal(snapshot.files.length, 600);
assert.deepEqual(before, snapshot.files); assert.deepEqual(after, snapshot.files);
for (const file of snapshot.files) { const actual = fs.readFileSync(join(root, file.file)); assert.equal(actual.length, file.bytes); assert.equal(sha(actual), file.sha256, file.file); }
const result = { status: 'passed', verifiedAt: new Date().toISOString(), phase: 'preflight-only', sourceFiles: snapshot.files.length,
  baselineSha256: sha(bytes), snapshotCapturedAt: snapshot.capturedAt, gate, beforeMatches: true, afterMatches: true, currentFileBytesMatch: true };
fs.writeFileSync(output, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(result, null, 2));
