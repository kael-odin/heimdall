# Catalog 最后 dispatch 栅栏回归诊断与最小修复

日期：2026-10-17。本目录保留修前隔离运行；没有修改原 catalog 或新增 decision 测试。所有运行均为离线夹具，没有启动 Browser。

## 修前原测试复现

`original-single` 使用未经修改的 `core/test/acceptance-browser-execution-catalog.test.mjs`，精确匹配题为 source change during the last dispatch fence retains copied staging but cannot publish or reuse an operation fact 的原单项。

结果：1 test / 0 pass / 1 fail，exit 1。失败在原文件第 126 行：evidence 目录 expected true / actual false。前面的 `BASELINE_CHANGED` 和 `fences === 2` 断言已经通过。600 项源码在运行前后完全一致，匹配 round5 SHA `bed82f629fa6350292378e3d1d1ccfb4cda034186cc35bf9e541b0031b0fb65f`。

D3 的外部完整来源 guard 在复制前调用一次，在真实 dispatch 不可变提交前调用第二次。D4 的新 claim 实现又在 claim 成功后、创建 evidence 前调用一次完整外部 guard。原测试在第二次 guard 精确注入来源变化，因此现在提前在复制前被拒绝，未再测试其标题声明的最后提交栅栏。这是产品调用时机回归，不能通过放宽原 evidence 断言解决。

## 额外修前探针

`true-last-fence-probe.mjs` 取原 fixture 的同一构造过程，在 24 项来源副本全部逐字节匹配且恰有一个 dispatch 临时文件时才注入来源变化。它实际走到第三次外部 guard，仍被 `BASELINE_CHANGED` 拒绝，24 项 evidence 保留且 dispatch/head 不存在，最终目录仅有 evidence。

随后探针发现第二处兼容回归：旧 `read(partial)` 现在经新 decision shape 返回 `BROWSER_OPERATION_INTEGRITY_FAILED / DECISION_INCOMPLETE`，但原合同要求 `BROWSER_OPERATION_UNAVAILABLE`。该探针因此 exit 1，具体 actual/expected 与完整堆栈保留在 `true-last-fence-probe/stderr.log`，不能写成整组通过。其 600 项源码也前后不变。

## 经主代理授权的最小修复

1. accepted `claimNew` 后只调用 `currentClaim`，保留 owner、namespace 容量、目录身份及形状检查。复制前外部完整 guard 和真实 dispatch 末栅栏继续存在。拒绝发布的 claimGuard 路径保持原样。
2. `readInternal` 仅将新完整性错误中的 `DECISION_INCOMPLETE` 投影回旧 `BROWSER_OPERATION_UNAVAILABLE`，保留相同 reason 和 503；`inspectDecision` 及批次 decision 预检继续保留严格完整性错误。不会收养、补齐或重新执行 partial。

本目录 `minimal-fix.diff` 只含这两处变化。`store-before.mjs` 是对修后文件精确逆补丁重建的前像，并独立核对为既有冻结 SHA `dd00e2ecf730637e6243c254907c0e75d1f6c8e66265005cd6221ec089496f5a`，不是事前直接复制；该来源明确记于 `store-change.json`。修后 `store-after.mjs` 为实际读取的 46174 bytes，SHA `f1b3a61fc0e88838f987e46375f8311e7819e348c7484b94ef8a57e42166684a`。

## 修后验证指针

新的 600 项源码集合及原 catalog 整文件、原样 decision 专项位于 sibling `d4-catalog-last-fence-fixed-20261017-ec8e9a2b-de5d-4040-a55f-dedfe49ff2df`。它的最终结果必须等待各组 summary，不能以本目录修前失败或早前专项通过替代。整个 round5 全量 Core 已由主代理精确终止并保留，不作为最终发布通过。
