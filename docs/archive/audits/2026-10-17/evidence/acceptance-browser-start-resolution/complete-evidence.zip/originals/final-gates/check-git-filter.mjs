import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
const out = dirname(fileURLToPath(import.meta.url));
const names = JSON.parse(readFileSync(join(out, 'source-snapshot.json'), 'utf8')).files.map(value => value.file);
const hashes = args => {
  const value = spawnSync('git', ['hash-object', ...args, '--stdin-paths'], { input: names.join('\n') + '\n', encoding: 'utf8', windowsHide: true });
  assert.equal(value.status, 0, value.stderr);
  const result = value.stdout.trim().split(/\r?\n/); assert.equal(result.length, names.length); return result;
};
const filtered = hashes([]), raw = hashes(['--no-filters']);
const transformed = names.flatMap((file, index) => filtered[index] === raw[index] ? [] : [{ file, filtered: filtered[index], raw: raw[index] }]);
const result = { checkedAt: new Date().toISOString(), checked: names.length, transformed };
writeFileSync(join(out, 'git-filter-precheck.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(result)); assert.equal(transformed.length, 0);
