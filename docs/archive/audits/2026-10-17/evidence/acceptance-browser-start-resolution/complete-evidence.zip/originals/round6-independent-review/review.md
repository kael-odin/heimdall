# round6 Browser 启动决定恢复独立审查

审查在 2026-10-17 UTC / 2026-10-18 Asia/Hong_Kong 完成。原始 smoke 目录为 `browser-resolution-console-smoke-8476a773-f235-49c1-9f67-c00c4289bb71`，UTC 15:53:45.858–15:54:47.391；其 summary 与 checks 为 passed、9/9，独立验证脚本 exit 0。后续发现了 smoke 未覆盖的双 Vue 同时 start 竞态，因此本轮历史通过不能写成没有阻断问题，也不能替代修后的 round7。

`verify-completed-smoke.mjs` 直接读取完整 smoke、实盘决定和来源文件，结果落于 `independent-evidence-check.json`。原件没有被改写。

| 核验项 | 实际结果及精确范围 |
| --- | --- |
| A 原 start 的精确 body | 342 bytes，prefix 171 bytes，SHA-256 `c4c484235cfbb5daa12b5c148cd7d98428eae7ba473a7969483e4a3e3def8bf0`，唯一 ingress request 与 connection。 |
| A/B 拒绝原件 | 各 761 bytes，均等于 canonical JSON 加单个 LF。A SHA `3225bf837852f321d9fb0e4dcd7ffecfb09d90021c0a270fbc2a21597af37ba8`；B SHA `2fe554d8b4709a1088e0b53ee68bcbc847ee43408a50676fe7953313f4ca18db`。 |
| B 丢失拒绝响应后的进程重启 | origin `http://127.0.0.1:63625`，保持 storage key，1 次拒绝响应被丢弃，恢复只发 3 GET。总 start=3、deny=2，恢复不增 POST。 |
| 双页原生 helper 锁 | save-save、resolve-save、resolve-resolve 均有 held=1、pending=2、两个 clientId；集合分别 0→2、2→2、2→0。此轮没有 claim-start-claim-start。 |
| Fresh 真实 API | completed/passed，14/14 声明检查通过。保存来源后未重新访问来源；29 份来源文件 SHA 完整相同。source/broken/healthy 请求各 4。 |
| Console | pageErrors=0；5 条 error 均逐条匹配受控 503 resource 文案，没有将它们删除后声称零错误。 |
| 采样布局 | 桌面 1440 视口，组件 client/scroll=964/964；手机 390 视口，296/296；documentWidth 等于视口，没有采样横向溢出。 |

四张本轮 PNG 均已实际打开：

- `resolution-A-desktop-light.png` 显示未知确认、重新复核并勾选后灰置的新启动按钮，原操作说明可读。
- `resolution-B-mobile-dark.png` 显示未知确认和原回执上半部；下部 pending 文案仅由完整 DOM 文本证明，不能称首屏截图全部覆盖。
- `resolution-recovered-desktop-dark.png` 显示永久拒绝证明核验和原确认解除提示，没有自动启动。
- `resolution-fresh-mobile-light.png` **实际仍显示“正在验收 · 存在阻塞”和“请求停止”**；`layouts.json` 的完整文本同样如此。同期 fresh API 已 completed/passed 14/14，说明本轮 capture 早于 UI 下次轮询更新。不能将其他轮截图的“已完成 · 通过”结论沿用到本轮。协调者随后为新 smoke 增加精确等待实际 fresh 操作行终态，修后的截图以 round7 为准。

A 的路径是“原 UI body 经单一 Node HTTP relay 分段送入真实 engine”，不声称 Chromium socket 原生拆包。双页锁为实际 helper + 原生 navigator.locks/localStorage，尚不是双 Vue DOM/storage-event 闭环。重启先 SIGTERM、可能 SIGKILL，不单凭此证明优雅退出。受控本机站点证据不构成任意业务站点、PRD/Figma 还原度或全量无障碍认证。

独立审查使用实际 Vue 状态 harness 构造了另一个确定性场景：先持有共享 origin/project 锁，让两个独立页面都越过空集合预检并排队，再释放。修前两页各 1 POST，最终 2 receipts。证据为 `cross-page-start-race-probe.mjs`、`cross-page-start-race-result.json`；该反例仅使用离线受控 503 运输，没有 Browser/HTTP/Core。

根因是通用 save 在锁内保留另一条确认，这满足集合更新合同，却没有实现“新启动只允许空集合”的准入合同。协调者停止 round6 后授权四文件修复：新增专用 claimForStart，保持一般 save/resolveExact；真实双 Vue 状态测试现在要求 1 POST/1 receipt，等待期间另一回执出现要求 0 新 POST、无 fault，坏回读继续锁存。修后纯专项 25/25，详情见 `../d4-cross-page-start-fix-20261017/review.md`。它没有被冒充为真实两页 Vue 浏览器验证。

协调者报告本轮全 Core 原件为 2525 total / 2513 pass / 0 fail / 0 cancelled / 12 skipped，exit 0，UTC 15:34:53.365–15:53:21.840；其余已成功阶段原件保留。round6 在新缺陷发现后主动停止，managed-execution-ui 仅 before 与空 stdout，没有成功 summary，不能把它记作通过。当前报告只独立重算本轮新 resolution smoke；全 Core skip 原因及完整门禁汇总由协调者核对，后续统一发布以新 round7 冻结、最终 commit 与自身 CI 为准。
