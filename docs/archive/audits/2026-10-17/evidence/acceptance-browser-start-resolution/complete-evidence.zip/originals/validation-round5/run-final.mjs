import assert from 'node:assert/strict';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const out = dirname(fileURLToPath(import.meta.url)), root = resolve(out, '../../../..'), guard = join(out, 'guard.mjs');
const core = join(out, 'core-full/summary.json');
console.log('Waiting for the current full Core gate before serial Browser gates.');
while (!existsSync(core)) await new Promise(resolve => setTimeout(resolve, 1000));
const first = JSON.parse(readFileSync(core, 'utf8')); assert.equal(first.exitCode, 0); assert.equal(first.unchanged, true);
const steps = [
  ['console-build', ['console/node_modules/vite/bin/vite.js', 'build', 'console']],
  ['syntax', ['core/scripts/check-syntax.mjs']],
  ['browser-resolution-ui', ['core/scripts/smoke-acceptance-browser-resolution-console.mjs']],
  ['browser-execution-ui', ['core/scripts/smoke-acceptance-browser-execution-console.mjs']],
  ['original-console', ['core/scripts/smoke-acceptance-console.mjs']],
  ['owned-recovery', ['core/scripts/smoke-acceptance-owned-recovery.mjs']],
  ['managed-execution-ui', ['core/scripts/smoke-acceptance-execution-ui.mjs']],
  ['browser-candidates', ['core/scripts/smoke-acceptance-browser-candidates-console.mjs']],
  ['browser-bindings-v4', ['core/scripts/smoke-acceptance-browser-bindings-console.mjs', '--migrate-catalog']],
  ['forge', ['core/scripts/smoke-forge.mjs']],
  ['console-cdp', ['core/scripts/smoke-console-cdp.mjs']],
];
for (const [name, args] of steps) {
  console.log(JSON.stringify({ event: 'gate-start', name, at: new Date().toISOString() }));
  const child = spawn(process.execPath, [guard, 'run', name, 'node', ...args], { cwd: root, windowsHide: true,
    env: { ...process.env, ...(name === 'console-cdp' ? { HEIMDALL_E2E_CDP_SELF: '1' } : {}) }, stdio: 'inherit' });
  const code = await new Promise((resolve, reject) => { child.once('error', reject); child.once('close', resolve); });
  assert.equal(code, 0, name + ' failed; all original output retained.');
}
writeFileSync(join(out, 'completed.json'), JSON.stringify({ completedAt: new Date().toISOString(), gates: ['core-full', ...steps.map(([name]) => name)], status: 'passed' }, null, 2) + '\n', { flag: 'wx' });
